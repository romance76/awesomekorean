<template>
  <div :class="isMobile ? 'ss-m' : ''">
    <!-- Header -->
    <div class="flex items-center justify-between mb-6">
      <h1 class="flex items-center gap-2.5 text-xl font-bold text-ink">
        <span class="icon-chip w-9 h-9 bg-amber-50 text-amber-600"><AppIcon name="settings" :size="20" /></span>
        사이트 설정
      </h1>
      <span class="text-xs text-ink-faint">마지막 로드: {{ lastLoaded }}</span>
    </div>

    <!-- Toast -->
    <Transition name="toast">
      <div v-if="toast.show" :class="[
        'fixed top-5 right-5 z-50 flex items-center gap-3 px-5 py-3 rounded-xl shadow-lg text-white text-sm font-medium',
        toast.type === 'success' ? 'bg-green-500' : 'bg-red-500'
      ]">
        <span>{{ toast.type === 'success' ? '✓' : '✕' }}</span>
        {{ toast.message }}
      </div>
    </Transition>

    <!-- Tab Navigation -->
    <div class="flex gap-1 mb-6 bg-gray-100 p-1 rounded-xl overflow-x-auto">
      <button
        v-for="tab in tabs"
        :key="tab.key"
        @click="activeTab = tab.key"
        :class="[
          'flex-shrink-0 px-4 py-2 rounded-lg text-sm transition-all',
          activeTab === tab.key
            ? 'bg-white text-ink font-semibold shadow-sm'
            : 'text-ink-muted hover:text-ink-light'
        ]"
      >
        {{ tab.label }}
      </button>
    </div>

    <!-- Loading -->
    <div v-if="loading" class="flex justify-center items-center py-20">
      <div class="w-8 h-8 border-4 border-amber-400 border-t-transparent rounded-full animate-spin"></div>
    </div>

    <div v-else>
      <!-- ========================= TAB 1: 회사 정보 ========================= -->
      <div v-show="activeTab === 'company'">
        <div class="card p-6">
          <h2 class="text-base font-semibold text-ink mb-6">회사 정보</h2>
          <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div>
              <label class="input-label">사이트명</label>
              <input v-model="company.site_name" type="text" class="input-field" placeholder="AwesomeKorean" />
            </div>
            <div>
              <label class="input-label">사이트 부제목</label>
              <input v-model="company.site_subtitle" type="text" class="input-field" placeholder="미국 한인 커뮤니티" />
            </div>
            <div>
              <label class="input-label">회사명</label>
              <input v-model="company.company_name" type="text" class="input-field" placeholder="AwesomeKorean Inc." />
            </div>
            <div>
              <label class="input-label">대표자명</label>
              <input v-model="company.ceo_name" type="text" class="input-field" placeholder="홍길동" />
            </div>
            <div>
              <label class="input-label">사업자등록번호</label>
              <input v-model="company.business_number" type="text" class="input-field" placeholder="123-45-67890" />
            </div>
            <div>
              <label class="input-label">주소</label>
              <input v-model="company.address" type="text" class="input-field" placeholder="Los Angeles, CA, USA" />
            </div>
            <div>
              <label class="input-label">전화번호</label>
              <input v-model="company.phone" type="text" class="input-field" placeholder="+1-213-000-0000" />
            </div>
            <div>
              <label class="input-label">이메일</label>
              <input v-model="company.email" type="email" class="input-field" placeholder="admin@awesomekorean.com" />
            </div>
            <div>
              <label class="input-label">설립일</label>
              <input v-model="company.founded_date" type="date" class="input-field" />
            </div>
            <div>
              <label class="input-label">메타 키워드</label>
              <input v-model="company.meta_keywords" type="text" class="input-field" placeholder="한인, 커뮤니티, 미국, LA" />
            </div>
          </div>

          <!-- 로고 업로드 — 올리면 네비게이션 바, 로그인/가입 화면, 이메일 템플릿 등
               로고가 들어가는 모든 곳에 바로 반영됨 (public/images/logo.png 자체를 교체) -->
          <div class="mt-5">
            <label class="input-label">사이트 로고</label>
            <div class="flex items-center gap-3">
              <div class="w-16 h-16 border border-gray-100 rounded-xl overflow-hidden flex items-center justify-center bg-gray-50 flex-shrink-0">
                <img v-if="company.logo_url" :src="company.logo_url" alt="Logo Preview" class="w-full h-full object-contain" @error="logoError = true" />
                <span v-else class="text-xs text-ink-faint">미리보기</span>
              </div>
              <div class="flex-1">
                <input ref="logoFileInput" type="file" accept="image/png,image/jpeg,image/webp" class="hidden" @change="onLogoFileSelected" />
                <button type="button" @click="logoFileInput.click()" :disabled="uploadingLogo" class="btn-secondary px-4 py-2 text-sm">
                  {{ uploadingLogo ? '업로드 중...' : '로고 이미지 업로드' }}
                </button>
                <p class="text-xs text-ink-faint mt-1.5">PNG/JPG/WEBP, 최대 4MB. 업로드하면 즉시 전체 화면에 반영됩니다.</p>
              </div>
            </div>
          </div>

          <!-- 다크 배경용 로고 업로드 — 푸터처럼 어두운 배경에서 기본 로고가
               안 보일 때를 대비한 흰색/밝은 톤 버전. 안 올리면 텍스트로 폴백. -->
          <div class="mt-5">
            <label class="input-label">로고 (다크 배경용, 흰색 버전)</label>
            <div class="flex items-center gap-3">
              <div class="w-16 h-16 rounded-xl overflow-hidden flex items-center justify-center bg-slate-800 flex-shrink-0">
                <img v-if="company.logo_dark_url" :src="company.logo_dark_url" alt="Dark Logo Preview" class="w-full h-full object-contain" />
                <span v-else class="text-xs text-gray-400">미리보기</span>
              </div>
              <div class="flex-1">
                <input ref="logoDarkFileInput" type="file" accept="image/png,image/jpeg,image/webp" class="hidden" @change="onLogoDarkFileSelected" />
                <button type="button" @click="logoDarkFileInput.click()" :disabled="uploadingLogoDark" class="btn-secondary px-4 py-2 text-sm">
                  {{ uploadingLogoDark ? '업로드 중...' : '다크 배경용 로고 업로드' }}
                </button>
                <p class="text-xs text-ink-faint mt-1.5">PNG/JPG/WEBP, 최대 4MB. 푸터 등 어두운 배경 섹션에 반영됩니다 (안 올리면 텍스트로 대체 표시).</p>
              </div>
            </div>
          </div>

          <!-- 앱 아이콘 업로드 — 핸드폰 홈 화면에 "바로가기"로 추가할 때 쓰이는
               정사각형 아이콘. 로고(가로형 워드마크)와는 별개로 관리. -->
          <div class="mt-5">
            <label class="input-label">앱 아이콘 (홈 화면 바로가기용)</label>
            <div class="flex items-center gap-3">
              <div class="w-16 h-16 border border-gray-100 rounded-xl overflow-hidden flex items-center justify-center bg-gray-50 flex-shrink-0">
                <img v-if="company.app_icon_url" :src="company.app_icon_url" alt="App Icon Preview" class="w-full h-full object-contain" />
                <span v-else class="text-xs text-ink-faint">미리보기</span>
              </div>
              <div class="flex-1">
                <input ref="appIconFileInput" type="file" accept="image/png,image/jpeg,image/webp" class="hidden" @change="onAppIconFileSelected" />
                <button type="button" @click="appIconFileInput.click()" :disabled="uploadingAppIcon" class="btn-secondary px-4 py-2 text-sm">
                  {{ uploadingAppIcon ? '업로드 중...' : '앱 아이콘 업로드' }}
                </button>
                <p class="text-xs text-ink-faint mt-1.5">정사각형 이미지 권장 (PNG/JPG/WEBP, 최대 4MB). iOS/안드로이드 홈 화면 바로가기 아이콘에 반영됩니다.</p>
              </div>
            </div>
          </div>

          <!-- 파비콘 업로드 — 브라우저 탭에 표시되는 작은 아이콘 -->
          <div class="mt-5">
            <label class="input-label">파비콘 (브라우저 탭 아이콘)</label>
            <div class="flex items-center gap-3">
              <div class="w-16 h-16 border border-gray-100 rounded-xl overflow-hidden flex items-center justify-center bg-gray-50 flex-shrink-0">
                <img v-if="company.favicon_url" :src="company.favicon_url" alt="Favicon Preview" class="w-full h-full object-contain" />
                <span v-else class="text-xs text-ink-faint">미리보기</span>
              </div>
              <div class="flex-1">
                <input ref="faviconFileInput" type="file" accept="image/png,image/jpeg,image/webp" class="hidden" @change="onFaviconFileSelected" />
                <button type="button" @click="faviconFileInput.click()" :disabled="uploadingFavicon" class="btn-secondary px-4 py-2 text-sm">
                  {{ uploadingFavicon ? '업로드 중...' : '파비콘 업로드' }}
                </button>
                <p class="text-xs text-ink-faint mt-1.5">정사각형 이미지 권장 (PNG/JPG/WEBP, 최대 2MB). 브라우저 탭/즐겨찾기에 반영됩니다.</p>
              </div>
            </div>
          </div>

          <!-- Meta Description -->
          <div class="mt-5">
            <label class="input-label">메타 설명 (SEO)</label>
            <textarea v-model="company.meta_description" rows="3" class="input-field resize-none" placeholder="미국 한인 커뮤니티 플랫폼..."></textarea>
          </div>

          <div class="mt-6 flex justify-end">
            <button @click="saveCompany" :disabled="saving" class="btn-primary">
              <span v-if="saving" class="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></span>
              저장하기
            </button>
          </div>
        </div>
      </div>

      <!-- ========================= TAB 2: 사이트 설정 ========================= -->
      <div v-show="activeTab === 'site'">
        <div class="card p-6">
          <h2 class="text-base font-semibold text-ink mb-6">사이트 설정</h2>

          <!-- 회원 설정 -->
          <div class="mb-6">
            <h3 class="text-sm font-semibold text-ink-muted uppercase tracking-wide mb-4">회원 설정</h3>
            <div class="space-y-4">
              <ToggleRow v-model="site.allow_signup" label="회원가입 허용" desc="신규 회원 가입을 허용합니다" />
              <ToggleRow v-model="site.require_email_verify" label="이메일 인증 필수" desc="가입 후 이메일 인증이 필요합니다" />
              <ToggleRow v-model="site.auto_approve" label="자동 승인" desc="가입 즉시 계정을 활성화합니다" />
              <ToggleRow v-model="site.allow_withdrawal" label="회원 탈퇴 허용" desc="회원이 스스로 탈퇴할 수 있습니다" />
              <div class="flex items-center gap-4">
                <label class="text-sm text-ink-light w-48">최소 비밀번호 길이</label>
                <input v-model.number="site.min_password_length" type="number" min="6" max="32" class="input-field w-24" />
                <span class="text-sm text-ink-faint">자리</span>
              </div>
            </div>
          </div>

          <div class="border-t border-gray-100 pt-6 mb-6">
            <h3 class="text-sm font-semibold text-ink-muted uppercase tracking-wide mb-4">파일 업로드 설정</h3>
            <div class="flex flex-col gap-4">
              <div class="flex items-center gap-4">
                <label class="text-sm text-ink-light w-48">최대 업로드 파일 크기</label>
                <input v-model.number="site.max_upload_mb" type="number" min="1" max="100" class="input-field w-24" />
                <span class="text-sm text-ink-faint">MB</span>
              </div>
              <div>
                <label class="input-label">허용 파일 형식</label>
                <input v-model="site.allowed_file_types" type="text" class="input-field" placeholder="jpg,png,gif,pdf,doc" />
                <p class="text-xs text-ink-faint mt-1">쉼표로 구분하여 입력하세요</p>
              </div>
            </div>
          </div>

          <div class="border-t border-gray-100 pt-6 mb-6">
            <h3 class="text-sm font-semibold text-ink-muted uppercase tracking-wide mb-4">점검 모드</h3>
            <ToggleRow v-model="site.maintenance_mode" label="점검 모드" desc="사이트를 점검 모드로 전환합니다" />
            <div v-if="site.maintenance_mode" class="mt-4 space-y-3">
              <div>
                <label class="input-label">점검 안내 문구</label>
                <textarea v-model="site.maintenance_reason" rows="2" class="input-field resize-none" placeholder="현재 시스템 점검 중입니다. 잠시 후 다시 이용해 주세요."></textarea>
              </div>
              <div>
                <label class="input-label">점검 종료 예정시각</label>
                <input v-model="site.maintenance_until" type="datetime-local" class="input-field" />
              </div>
            </div>
          </div>

          <div class="flex justify-end">
            <button @click="saveSite" :disabled="saving" class="btn-primary">
              <span v-if="saving" class="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></span>
              저장하기
            </button>
          </div>
        </div>
      </div>

      <!-- ========================= TAB: 메뉴 관리 ========================= -->
      <div v-if="activeTab === 'menus'">
        <div class="flex items-center justify-between mb-5">
          <div>
            <h2 class="text-base font-semibold text-ink">네비게이션 메뉴 관리</h2>
            <p class="text-xs text-ink-faint mt-0.5">순서, 표시여부, 로그인/관리자 권한을 한 곳에서 설정하세요</p>
          </div>
          <button @click="saveMenus" :disabled="menuSaving"
            class="btn-primary">
            {{ menuSaving ? '저장 중...' : '저장' }}
          </button>
        </div>

        <!-- 통계 -->
        <div class="grid grid-cols-3 gap-4 mb-6 ss-keep">
          <div class="bg-blue-50 rounded-xl p-4 text-center">
            <div class="text-2xl font-black text-blue-600">{{ menuList.filter(m => m.enabled).length }}</div>
            <div class="text-xs text-blue-400">활성 메뉴</div>
          </div>
          <div class="bg-gray-50 rounded-xl p-4 text-center">
            <div class="text-2xl font-black text-ink-muted">{{ menuList.filter(m => !m.enabled).length }}</div>
            <div class="text-xs text-ink-faint">비활성 메뉴</div>
          </div>
          <div class="bg-red-50 rounded-xl p-4 text-center">
            <div class="text-2xl font-black text-red-500">{{ menuList.filter(m => m.login_required).length }}</div>
            <div class="text-xs text-red-400">로그인 필요</div>
          </div>
        </div>

        <!-- 휴대폰: 메뉴 한 개를 카드 한 장으로 (PC 의 가로 표는 폰에서 깨져서) -->
        <div v-if="isMobile" class="space-y-2.5">
          <div v-for="(item, idx) in menuList" :key="item.key" class="bg-white border border-gray-100 rounded-2xl p-3">
            <div class="flex items-center gap-2">
              <span class="icon-chip w-9 h-9 flex-shrink-0" :class="menuChipColor(item.key)"><AppIcon :name="menuIcon(item.key)" :size="17" /></span>
              <input v-model="item.label" type="text" maxlength="20" placeholder="메뉴 이름" :aria-label="'메뉴 이름 ' + item.key" class="flex-1 min-w-0 rounded-xl border border-gray-200 px-3 font-semibold text-ink" />
              <span class="shrink-0 text-[11px] text-ink-faint font-mono">{{ idx + 1 }}</span>
            </div>
            <div class="flex items-center gap-2 mt-2">
              <button @click="moveMenu(idx, -1)" :disabled="idx === 0" class="w-11 h-11 rounded-xl border border-gray-200 flex items-center justify-center disabled:opacity-25" aria-label="위로"><AppIcon name="chevron-up" :size="18" /></button>
              <button @click="moveMenu(idx, 1)" :disabled="idx === menuList.length - 1" class="w-11 h-11 rounded-xl border border-gray-200 flex items-center justify-center disabled:opacity-25" aria-label="아래로"><AppIcon name="chevron-down" :size="18" /></button>
              <span class="text-[11px] text-ink-faint font-mono truncate">{{ item.key }}</span>
              <label class="ml-auto flex items-center gap-2 text-[14px] font-bold text-ink min-h-[44px]">표시
                <button type="button" role="switch" :aria-checked="!!item.enabled" @click="item.enabled = !item.enabled" class="relative shrink-0 w-[54px] h-[32px] rounded-full transition-colors" :class="item.enabled ? 'bg-emerald-500' : 'bg-gray-300'"><span class="absolute top-[4px] w-6 h-6 bg-white rounded-full shadow transition-all" :class="item.enabled ? 'left-[26px]' : 'left-[4px]'"></span></button>
              </label>
            </div>
            <div class="grid grid-cols-2 gap-x-3 gap-y-1 mt-1 ss-keep">
              <label class="flex items-center gap-2 min-h-[44px] text-[14px] text-ink"><input type="checkbox" v-model="item.login_required" /> 로그인 필요</label>
              <label class="flex items-center gap-2 min-h-[44px] text-[14px] text-ink"><input type="checkbox" v-model="item.admin_only" /> 관리자만</label>
              <label class="flex items-center gap-2 text-[14px] text-ink"><span class="shrink-0">기본 보기</span>
                <select v-model="item.defaultView" class="flex-1 min-w-0 rounded-xl border border-gray-200 px-2 bg-white"><option value="list">☰ 목록</option><option value="card">⊞ 카드</option></select></label>
              <div class="flex items-center gap-2"><label class="flex items-center gap-2 min-h-[44px] text-[14px] text-ink"><input type="checkbox" v-model="item.ads_enabled" /> 광고</label>
                <select v-if="item.ads_enabled" v-model="item.ads_type" class="flex-1 min-w-0 rounded-xl border border-gray-200 px-2 bg-white"><option value="banner">일반</option><option value="adsense">애드센스</option></select></div>
            </div>
          </div>
        </div>

        <!-- 헤더 행 -->
        <div v-if="!isMobile" class="flex items-center gap-3 px-4 py-2 text-xs text-ink-faint font-medium border-b border-gray-100 mb-2">
          <span class="w-6 text-center">#</span>
          <span class="w-7"></span>
          <span class="flex-1">메뉴</span>
          <span class="w-14 hidden sm:inline"></span>
          <span class="w-16 text-center">순서</span>
          <span class="w-16 text-center">로그인</span>
          <span class="w-16 text-center">관리자</span>
          <span class="w-14 text-center">뷰</span>
          <span class="w-28 text-center">광고</span>
          <span class="w-12 text-center">표시</span>
        </div>

        <div v-if="!isMobile" class="space-y-2">
          <div v-for="(item, idx) in menuList" :key="item.key"
            class="flex items-center gap-3 card px-4 py-3 hover:shadow-lift transition-all">
            <span class="w-6 text-center text-xs font-bold text-ink-faint">{{ idx + 1 }}</span>
            <span class="icon-chip w-7 h-7 flex-shrink-0" :class="menuChipColor(item.key)"><AppIcon :name="menuIcon(item.key)" :size="15" /></span>
            <input v-model="item.label" type="text" maxlength="20" placeholder="메뉴 이름"
              class="flex-1 min-w-0 text-sm font-semibold text-ink bg-transparent border border-transparent hover:border-gray-200 focus:border-amber-400 focus:bg-white rounded-lg px-2 py-1 outline-none transition-colors" />
            <span class="text-xs text-ink-faint font-mono bg-gray-50 px-2 py-0.5 rounded hidden sm:inline">{{ item.key }}</span>
            <!-- Up/Down -->
            <div class="flex gap-1">
              <button @click="moveMenu(idx, -1)" :disabled="idx === 0"
                class="w-7 h-7 rounded-lg border border-gray-200 flex items-center justify-center text-ink-muted hover:bg-amber-50 hover:text-amber-600 disabled:opacity-20 transition-colors"><AppIcon name="chevron-up" :size="14" /></button>
              <button @click="moveMenu(idx, 1)" :disabled="idx === menuList.length - 1"
                class="w-7 h-7 rounded-lg border border-gray-200 flex items-center justify-center text-ink-muted hover:bg-amber-50 hover:text-amber-600 disabled:opacity-20 transition-colors"><AppIcon name="chevron-down" :size="14" /></button>
            </div>
            <!-- Login required -->
            <label class="flex items-center gap-1 text-xs text-ink-muted cursor-pointer" title="로그인 필요">
              <input type="checkbox" v-model="item.login_required" class="rounded border-gray-300 text-amber-500 focus:ring-amber-400" />
              <span class="hidden lg:inline">로그인</span>
            </label>
            <!-- Admin only -->
            <label class="flex items-center gap-1 text-xs text-ink-muted cursor-pointer" title="관리자만">
              <input type="checkbox" v-model="item.admin_only" class="rounded border-gray-300 text-red-600 focus:ring-red-500" />
              <span class="hidden lg:inline">관리자</span>
            </label>
            <!-- 기본 뷰 -->
            <select v-model="item.defaultView" class="text-[11px] border border-gray-200 rounded-lg px-1 py-0.5 text-ink-muted w-14" title="기본 보기">
              <option value="list">☰</option>
              <option value="card">⊞</option>
            </select>
            <!-- 광고 — 이 페이지에 광고를 띄울지, 띄운다면 일반 배너 광고인지 애드센스인지 -->
            <div class="w-28 flex items-center justify-center gap-1">
              <label class="flex items-center gap-1 text-xs text-ink-muted cursor-pointer" title="이 페이지에 광고 표시">
                <input type="checkbox" v-model="item.ads_enabled" class="rounded border-gray-300 text-amber-500 focus:ring-amber-400" />
              </label>
              <select v-if="item.ads_enabled" v-model="item.ads_type" class="text-[11px] border border-gray-200 rounded-lg px-1 py-0.5 text-ink-muted" title="광고 종류">
                <option value="banner">일반 광고</option>
                <option value="adsense">애드센스</option>
              </select>
            </div>
            <!-- Enable toggle -->
            <label class="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" v-model="item.enabled" class="sr-only peer" />
              <div class="w-10 h-5 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-400"></div>
            </label>
          </div>
        </div>

        <div class="mt-4 flex justify-between items-center">
          <button @click="resetMenuOrder"
            class="btn-secondary text-xs">
            <AppIcon name="refresh" :size="13" />기본 순서로 리셋
          </button>
          <button @click="saveMenus" :disabled="menuSaving" class="btn-primary">
            {{ menuSaving ? '저장 중...' : '메뉴 설정 저장' }}
          </button>
        </div>
      </div>

      <!-- ========================= TAB 3: 푸터 편집 ========================= -->
      <div v-show="activeTab === 'footer'">
        <div class="card p-6 mb-4">
          <h2 class="text-base font-semibold text-ink mb-6">푸터 편집</h2>

          <p class="text-xs text-ink-muted mb-4">사이트 맨 아래 푸터와 같은 모양이에요. 첫 칸은 로고 + 소개 문구, 그 옆으로 아래 섹션들이 나란히 표시돼요. 저장하면 바로 사이트에 반영돼요.</p>
          <div class="mb-5">
            <label class="input-label">로고 아래 소개 문구</label>
            <input v-model="footer.tagline" type="text" class="input-field" placeholder="미국 한인 No.1 커뮤니티" />
          </div>

          <!-- Footer columns -->
          <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div v-for="(col, ci) in footer.columns" :key="ci" class="border border-gray-100 rounded-xl p-4">
              <div class="flex items-center justify-between mb-3">
                <input v-model="col.title" type="text" class="input-field text-sm font-medium" placeholder="섹션 제목" />
              </div>
              <div class="space-y-2 mb-3">
                <div v-for="(link, li) in col.links" :key="li" class="flex items-center gap-2">
                  <input v-model="link.label" type="text" class="input-field text-xs flex-1" placeholder="링크 텍스트" />
                  <input v-model="link.url" type="text" class="input-field text-xs flex-1" placeholder="URL" />
                  <button @click="removeFooterLink(ci, li)" class="text-red-400 hover:text-red-600 flex-shrink-0 text-lg leading-none">&times;</button>
                </div>
              </div>
              <button @click="addFooterLink(ci)" class="text-xs text-amber-600 hover:text-amber-700 font-medium transition-colors">+ 링크 추가</button>
            </div>
          </div>

          <!-- Copyright -->
          <div class="mb-5">
            <label class="input-label">저작권 문구</label>
            <input v-model="footer.copyright" type="text" class="input-field" placeholder="© 2024 AwesomeKorean Inc. All rights reserved." />
          </div>

          <!-- SNS Links -->
          <div class="mb-5">
            <h3 class="text-sm font-semibold text-ink-muted mb-3">SNS 링크</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div class="flex items-center gap-2">
                <span class="text-sm text-ink-muted w-24 flex-shrink-0">Facebook</span>
                <input v-model="footer.sns.facebook" type="text" class="input-field text-sm flex-1" placeholder="https://facebook.com/..." />
              </div>
              <div class="flex items-center gap-2">
                <span class="text-sm text-ink-muted w-24 flex-shrink-0">Instagram</span>
                <input v-model="footer.sns.instagram" type="text" class="input-field text-sm flex-1" placeholder="https://instagram.com/..." />
              </div>
              <div class="flex items-center gap-2">
                <span class="text-sm text-ink-muted w-24 flex-shrink-0">Twitter/X</span>
                <input v-model="footer.sns.twitter" type="text" class="input-field text-sm flex-1" placeholder="https://twitter.com/..." />
              </div>
              <div class="flex items-center gap-2">
                <span class="text-sm text-ink-muted w-24 flex-shrink-0">YouTube</span>
                <input v-model="footer.sns.youtube" type="text" class="input-field text-sm flex-1" placeholder="https://youtube.com/..." />
              </div>
              <div class="flex items-center gap-2">
                <span class="text-sm text-ink-muted w-24 flex-shrink-0">KakaoTalk</span>
                <input v-model="footer.sns.kakao" type="text" class="input-field text-sm flex-1" placeholder="카카오 채널 URL" />
              </div>
            </div>
          </div>

          <!-- Additional Text -->
          <div class="mb-6">
            <label class="input-label">하단 추가 텍스트</label>
            <textarea v-model="footer.additional_text" rows="3" class="input-field resize-none text-sm" placeholder="사업자등록번호, 통신판매업 신고번호 등 법적 고지사항..."></textarea>
          </div>

          <div class="flex justify-end">
            <button @click="saveFooter" :disabled="saving" class="btn-primary">
              <span v-if="saving" class="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></span>
              저장하기
            </button>
          </div>
        </div>

        <!-- Live Footer Preview -->
        <div class="bg-gray-800 rounded-xl overflow-hidden">
          <div class="px-5 py-3 bg-gray-700 flex items-center gap-2">
            <div class="w-3 h-3 rounded-full bg-red-400"></div>
            <div class="w-3 h-3 rounded-full bg-yellow-400"></div>
            <div class="w-3 h-3 rounded-full bg-green-400"></div>
            <span class="text-gray-300 text-xs ml-2">푸터 미리보기</span>
          </div>
          <footer class="px-8 py-10 text-gray-400 text-sm">
            <div class="grid gap-8 mb-8" :style="{ gridTemplateColumns: `repeat(${footer.columns.length + 1}, minmax(0, 1fr))` }">
              <div>
                <img v-if="company.logo_dark_url" :src="company.logo_dark_url" alt="AwesomeKorean" class="h-7 w-auto mb-2" />
                <div v-else class="text-amber-400 font-black text-sm mb-2">AwesomeKorean</div>
                <div class="text-xs text-gray-400">{{ footer.tagline }}</div>
              </div>
              <div v-for="(col, ci) in footer.columns" :key="ci">
                <h4 class="text-white font-semibold mb-3">{{ col.title || '섹션명' }}</h4>
                <ul class="space-y-1.5">
                  <li v-for="(link, li) in col.links" :key="li">
                    <a href="#" class="hover:text-white transition-colors text-xs">{{ link.label || '링크' }}</a>
                  </li>
                  <li v-if="col.links.length === 0" class="text-xs text-gray-600">링크를 추가하세요</li>
                </ul>
              </div>
            </div>
            <div class="border-t border-gray-700 pt-6 flex flex-col md:flex-row items-center justify-between gap-4">
              <p class="text-xs">{{ footer.copyright || '© 2024 AwesomeKorean Inc.' }}</p>
              <div class="flex items-center gap-3">
                <span v-if="footer.sns.facebook" class="text-xs hover:text-white cursor-pointer">Facebook</span>
                <span v-if="footer.sns.instagram" class="text-xs hover:text-white cursor-pointer">Instagram</span>
                <span v-if="footer.sns.twitter" class="text-xs hover:text-white cursor-pointer">Twitter</span>
                <span v-if="footer.sns.youtube" class="text-xs hover:text-white cursor-pointer">YouTube</span>
                <span v-if="footer.sns.kakao" class="text-xs hover:text-white cursor-pointer">KakaoTalk</span>
              </div>
            </div>
            <p v-if="footer.additional_text" class="text-xs text-gray-600 mt-4">{{ footer.additional_text }}</p>
          </footer>
        </div>
      </div>

      <!-- ========================= TAB 4: 약관 관리 ========================= -->
      <div v-show="activeTab === 'terms'">
        <div class="card p-6">
          <h2 class="text-base font-semibold text-ink mb-5">약관 관리</h2>

          <!-- Sub tabs -->
          <div class="flex gap-1 mb-6 border-b border-gray-200">
            <button
              v-for="st in termsTabs"
              :key="st.key"
              @click="activeTermsTab = st.key"
              :class="[
                'px-5 py-2.5 text-sm font-medium border-b-2 -mb-px transition-colors',
                activeTermsTab === st.key
                  ? 'border-amber-500 text-amber-700'
                  : 'border-transparent text-ink-muted hover:text-ink-light'
              ]"
            >
              {{ st.label }}
            </button>
          </div>

          <!-- v-show 대신 v-if 사용 — v-for 안에서 v-show로 탭을 토글하면
               버튼 쪽 활성 표시(activeTermsTab 비교)는 제대로 바뀌는데도
               이 div의 실제 표시 여부(el.style.display)는 최초 렌더 상태에
               그대로 고정돼버려서, 탭을 바꿔도 항상 처음 탭(이용약관)
               내용만 보이고 거기에 입력한 게 다른 탭에도 그대로 반영되는
               것처럼 보이던 버그였음(실제로는 두 탭 다 같은 div가 계속
               보이고 있었을 뿐). template로 감싸고 v-if로 바꿔서 탭 전환마다
               해당 div를 새로 만들도록 함. -->
          <template v-for="st in termsTabs" :key="st.key">
          <div v-if="activeTermsTab === st.key">
            <!-- Toolbar -->
            <div class="flex items-center gap-1 mb-2 p-1 bg-gray-50 border border-gray-100 rounded-xl">
              <button @click="formatText(st.key, 'bold')" class="toolbar-btn font-bold">B</button>
              <button @click="formatText(st.key, 'italic')" class="toolbar-btn italic">I</button>
              <div class="w-px h-5 bg-gray-300 mx-1"></div>
              <button @click="formatText(st.key, 'h2')" class="toolbar-btn">H2</button>
              <button @click="formatText(st.key, 'h3')" class="toolbar-btn">H3</button>
              <div class="w-px h-5 bg-gray-300 mx-1"></div>
              <button @click="formatText(st.key, 'list')" class="toolbar-btn">&#8801;</button>
              <button @click="formatText(st.key, 'link')" class="toolbar-btn">&#128279;</button>
              <div class="ml-auto text-xs text-ink-faint">{{ termsContent[st.key]?.length || 0 }}자</div>
            </div>

            <textarea
              :ref="el => termsRef[st.key] = el"
              v-model="termsContent[st.key]"
              rows="16"
              class="input-field resize-none font-mono text-sm"
              :placeholder="`${st.label} 내용을 입력하세요...`"
            ></textarea>

            <div class="flex items-center justify-between mt-3">
              <span class="text-xs text-ink-faint">
                마지막 수정: {{ termsLastUpdated[st.key] || '미정' }}
              </span>
              <button @click="saveTerms(st.key)" :disabled="saving" class="btn-primary">
                <span v-if="saving" class="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></span>
                저장하기
              </button>
            </div>

            <!-- Version History -->
            <div class="mt-6 border-t border-gray-100 pt-5">
              <h3 class="text-sm font-semibold text-ink-light mb-3">버전 히스토리</h3>
              <div v-if="termsHistory[st.key]?.length" class="space-y-2">
                <div
                  v-for="(version, vi) in termsHistory[st.key]"
                  :key="vi"
                  class="flex items-center justify-between py-2 px-3 bg-gray-50 rounded-lg"
                >
                  <div>
                    <span class="text-sm text-ink-light font-medium">v{{ version.version }}</span>
                    <span class="text-xs text-ink-faint ml-2">{{ version.date }}</span>
                    <span class="text-xs text-ink-muted ml-2">{{ version.summary }}</span>
                  </div>
                  <button @click="restoreVersion(st.key, version)" class="btn-soft px-3 py-1 text-xs">
                    복원
                  </button>
                </div>
              </div>
              <div v-else class="text-sm text-ink-muted py-4 text-center">버전 히스토리가 없습니다.</div>
            </div>
          </div>
          </template>
        </div>
      </div>

      <!-- ========================= TAB 5: 결제/알림 설정 ========================= -->
      <div v-show="activeTab === 'notifications'">

        <!-- Stripe 결제 키 설정 -->
        <div class="card p-6 mb-4">
          <div class="flex items-center justify-between mb-5">
            <div class="flex items-center gap-3">
              <div class="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                <span class="text-lg font-bold text-indigo-600">S</span>
              </div>
              <div>
                <h2 class="text-base font-semibold text-ink">Stripe API 키 설정</h2>
                <p class="text-xs text-ink-faint">결제 처리를 위한 Stripe API 키 관리</p>
              </div>
            </div>
            <span :class="[
              payment.stripe_publishable_key ? 'badge-green' : 'badge-red'
            ]">
              {{ payment.stripe_publishable_key ? 'API 키 설정됨' : '미설정' }}
            </span>
          </div>

          <!-- 테스트/라이브 모드 토글 -->
          <div class="flex items-center gap-4 mb-5 p-3 bg-gray-50 rounded-xl">
            <span class="text-sm text-ink-light font-medium">결제 모드:</span>
            <label class="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" v-model="payment.stripe_test_mode" class="sr-only peer" />
              <div class="w-11 h-6 bg-green-500 peer-checked:bg-yellow-400 rounded-full transition-colors after:content-[''] after:absolute after:top-0.5 after:left-[2px] peer-checked:after:translate-x-full after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all"></div>
            </label>
            <span :class="[
              payment.stripe_test_mode ? 'badge-primary' : 'badge-green'
            ]">
              {{ payment.stripe_test_mode ? '테스트 모드' : '라이브 (실결제)' }}
            </span>
          </div>

          <!-- Stripe API 키 입력 -->
          <div class="space-y-4 mb-5">
            <div>
              <label class="input-label">Publishable Key</label>
              <input
                v-model="payment.stripe_publishable_key"
                type="text"
                class="input-field font-mono text-sm"
                :placeholder="payment.stripe_test_mode ? 'pk_test_...' : 'pk_live_...'"
              />
              <p class="text-xs text-ink-faint mt-1">프론트엔드에서 사용되는 공개 키입니다</p>
            </div>
            <div>
              <label class="input-label">Secret Key</label>
              <div class="relative">
                <input
                  v-model="payment.stripe_secret_key"
                  :type="showStripeSecret ? 'text' : 'password'"
                  class="input-field font-mono text-sm pr-20"
                  :placeholder="payment.stripe_test_mode ? 'sk_test_...' : 'sk_live_...'"
                />
                <button
                  type="button"
                  @click="showStripeSecret = !showStripeSecret"
                  class="absolute right-2 top-1/2 -translate-y-1/2 text-xs text-ink-muted hover:text-ink px-2 py-1 rounded transition-colors"
                >
                  {{ showStripeSecret ? '숨기기' : '보기' }}
                </button>
              </div>
              <p class="text-xs text-ink-faint mt-1">서버에서 사용되는 비밀 키입니다 (절대 노출하지 마세요)</p>
            </div>
            <div>
              <label class="input-label">Webhook Secret <span class="text-ink-faint">(선택)</span></label>
              <input
                v-model="payment.stripe_webhook_secret"
                type="password"
                class="input-field font-mono text-sm"
                placeholder="whsec_..."
              />
              <p class="text-xs text-ink-faint mt-1">Webhook 이벤트 검증용 (설정 시 보안 강화)</p>
            </div>
          </div>

          <div class="flex justify-end">
            <button @click="saveStripeKeys" :disabled="savingStripe" class="btn-primary">
              <span v-if="savingStripe" class="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></span>
              Stripe 키 저장
            </button>
          </div>
        </div>

        <!-- 결제 일반 설정 -->
        <div class="card p-6 mb-4">
          <div class="flex items-center justify-between mb-5">
            <h2 class="text-base font-semibold text-ink">결제 시스템 연결</h2>
            <span :class="[
              payment.stripe_connected ? 'badge-green' : 'badge-red'
            ]">
              {{ payment.stripe_connected ? '연결됨' : '미연결' }}
            </span>
          </div>

          <!-- Stripe 연동 상태 -->
          <div class="border border-gray-100 rounded-xl p-4 mb-5">
            <div class="flex items-center justify-between mb-3">
              <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                  <span class="text-lg font-bold text-indigo-600">S</span>
                </div>
                <div>
                  <p class="text-sm font-semibold text-ink">Stripe</p>
                  <p class="text-xs text-ink-faint">결제 처리 서비스</p>
                </div>
              </div>
              <a href="/admin/payments" class="inline-flex items-center gap-1 px-4 py-2 bg-indigo-500 hover:bg-indigo-600 text-white text-sm font-medium rounded-lg transition-colors">
                {{ payment.stripe_connected ? 'Stripe 설정 변경' : 'Stripe 연동하기' }}
                <span class="text-xs">&rarr;</span>
              </a>
            </div>

            <!-- 결제 모드 -->
            <div class="flex items-center gap-4 mt-3 pt-3 border-t border-gray-100">
              <span class="text-sm text-ink-light">결제 모드:</span>
              <span :class="[
                payment.mode === 'live' ? 'badge-green' : 'badge-primary'
              ]">
                {{ payment.mode === 'live' ? '라이브 (실결제)' : '테스트 모드' }}
              </span>
            </div>
          </div>

          <!-- 결제 수단 현황 -->
          <div class="mb-5">
            <h3 class="text-sm font-semibold text-ink-muted mb-3">결제 수단 현황</h3>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div class="flex items-center justify-between border border-gray-100 rounded-xl p-3">
                <div class="flex items-center gap-2">
                  <span class="text-lg">&#128179;</span>
                  <span class="text-sm text-ink-light">카드 결제</span>
                </div>
                <span :class="[payment.card_enabled ? 'badge-green' : 'badge-gray']">
                  {{ payment.card_enabled ? '활성' : '비활성' }}
                </span>
              </div>
              <div class="flex items-center justify-between border border-gray-100 rounded-xl p-3">
                <div class="flex items-center gap-2">
                  <span class="text-lg">&#127822;</span>
                  <span class="text-sm text-ink-light">Apple Pay</span>
                </div>
                <span :class="[payment.apple_pay_enabled ? 'badge-green' : 'badge-gray']">
                  {{ payment.apple_pay_enabled ? '활성' : '비활성' }}
                </span>
              </div>
              <div class="flex items-center justify-between border border-gray-100 rounded-xl p-3">
                <div class="flex items-center gap-2">
                  <span class="text-lg">G</span>
                  <span class="text-sm text-ink-light">Google Pay</span>
                </div>
                <span :class="[payment.google_pay_enabled ? 'badge-green' : 'badge-gray']">
                  {{ payment.google_pay_enabled ? '활성' : '비활성' }}
                </span>
              </div>
            </div>
          </div>

          <!-- 최소 결제금액 / 통화 설정 -->
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-5">
            <div>
              <label class="input-label">최소 결제금액</label>
              <div class="flex items-center gap-2">
                <input v-model.number="payment.min_amount" type="number" min="0" step="0.01" class="input-field w-32" />
                <span class="text-sm text-ink-muted">{{ payment.currency }}</span>
              </div>
            </div>
            <div>
              <label class="input-label">기본 통화</label>
              <select v-model="payment.currency" class="input-field">
                <option value="USD">USD (미국 달러)</option>
                <option value="KRW">KRW (한국 원)</option>
                <option value="EUR">EUR (유로)</option>
                <option value="JPY">JPY (일본 엔)</option>
              </select>
            </div>
          </div>

          <!-- 이번달 결제 요약 -->
          <div class="bg-gray-50 rounded-xl p-4">
            <h3 class="text-sm font-semibold text-ink-muted mb-3">이번달 결제 요약</h3>
            <div class="grid grid-cols-2 gap-4">
              <div class="bg-white rounded-xl p-3 border border-gray-100">
                <p class="text-xs text-ink-muted mb-1">총 결제 금액</p>
                <p class="text-lg font-bold text-ink">
                  {{ payment.currency === 'USD' ? '$' : '' }}{{ payment.this_month_total.toLocaleString() }}
                  <span v-if="payment.currency !== 'USD'" class="text-sm font-normal text-ink-muted">{{ payment.currency }}</span>
                </p>
              </div>
              <div class="bg-white rounded-xl p-3 border border-gray-100">
                <p class="text-xs text-ink-muted mb-1">결제 성공률</p>
                <p class="text-lg font-bold" :class="payment.this_month_success_rate >= 90 ? 'text-green-600' : payment.this_month_success_rate >= 70 ? 'text-yellow-600' : 'text-red-600'">
                  {{ payment.this_month_success_rate }}%
                </p>
              </div>
            </div>
          </div>

          <div class="mt-4 flex justify-end">
            <button @click="savePayment" :disabled="saving" class="btn-primary">
              <span v-if="saving" class="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></span>
              결제 설정 저장
            </button>
          </div>
        </div>

        <!-- 시스템 공지사항 -->
        <div class="card p-6 mb-4">
          <div class="flex items-center justify-between mb-5">
            <h2 class="text-base font-semibold text-ink">시스템 공지사항</h2>
            <button @click="showAnnouncementForm = !showAnnouncementForm" class="btn-secondary text-sm">
              {{ showAnnouncementForm ? '취소' : '+ 새 공지 추가' }}
            </button>
          </div>

          <!-- New Announcement Form -->
          <div v-if="showAnnouncementForm" class="border border-amber-100 bg-amber-50 rounded-xl p-5 mb-5">
            <h3 class="text-sm font-semibold text-ink-light mb-4">새 공지사항</h3>
            <div class="grid grid-cols-1 gap-4">
              <div>
                <label class="input-label">제목</label>
                <input v-model="newAnnouncement.title" type="text" class="input-field" placeholder="공지사항 제목" />
              </div>
              <div>
                <label class="input-label">내용</label>
                <textarea v-model="newAnnouncement.content" rows="3" class="input-field resize-none" placeholder="공지사항 내용..."></textarea>
              </div>
              <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label class="input-label">시작 날짜</label>
                  <input v-model="newAnnouncement.start_date" type="date" class="input-field" />
                </div>
                <div>
                  <label class="input-label">종료 날짜</label>
                  <input v-model="newAnnouncement.end_date" type="date" class="input-field" />
                </div>
                <div>
                  <label class="input-label">표시 위치</label>
                  <select v-model="newAnnouncement.display_position" class="input-field">
                    <option value="all">전체</option>
                    <option value="home">홈</option>
                    <option value="specific">특정 메뉴</option>
                  </select>
                </div>
              </div>
              <div class="flex items-center gap-3">
                <ToggleRow v-model="newAnnouncement.active" label="활성화" desc="" />
              </div>
            </div>
            <div class="mt-4 flex justify-end gap-2">
              <button @click="showAnnouncementForm = false" class="btn-secondary">취소</button>
              <button @click="addAnnouncement" class="btn-primary">추가</button>
            </div>
          </div>

          <!-- Announcements List -->
          <div v-if="notifications.announcements.length" class="space-y-2">
            <div
              v-for="(ann, ai) in notifications.announcements"
              :key="ai"
              class="border border-gray-100 rounded-xl p-4"
            >
              <div v-if="editingAnnouncement === ai">
                <!-- Edit mode -->
                <div class="grid grid-cols-1 gap-3">
                  <input v-model="ann.title" type="text" class="input-field text-sm" />
                  <textarea v-model="ann.content" rows="2" class="input-field resize-none text-sm"></textarea>
                  <div class="grid grid-cols-3 gap-2">
                    <input v-model="ann.start_date" type="date" class="input-field text-xs" />
                    <input v-model="ann.end_date" type="date" class="input-field text-xs" />
                    <select v-model="ann.display_position" class="input-field text-xs">
                      <option value="all">전체</option>
                      <option value="home">홈</option>
                      <option value="specific">특정 메뉴</option>
                    </select>
                  </div>
                  <div class="flex justify-end gap-2">
                    <button @click="editingAnnouncement = null" class="btn-secondary text-xs">취소</button>
                    <button @click="editingAnnouncement = null" class="btn-primary text-xs">저장</button>
                  </div>
                </div>
              </div>
              <div v-else class="flex items-start justify-between">
                <div class="flex-1 min-w-0">
                  <div class="flex items-center gap-2 mb-1">
                    <span :class="['inline-block w-2 h-2 rounded-full', ann.active ? 'bg-green-400' : 'bg-gray-300']"></span>
                    <span class="text-sm font-medium text-ink truncate">{{ ann.title }}</span>
                    <span class="badge-gray !text-[11px]">{{ positionLabel(ann.display_position) }}</span>
                  </div>
                  <p class="text-xs text-ink-muted truncate">{{ ann.content }}</p>
                  <p class="text-xs text-ink-faint mt-1">{{ ann.start_date }} ~ {{ ann.end_date }}</p>
                </div>
                <div class="flex items-center gap-2 ml-3 flex-shrink-0">
                  <button @click="editingAnnouncement = ai" class="text-xs text-amber-600 hover:text-amber-700 transition-colors">수정</button>
                  <button @click="removeAnnouncement(ai)" class="text-xs text-red-400 hover:text-red-600 transition-colors">삭제</button>
                </div>
              </div>
            </div>
          </div>
          <div v-else class="text-sm text-ink-muted py-6 text-center">등록된 공지사항이 없습니다.</div>
        </div>

        <!-- 이메일 알림 설정 -->
        <div class="card p-6 mb-4">
          <h2 class="text-base font-semibold text-ink mb-5">이메일 알림 설정</h2>
          <ToggleRow v-model="notifications.email.enabled" label="알림 이메일 활성화" desc="관리자에게 이메일 알림을 전송합니다" class="mb-4" />
          <div :class="['space-y-3 transition-opacity', notifications.email.enabled ? 'opacity-100' : 'opacity-40 pointer-events-none']">
            <div>
              <label class="input-label">신규 가입 알림 수신 이메일</label>
              <input v-model="notifications.email.new_user" type="email" class="input-field" placeholder="admin@awesomekorean.com" />
            </div>
            <div>
              <label class="input-label">신고 접수 알림 수신 이메일</label>
              <input v-model="notifications.email.report" type="email" class="input-field" placeholder="admin@awesomekorean.com" />
            </div>
            <div>
              <label class="input-label">결제 알림 수신 이메일</label>
              <input v-model="notifications.email.payment" type="email" class="input-field" placeholder="billing@awesomekorean.com" />
            </div>
          </div>
        </div>

        <!-- 푸시 알림 설정 -->
        <div class="card p-6 mb-4">
          <h2 class="text-base font-semibold text-ink mb-5">푸시 알림 설정 (VAPID)</h2>
          <div class="space-y-4">
            <div>
              <label class="input-label">VAPID Public Key</label>
              <div class="flex gap-2">
                <input v-model="notifications.push.vapid_public" type="text" class="input-field flex-1 font-mono text-xs" placeholder="BFHtE3h..." readonly />
              </div>
            </div>
            <div>
              <label class="input-label">VAPID Private Key</label>
              <input
                v-model="notifications.push.vapid_private"
                :type="showVapidPrivate ? 'text' : 'password'"
                class="input-field font-mono text-xs"
                placeholder="••••••••"
                readonly
              />
            </div>
            <div class="flex items-center gap-3">
              <button @click="generateVapidKeys" :disabled="generatingKeys" class="btn-secondary flex items-center gap-2">
                <span v-if="generatingKeys" class="inline-block w-4 h-4 border-2 border-gray-400 border-t-transparent rounded-full animate-spin"></span>
                키 생성
              </button>
              <button @click="showVapidPrivate = !showVapidPrivate" class="text-sm text-ink-muted hover:text-ink transition-colors">
                {{ showVapidPrivate ? '숨기기' : '보기' }}
              </button>
              <p class="text-xs text-amber-600">주의: 키를 재생성하면 기존 구독이 모두 해제됩니다.</p>
            </div>
          </div>
        </div>

        <!-- SEO 설정 -->
        <div class="card p-6 mb-4">
          <h2 class="text-base font-semibold text-ink mb-5">SEO 설정</h2>
          <div class="space-y-4">
            <div>
              <label class="input-label">메타 타이틀 기본값</label>
              <input v-model="seo.meta_title" type="text" class="input-field" placeholder="AwesomeKorean - 미국 한인 커뮤니티" />
              <p class="text-xs text-ink-faint mt-1">페이지별 타이틀이 없을 때 사용되는 기본 타이틀</p>
            </div>
            <div>
              <label class="input-label">메타 설명 기본값</label>
              <textarea v-model="seo.meta_description" rows="2" class="input-field resize-none" placeholder="미국 한인 커뮤니티 플랫폼 AwesomeKorean에서 다양한 정보를 나누세요."></textarea>
              <p class="text-xs text-ink-faint mt-1">검색 결과에 표시되는 사이트 설명 (150자 이내 권장)</p>
            </div>
            <div>
              <label class="input-label">Open Graph 이미지 URL</label>
              <div class="flex items-center gap-3">
                <input v-model="seo.og_image" type="text" class="input-field flex-1" placeholder="https://awesomekorean.com/images/og-image.jpg" />
                <div v-if="seo.og_image" class="w-16 h-10 border border-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                  <img :src="seo.og_image" alt="OG Preview" class="w-full h-full object-cover" @error="() => {}" />
                </div>
              </div>
              <p class="text-xs text-ink-faint mt-1">SNS 공유 시 표시되는 대표 이미지 (1200x630px 권장)</p>
            </div>

            <div class="border-t border-gray-100 pt-4">
              <h3 class="text-sm font-semibold text-ink-muted mb-3">사이트 인증</h3>
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label class="input-label">Google Site Verification</label>
                  <input v-model="seo.google_verification" type="text" class="input-field" placeholder="google-site-verification=..." />
                </div>
                <div>
                  <label class="input-label">Naver Site Verification</label>
                  <input v-model="seo.naver_verification" type="text" class="input-field" placeholder="naver-site-verification=..." />
                </div>
              </div>
            </div>

            <div class="border-t border-gray-100 pt-4">
              <label class="input-label">robots.txt 편집</label>
              <textarea v-model="seo.robots_txt" rows="8" class="input-field resize-none font-mono text-xs" placeholder="User-agent: *&#10;Allow: /&#10;Sitemap: https://awesomekorean.com/sitemap.xml"></textarea>
              <p class="text-xs text-ink-faint mt-1">검색 엔진 크롤러 접근 규칙을 설정합니다</p>
            </div>
          </div>

          <div class="mt-4 flex justify-end">
            <button @click="saveSeo" :disabled="saving" class="btn-primary">
              <span v-if="saving" class="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></span>
              SEO 설정 저장
            </button>
          </div>
        </div>

        <div class="flex justify-end">
          <button @click="saveNotifications" :disabled="saving" class="btn-primary">
            <span v-if="saving" class="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></span>
            알림 설정 저장
          </button>
        </div>
      </div>
    </div>

    <!-- API 키 관리 -->
    <div v-if="activeTab === 'api'" class="space-y-6">

      <!-- Firebase Cloud Messaging 설정 -->
      <div class="card p-6">
        <div class="flex items-center justify-between mb-4">
          <h3 class="flex items-center gap-2 text-lg font-bold text-ink"><span class="icon-chip w-8 h-8 bg-orange-50 text-orange-500"><AppIcon name="bell" :size="16" /></span>Firebase Push Notification</h3>
          <span :class="firebaseStatus ? 'badge-green' : 'badge-primary'">
            {{ firebaseStatus ? '연결됨' : '미설정' }}
          </span>
        </div>
        <p class="text-xs text-ink-faint mb-4">안심통화 수신 알림, 백그라운드 푸시, 벨소리에 사용됩니다.</p>

        <div class="space-y-3">
          <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label class="input-label !text-xs">API Key</label>
              <input v-model="firebase.apiKey" type="text" class="input-field font-mono" placeholder="AIzaSy..." />
            </div>
            <div>
              <label class="input-label !text-xs">Project ID</label>
              <input v-model="firebase.projectId" type="text" class="input-field font-mono" placeholder="awesomekorean-xxxxx" />
            </div>
            <div>
              <label class="input-label !text-xs">Messaging Sender ID</label>
              <input v-model="firebase.messagingSenderId" type="text" class="input-field font-mono" placeholder="123456789" />
            </div>
            <div>
              <label class="input-label !text-xs">App ID</label>
              <input v-model="firebase.appId" type="text" class="input-field font-mono" placeholder="1:123:web:abc..." />
            </div>
            <div>
              <label class="input-label !text-xs">Auth Domain</label>
              <input v-model="firebase.authDomain" type="text" class="input-field font-mono" placeholder="xxx.firebaseapp.com" />
            </div>
            <div>
              <label class="input-label !text-xs">Storage Bucket</label>
              <input v-model="firebase.storageBucket" type="text" class="input-field font-mono" placeholder="xxx.appspot.com" />
            </div>
          </div>
          <div>
            <label class="input-label !text-xs">VAPID Key (웹 푸시 인증서)</label>
            <input v-model="firebase.vapidKey" type="text" class="input-field font-mono" placeholder="BA93MT..." />
          </div>
          <div>
            <label class="input-label !text-xs">서비스 계정 JSON (백엔드용 — 서버에 직접 업로드)</label>
            <div class="flex items-center gap-2">
              <code class="text-xs bg-gray-100 px-3 py-2 rounded-lg flex-1 font-mono text-ink-light">{{ firebase.credentialsPath || '/storage/app/firebase-service-account.json' }}</code>
              <span :class="firebase.credentialsExists ? 'text-green-600' : 'text-red-500'" class="text-xs font-medium">{{ firebase.credentialsExists ? '파일 존재' : '파일 없음' }}</span>
            </div>
            <div class="flex items-center gap-2 mt-2 flex-wrap">
              <input ref="credFileInput" type="file" accept=".json,application/json" class="hidden" @change="uploadFirebaseCredentials" />
              <button type="button" @click="credFileInput.click()" :disabled="uploadingCred" class="px-3 py-1.5 rounded-lg border border-gray-200 text-xs font-bold text-ink-light hover:bg-gray-50 disabled:opacity-50">
                {{ uploadingCred ? '올리는 중...' : '📤 서비스 계정 JSON 업로드' }}
              </button>
              <span v-if="firebase.credentialsExists && firebase.credentialsProject" class="text-[11px] text-ink-muted">파일의 프로젝트: <b>{{ firebase.credentialsProject }}</b></span>
              <span v-if="firebase.credentialsProject && firebase.projectId && firebase.credentialsProject !== firebase.projectId" class="text-[11px] text-red-500 font-bold">⚠️ 위 Project ID({{ firebase.projectId }})와 달라요</span>
            </div>
            <p v-if="credMsg" class="text-[11px] mt-1" :class="credOk ? 'text-green-600' : 'text-red-500'">{{ credMsg }}</p>
            <p class="text-[11px] text-ink-faint mt-1">Firebase 콘솔 → 프로젝트 설정 → 서비스 계정 → "새 비공개 키 생성"으로 받은 파일이에요. 비공개 키라서 서버 안쪽 폴더에만 저장되고 화면에는 표시되지 않아요. (최고 관리자만 업로드 가능)</p>
          </div>
          <button @click="saveFirebase" :disabled="savingFirebase" class="btn-primary w-full mt-2">
            {{ savingFirebase ? '저장 중...' : 'Firebase 설정 저장' }}
          </button>
          <p class="text-[11px] text-ink-faint mt-2 leading-relaxed">저장하면 사이트를 다시 만들지 않아도 바로 적용돼요. 회원이 사이트를 열 때 브라우저가 "알림 허용"을 물어보고, 허용하면 새 쪽지·1:1 대화·안심 통화 알림이 휴대폰/PC 알림으로 와요. (한 계정당 가장 최근에 허용한 기기 1대로 보내요)</p>
          <button @click="testFirebasePush" :disabled="testingPush" class="w-full mt-2 py-2.5 rounded-xl border border-gray-200 text-sm font-bold text-ink-light hover:bg-gray-50 disabled:opacity-50">
            {{ testingPush ? '보내는 중...' : '🔔 내 기기로 테스트 알림 보내기' }}
          </button>
          <p v-if="pushTestMsg" class="text-xs mt-2 leading-relaxed" :class="pushTestOk ? 'text-green-600' : 'text-red-500'">{{ pushTestMsg }}</p>
        </div>
      </div>

      <!-- 기존 API 키 관리 -->
      <div class="card p-6">
        <div class="flex items-center justify-between mb-4">
          <h3 class="flex items-center gap-2 text-lg font-bold text-ink"><span class="icon-chip w-8 h-8 bg-amber-50 text-amber-600"><AppIcon name="key" :size="16" /></span>API 키 관리</h3>
          <div class="flex gap-2">
            <button @click="runMailTestSend" class="btn-secondary px-4 py-2 text-sm">테스트 메일 보내기</button>
            <button @click="openAddAnalytics" class="btn-secondary px-4 py-2 text-sm">+ 구글 Analytics</button>
            <button @click="showAddApiKey = true" class="btn-primary px-4 py-2">+ 새 API 키</button>
          </div>
        </div>

        <div class="space-y-3">
          <div v-for="key in apiKeys" :key="key.id" class="border border-gray-100 rounded-xl p-4 flex items-center justify-between">
            <div class="flex-1">
              <div class="flex items-center gap-2">
                <span class="text-sm font-bold text-ink">{{ key.name }}</span>
                <span class="badge-blue !text-[11px]">{{ key.service }}</span>
                <span :class="key.is_active ? 'badge-green' : 'badge-red'" class="!text-[11px]">{{ key.is_active ? '활성' : '비활성' }}</span>
              </div>
              <p v-if="key.description" class="text-xs text-ink-muted mt-1">{{ key.description }}</p>
              <div class="flex items-center gap-2 mt-2">
                <code class="text-xs bg-gray-100 px-2 py-1 rounded-lg font-mono text-ink-light">{{ key.showFull ? key.fullKey : key.masked_key }}</code>
                <button @click="toggleReveal(key)" class="text-xs text-amber-600 hover:underline transition-colors">{{ key.showFull ? '숨기기' : '보기' }}</button>
                <button @click="copyKey(key)" class="text-xs text-ink-muted hover:underline transition-colors">복사</button>
              </div>
            </div>
            <div class="flex gap-2">
              <button @click="openEditApiKey(key)" class="text-xs text-blue-600 hover:underline">수정</button>
              <button @click="toggleApiKeyActive(key)" :class="key.is_active ? 'text-orange-600' : 'text-green-600'" class="text-xs hover:underline">{{ key.is_active ? '비활성화' : '활성화' }}</button>
              <button @click="deleteApiKey(key.id)" class="text-xs text-red-600 hover:underline">삭제</button>
            </div>
          </div>
          <div v-if="!apiKeys.length" class="text-center py-8 text-ink-muted text-sm">등록된 API 키가 없습니다</div>
        </div>
      </div>

      <!-- 새 API 키 추가 모달 -->
      <div v-if="showAddApiKey" class="fixed inset-0 bg-black/50 z-50 flex items-center justify-center" @click.self="showAddApiKey = false">
        <div class="bg-white rounded-2xl p-6 w-full max-w-md">
          <h3 class="flex items-center gap-2 font-bold text-lg text-ink mb-4"><span class="icon-chip w-8 h-8 bg-amber-50 text-amber-600"><AppIcon name="key" :size="16" /></span>새 API 키 등록</h3>
          <div class="space-y-3">
            <div>
              <label class="input-label !text-xs">서비스 이름</label>
              <input v-model="newApiKey.name" placeholder="예: YouTube Data API v3" class="input-field" />
            </div>
            <div>
              <label class="input-label !text-xs">서비스 코드</label>
              <input v-model="newApiKey.service" placeholder="예: youtube, stripe, openai" class="input-field" />
            </div>
            <div>
              <label class="input-label !text-xs">API 키</label>
              <input v-model="newApiKey.api_key" placeholder="키 입력..." class="input-field font-mono" />
            </div>
            <div>
              <label class="input-label !text-xs">설명 (선택)</label>
              <input v-model="newApiKey.description" placeholder="용도 설명" class="input-field" />
            </div>
            <div class="flex gap-2 pt-2">
              <button @click="showAddApiKey = false" class="btn-secondary flex-1 py-2">취소</button>
              <button @click="saveApiKey" class="btn-primary flex-1 py-2">등록</button>
            </div>
          </div>
        </div>
      </div>

      <!-- API 키 수정 모달 -->
      <div v-if="showEditApiKey" class="fixed inset-0 bg-black/50 z-50 flex items-center justify-center" @click.self="showEditApiKey = false">
        <div class="bg-white rounded-2xl p-6 w-full max-w-md">
          <h3 class="flex items-center gap-2 font-bold text-lg text-ink mb-4"><span class="icon-chip w-8 h-8 bg-amber-50 text-amber-600"><AppIcon name="key" :size="16" /></span>API 키 수정</h3>
          <div class="space-y-3">
            <div>
              <label class="input-label !text-xs">서비스 이름</label>
              <input v-model="editApiKey.name" class="input-field" />
            </div>
            <div>
              <label class="input-label !text-xs">서비스 코드</label>
              <input v-model="editApiKey.service" class="input-field" />
            </div>
            <div>
              <label class="input-label !text-xs">API 키</label>
              <input v-model="editApiKey.api_key" placeholder="변경하려면 입력 (비워두면 기존 값 유지)" class="input-field font-mono" />
            </div>
            <div>
              <label class="input-label !text-xs">설명 (선택)</label>
              <input v-model="editApiKey.description" class="input-field" />
            </div>
            <div class="flex gap-2 pt-2">
              <button @click="showEditApiKey = false" class="btn-secondary flex-1 py-2">취소</button>
              <button @click="saveEditApiKey" class="btn-primary flex-1 py-2">저장</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, watch, computed, inject } from 'vue'

// 관리자 휴대폰 화면이면 입력칸/버튼을 손가락에 맞게 키워서 보여 줌 (AdminLayout 이 알려 줌)
const adminIsMobile = inject('adminIsMobile', ref(false))
const isMobile = computed(() => !!adminIsMobile.value)
import axios from 'axios'
import AppIcon from '../../components/AppIcon.vue'
import { menuIcon, menuChipColor } from '../../utils/menuIcons'
import { useSiteStore } from '../../stores/site'
import { DEFAULT_FOOTER, FOOTER_VERSION, readSavedFooter } from '../../utils/footerDefaults'

// ─── Sub-component: Toggle Row ────────────────────────────────────────────────
const ToggleRow = {
  props: ['modelValue', 'label', 'desc'],
  emits: ['update:modelValue'],
  template: `
    <div class="flex items-center justify-between">
      <div>
        <p class="text-sm font-medium text-gray-700">{{ label }}</p>
        <p v-if="desc" class="text-xs text-gray-400">{{ desc }}</p>
      </div>
      <button
        @click="$emit('update:modelValue', !modelValue)"
        :class="['relative inline-flex h-6 w-11 items-center rounded-full transition-colors flex-shrink-0',
          modelValue ? 'bg-blue-500' : 'bg-gray-200']"
      >
        <span :class="['inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform',
          modelValue ? 'translate-x-6' : 'translate-x-1']"></span>
      </button>
    </div>
  `
}

// ─── State ────────────────────────────────────────────────────────────────────
const siteStore = useSiteStore()
const loading = ref(true)
const saving = ref(false)
const generatingKeys = ref(false)
const showVapidPrivate = ref(false)
const showAnnouncementForm = ref(false)
const editingAnnouncement = ref(null)
const activeTab = ref('company')
const activeTermsTab = ref('terms')
const logoError = ref(false)
const lastLoaded = ref('—')
const showStripeSecret = ref(false)
const savingStripe = ref(false)

const tabs = [
  { key: 'company', label: '회사 정보' },
  { key: 'site', label: '사이트 설정' },
  { key: 'menus', label: '메뉴 관리' },
  { key: 'footer', label: '푸터 편집' },
  { key: 'terms', label: '약관 관리' },
  { key: 'notifications', label: '결제/알림 설정' },
  { key: 'api', label: '🔑 API 키 관리' },
]

const termsTabs = [
  { key: 'terms', label: '이용약관' },
  { key: 'privacy', label: '개인정보처리방침' },
]

// ─── Toast ────────────────────────────────────────────────────────────────────
const toast = reactive({ show: false, message: '', type: 'success' })
let toastTimer = null

function showToast(message, type = 'success') {
  clearTimeout(toastTimer)
  toast.message = message
  toast.type = type
  toast.show = true
  toastTimer = setTimeout(() => { toast.show = false }, 3000)
}

// ─── Form Data ────────────────────────────────────────────────────────────────
const company = reactive({
  site_name: 'AwesomeKorean',
  site_subtitle: '미국 한인 커뮤니티',
  company_name: 'AwesomeKorean Inc.',
  ceo_name: '',
  business_number: '',
  address: 'Los Angeles, CA, USA',
  phone: '',
  email: 'admin@awesomekorean.com',
  founded_date: '',
  logo_url: '',
  logo_dark_url: '',
  app_icon_url: '',
  favicon_url: '',
  meta_description: '',
  meta_keywords: '',
})

const site = reactive({
  allow_signup: true,
  require_email_verify: true,
  auto_approve: false,
  allow_withdrawal: true,
  min_password_length: 8,
  max_upload_mb: 10,
  allowed_file_types: 'jpg,png,gif,pdf,doc',
  maintenance_mode: false,
  maintenance_reason: '',
  maintenance_until: '',
})

// 실제 사이트 푸터와 같은 기본값에서 시작 (저장된 값이 있으면 아래 applySettings 가 덮어씀)
const footer = reactive(JSON.parse(JSON.stringify(DEFAULT_FOOTER)))

const termsContent = reactive({ terms: '', privacy: '' })
const termsLastUpdated = reactive({ terms: '', privacy: '' })
const termsHistory = reactive({
  terms: [],
  privacy: [],
})
const termsRef = reactive({ terms: null, privacy: null })

const notifications = reactive({
  announcements: [],
  email: {
    enabled: true,
    new_user: 'admin@awesomekorean.com',
    report: 'admin@awesomekorean.com',
    payment: 'billing@awesomekorean.com',
  },
  push: {
    vapid_public: '',
    vapid_private: '',
  },
})

const newAnnouncement = reactive({
  title: '',
  content: '',
  start_date: '',
  end_date: '',
  display_position: 'all',
  active: true,
})

// ─── Payment Data ─────────────────────────────────────────────────────────────
const payment = reactive({
  stripe_connected: false,
  stripe_publishable_key: '',
  stripe_secret_key: '',
  stripe_webhook_secret: '',
  stripe_test_mode: true,
  mode: 'test',
  card_enabled: true,
  apple_pay_enabled: false,
  google_pay_enabled: false,
  min_amount: 1.00,
  currency: 'USD',
  this_month_total: 2340.00,
  this_month_success_rate: 92.5,
})

// ─── SEO Data ─────────────────────────────────────────────────────────────────
const seo = reactive({
  meta_title: 'AwesomeKorean - 미국 한인 커뮤니티',
  meta_description: '',
  og_image: '',
  google_verification: '',
  naver_verification: '',
  robots_txt: 'User-agent: *\nAllow: /\nSitemap: https://awesomekorean.com/sitemap.xml',
})

// ─── Load All Settings ────────────────────────────────────────────────────────
async function loadSettings() {
  loading.value = true
  try {
    const { data } = await axios.get('/api/admin/settings/all')
    // axios.get()의 data는 응답 바디 전체({success, data})이고, 실제
    // 설정값은 그 안의 data 한 겹 더 안쪽에 있음 — applySettings가 한
    // 겹 덜 벗긴 객체를 받아서 data.company/data.terms 등이 전부
    // undefined였던 게 약관 관리를 포함한 모든 탭이 항상 빈 채로
    // 보이던 진짜 원인.
    applySettings(data.data)
    lastLoaded.value = new Date().toLocaleTimeString('ko-KR')
  } catch {
    // Use hardcoded defaults — already set above
    lastLoaded.value = '기본값 (서버 연결 실패)'
    // Seed sample history
    termsHistory.terms = [
      { version: 3, date: '2024-03-01', summary: '제3조 수정' },
      { version: 2, date: '2024-01-15', summary: '전면 개정' },
      { version: 1, date: '2023-06-01', summary: '최초 등록' },
    ]
    termsHistory.privacy = [
      { version: 2, date: '2024-02-20', summary: '수집 항목 추가' },
      { version: 1, date: '2023-06-01', summary: '최초 등록' },
    ]
    termsLastUpdated.terms = '2024-03-01'
    termsLastUpdated.privacy = '2024-02-20'
  } finally {
    loading.value = false
  }
}

function applySettings(data) {
  if (data.company) Object.assign(company, data.company)
  if (data.site) Object.assign(site, data.site)
  const savedFooter = readSavedFooter(data.footer)   // 예전 방식으로 저장된 값은 무시하고 실제 푸터(기본값)에서 시작
  if (savedFooter) {
    footer.columns = savedFooter.columns
    footer.tagline = savedFooter.tagline ?? footer.tagline
    footer.copyright = savedFooter.copyright ?? footer.copyright
    if (savedFooter.sns) Object.assign(footer.sns, savedFooter.sns)
    footer.additional_text = savedFooter.additional_text ?? ''
  }
  if (data.terms) {
    termsContent.terms = data.terms.terms?.content || ''
    termsContent.privacy = data.terms.privacy?.content || ''
    termsLastUpdated.terms = data.terms.terms?.updated_at || ''
    termsLastUpdated.privacy = data.terms.privacy?.updated_at || ''
    termsHistory.terms = data.terms.terms?.history || []
    termsHistory.privacy = data.terms.privacy?.history || []
  }
  if (data.notifications) {
    if (data.notifications.announcements) notifications.announcements = data.notifications.announcements
    if (data.notifications.email) Object.assign(notifications.email, data.notifications.email)
    if (data.notifications.push) Object.assign(notifications.push, data.notifications.push)
  }
  if (data.payment) Object.assign(payment, data.payment)
  // Stripe 키 로드 (site_settings에서 직접)
  if (data.stripe_publishable_key) payment.stripe_publishable_key = data.stripe_publishable_key
  if (data.stripe_secret_key) payment.stripe_secret_key = data.stripe_secret_key
  if (data.stripe_webhook_secret) payment.stripe_webhook_secret = data.stripe_webhook_secret
  if (data.stripe_test_mode !== undefined) payment.stripe_test_mode = data.stripe_test_mode === '1' || data.stripe_test_mode === true
  if (data.seo) Object.assign(seo, data.seo)
}

// ─── Save Functions ───────────────────────────────────────────────────────────
async function saveCompany() {
  saving.value = true
  try {
    await axios.post('/api/admin/settings/company', { ...company })
    showToast('회사 정보가 저장되었습니다.')
  } catch {
    showToast('저장에 실패했습니다.', 'error')
  } finally {
    saving.value = false
  }
}

async function saveSite() {
  saving.value = true
  try {
    await axios.post('/api/admin/settings/site', { ...site })
    showToast('사이트 설정이 저장되었습니다.')
  } catch {
    showToast('저장에 실패했습니다.', 'error')
  } finally {
    saving.value = false
  }
}

async function saveFooter() {
  saving.value = true
  try {
    await axios.post('/api/admin/settings/footer', {
      version: FOOTER_VERSION,
      tagline: footer.tagline,
      columns: footer.columns,
      copyright: footer.copyright,
      sns: { ...footer.sns },
      additional_text: footer.additional_text,
    })
    showToast('푸터 설정이 저장되었습니다.')
  } catch {
    showToast('저장에 실패했습니다.', 'error')
  } finally {
    saving.value = false
  }
}

async function saveTerms(type) {
  saving.value = true
  try {
    await axios.post(`/api/admin/settings/terms/${type}`, { content: termsContent[type] })
    termsLastUpdated[type] = new Date().toLocaleDateString('ko-KR')
    showToast(type === 'terms' ? '이용약관이 저장되었습니다.' : '개인정보처리방침이 저장되었습니다.')
  } catch {
    showToast('저장에 실패했습니다.', 'error')
  } finally {
    saving.value = false
  }
}

async function saveNotifications() {
  saving.value = true
  try {
    await axios.post('/api/admin/settings/notifications', {
      announcements: notifications.announcements,
      email: { ...notifications.email },
      push: { ...notifications.push },
    })
    showToast('알림 설정이 저장되었습니다.')
  } catch {
    showToast('저장에 실패했습니다.', 'error')
  } finally {
    saving.value = false
  }
}

async function saveStripeKeys() {
  savingStripe.value = true
  try {
    await axios.post('/api/admin/settings/stripe', {
      stripe_publishable_key: payment.stripe_publishable_key,
      stripe_secret_key: payment.stripe_secret_key,
      stripe_webhook_secret: payment.stripe_webhook_secret,
      stripe_test_mode: payment.stripe_test_mode,
    })
    showToast('Stripe 키가 저장되었습니다.')
  } catch {
    showToast('Stripe 키 저장에 실패했습니다.', 'error')
  } finally {
    savingStripe.value = false
  }
}

async function savePayment() {
  saving.value = true
  try {
    await axios.post('/api/admin/settings/payment-gateway', {
      min_amount: payment.min_amount,
      currency: payment.currency,
    })
    showToast('결제 설정이 저장되었습니다.')
  } catch {
    showToast('저장에 실패했습니다.', 'error')
  } finally {
    saving.value = false
  }
}

async function saveSeo() {
  saving.value = true
  try {
    await axios.post('/api/admin/settings/seo', { ...seo })
    showToast('SEO 설정이 저장되었습니다.')
  } catch {
    showToast('저장에 실패했습니다.', 'error')
  } finally {
    saving.value = false
  }
}

// ─── Footer helpers ───────────────────────────────────────────────────────────
function addFooterLink(colIndex) {
  footer.columns[colIndex].links.push({ label: '', url: '' })
}

function removeFooterLink(colIndex, linkIndex) {
  footer.columns[colIndex].links.splice(linkIndex, 1)
}

// ─── Terms helpers ────────────────────────────────────────────────────────────
function formatText(type, format) {
  const el = termsRef[type]
  if (!el) return
  const start = el.selectionStart
  const end = el.selectionEnd
  const selected = termsContent[type].substring(start, end)
  let replacement = selected

  switch (format) {
    case 'bold': replacement = `**${selected}**`; break
    case 'italic': replacement = `*${selected}*`; break
    case 'h2': replacement = `\n## ${selected || '제목'}`; break
    case 'h3': replacement = `\n### ${selected || '소제목'}`; break
    case 'list': replacement = `\n- ${selected || '항목'}`; break
    case 'link': {
      const url = window.prompt('URL을 입력하세요:', 'https://')
      if (url) replacement = `[${selected || '링크 텍스트'}](${url})`
      break
    }
  }

  termsContent[type] =
    termsContent[type].substring(0, start) +
    replacement +
    termsContent[type].substring(end)
}

function restoreVersion(type, version) {
  if (confirm(`v${version.version} (${version.date}) 버전으로 복원하시겠습니까?`)) {
    // In production, would fetch version content from API
    showToast(`v${version.version} 버전으로 복원 요청되었습니다.`)
  }
}

// ─── Announcement helpers ─────────────────────────────────────────────────────
function addAnnouncement() {
  if (!newAnnouncement.title.trim()) {
    showToast('제목을 입력해주세요.', 'error')
    return
  }
  notifications.announcements.unshift({ ...newAnnouncement })
  Object.assign(newAnnouncement, {
    title: '', content: '', start_date: '', end_date: '',
    display_position: 'all', active: true,
  })
  showAnnouncementForm.value = false
}

function removeAnnouncement(index) {
  if (confirm('이 공지사항을 삭제하시겠습니까?')) {
    notifications.announcements.splice(index, 1)
  }
}

function positionLabel(pos) {
  const map = { all: '전체', home: '홈', specific: '특정 메뉴' }
  return map[pos] || pos
}

// ─── VAPID Key Generation ─────────────────────────────────────────────────────
async function generateVapidKeys() {
  generatingKeys.value = true
  try {
    const { data } = await axios.post('/api/admin/settings/generate-vapid')
    notifications.push.vapid_public = data.public_key
    notifications.push.vapid_private = data.private_key
    showToast('VAPID 키가 생성되었습니다.')
  } catch {
    // Simulate key generation for demo
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
    const randomStr = (n) => Array.from({ length: n }, () => chars[Math.floor(Math.random() * chars.length)]).join('')
    notifications.push.vapid_public = 'B' + randomStr(86) + '='
    notifications.push.vapid_private = randomStr(43) + '='
    showToast('VAPID 키가 생성되었습니다 (데모).')
  } finally {
    generatingKeys.value = false
  }
}

// ─── Lifecycle ────────────────────────────────────────────────────────────────
// ─── Menu Management ─────────────────────────────────────────────────────────
const menuList = ref([])
const menuSaving = ref(false)

const allMenuDefs = [
  { key: 'home',      label: '홈',       label_en: 'Home',       icon: '🏠', path: '/' },
  { key: 'community', label: '커뮤니티', label_en: 'Community',  icon: '💬', path: '/community' },
  { key: 'qa',        label: 'Q&A',      label_en: 'Q&A',        icon: '❓', path: '/qa' },
  { key: 'jobs',      label: '구인구직', label_en: 'Jobs',       icon: '💼', path: '/jobs' },
  { key: 'market',    label: '중고장터', label_en: 'Market',     icon: '🛒', path: '/market', hasCardView: true },
  { key: 'directory', label: '업소록',   label_en: 'Directory',  icon: '🏪', path: '/directory', hasCardView: true },
  { key: 'realestate',label: '부동산',   label_en: 'Real Estate',icon: '🏠', path: '/realestate', hasCardView: true },
  { key: 'events',    label: '이벤트',   label_en: 'Events',     icon: '🎉', path: '/events', hasCardView: true },
  { key: 'flyers',    label: 'NEW',      label_en: 'NEW',        icon: '🆕', path: '/new' },
  { key: 'news',      label: '뉴스',     label_en: 'News',       icon: '📰', path: '/news' },
  { key: 'info',      label: '정보',     label_en: 'Info',       icon: '📘', path: '/info' },
  { key: 'recipes',   label: '레시피',   label_en: 'Recipes',    icon: '🍳', path: '/recipes', hasCardView: true },
  { key: 'clubs',     label: '동호회',   label_en: 'Clubs',      icon: '👥', path: '/clubs' },
  { key: 'games',     label: '게임',     label_en: 'Games',      icon: '🎮', path: '/games' },
  { key: 'shorts',    label: '숏츠',     label_en: 'Shorts',     icon: '📱', path: '/shorts' },
  { key: 'music',     label: '음악듣기', label_en: 'Music',      icon: '🎵', path: '/music' },
  { key: 'groupbuy',  label: '공동구매', label_en: 'Group Buy',  icon: '🤝', path: '/groupbuy' },
  { key: 'shopping',  label: '쇼핑',     label_en: 'Shopping',   icon: '🛍️', path: '/shopping' },
  { key: 'chat',      label: '채팅',     label_en: 'Chat',       icon: '💭', path: '/chat' },
  { key: 'friends',   label: '친구',     label_en: 'Friends',    icon: '👫', path: '/friends' },
  { key: 'elder',     label: '안심서비스',label_en: 'Elder Care', icon: '💙', path: '/elder' },
  { key: 'comms',     label: '안심 커뮤', label_en: 'Comms',      icon: '📞', path: '/comms' },
]

async function loadMenus() {
  try {
    const { data } = await axios.get('/api/admin/settings/menus')
    const saved = Array.isArray(data?.data || data) ? (data?.data || data) : []
    if (saved.length > 0) {
      const ordered = []
      saved.forEach(m => {
        const def = allMenuDefs.find(d => d.key === m.key)
        if (def) ordered.push({ ...def, ...m, enabled: m.enabled !== false, login_required: m.login_required || false, admin_only: m.admin_only || false, defaultView: m.defaultView || 'list', ads_enabled: m.ads_enabled || false, ads_type: m.ads_type || 'banner', order: m.order ?? 999 })
      })
      allMenuDefs.forEach(def => {
        if (!ordered.find(m => m.key === def.key)) {
          ordered.push({ ...def, enabled: true, login_required: false, admin_only: false, defaultView: 'list', ads_enabled: false, ads_type: 'banner', order: 999 })
        }
      })
      menuList.value = ordered.sort((a, b) => a.order - b.order)
    } else {
      menuList.value = allMenuDefs.map((d, i) => ({ ...d, enabled: true, login_required: false, admin_only: false, defaultView: 'list', ads_enabled: false, ads_type: 'banner', order: i }))
    }
  } catch {
    menuList.value = allMenuDefs.map((d, i) => ({ ...d, enabled: true, login_required: false, admin_only: false, defaultView: 'list', ads_enabled: false, ads_type: 'banner', order: i }))
  }
}

function moveMenu(idx, dir) {
  const newIdx = idx + dir
  if (newIdx < 0 || newIdx >= menuList.value.length) return
  const list = [...menuList.value]
  const [item] = list.splice(idx, 1)
  list.splice(newIdx, 0, item)
  menuList.value = list
}

function resetMenuOrder() {
  menuList.value = allMenuDefs.map((d, i) => ({ ...d, enabled: true, login_required: false, admin_only: false, ads_enabled: false, ads_type: 'banner', order: i }))
}

async function saveMenus() {
  menuSaving.value = true
  try {
    const menus = menuList.value.map((item, i) => ({
      key: item.key,
      label: item.label,
      label_en: item.label_en,
      icon: item.icon,
      path: item.path,
      enabled: item.enabled,
      order: i,
      login_required: item.login_required || false,
      admin_only: item.admin_only || false,
      defaultView: item.defaultView || 'list',
      hasCardView: item.hasCardView || false,
      ads_enabled: item.ads_enabled || false,
      ads_type: item.ads_type || 'banner',
    }))
    await axios.post('/api/admin/settings/menus/batch', { menus })
    // 같은 세션 내 광고 센터/가격 센터 등 다른 화면도 siteStore.menuConfig를
    // 읽으므로, 저장 직후 스토어에도 바로 반영 — 새로고침 없이 즉시 동기화.
    siteStore.updateMenuConfig(menus)
    showToast('메뉴 설정이 저장되었습니다.')
  } catch {
    showToast('저장 실패', 'error')
  } finally {
    menuSaving.value = false
  }
}

// ─── Firebase 설정 ───────────────────────────────────────────────────────────
const savingFirebase = ref(false)
const firebaseStatus = ref(false)
const firebase = reactive({
  apiKey: '',
  authDomain: '',
  projectId: '',
  storageBucket: '',
  messagingSenderId: '',
  appId: '',
  vapidKey: '',
  credentialsPath: '',
  credentialsExists: false,
})

async function loadFirebase() {
  try {
    const { data } = await axios.get('/api/admin/firebase')
    Object.assign(firebase, data)
    firebaseStatus.value = !!(data.apiKey && data.projectId && data.vapidKey && data.credentialsExists)
  } catch (e) { console.warn('loadFirebase:', e) }
}

const credFileInput = ref(null)
const uploadingCred = ref(false)
const credMsg = ref('')
const credOk = ref(false)
async function uploadFirebaseCredentials(e) {
  const file = e.target.files?.[0]; e.target.value = ''
  if (!file) return
  uploadingCred.value = true; credMsg.value = ''
  try {
    const fd = new FormData(); fd.append('file', file)
    const { data } = await axios.post('/api/admin/firebase/credentials', fd)
    credMsg.value = data.message; credOk.value = true
    await loadFirebase()
  } catch (er) {
    credMsg.value = er.response?.data?.message || (er.response?.status === 403 ? '최고 관리자만 업로드할 수 있어요' : '업로드하지 못했어요'); credOk.value = false
  }
  uploadingCred.value = false
}

const testingPush = ref(false)
const pushTestMsg = ref('')
const pushTestOk = ref(false)
async function testFirebasePush() {
  testingPush.value = true; pushTestMsg.value = ''
  try {
    const { data } = await axios.post('/api/admin/firebase/test')
    pushTestMsg.value = data.message; pushTestOk.value = !!data.success
  } catch (e) {
    pushTestMsg.value = e.response?.data?.message || '테스트 알림을 보내지 못했어요'; pushTestOk.value = false
  }
  testingPush.value = false
}

async function saveFirebase() {
  savingFirebase.value = true
  try {
    await axios.post('/api/admin/firebase', {
      apiKey: firebase.apiKey,
      authDomain: firebase.authDomain,
      projectId: firebase.projectId,
      storageBucket: firebase.storageBucket,
      messagingSenderId: firebase.messagingSenderId,
      appId: firebase.appId,
      vapidKey: firebase.vapidKey,
    })
    showToast('Firebase 설정이 저장되었습니다')
    firebaseStatus.value = !!(firebase.apiKey && firebase.projectId && firebase.vapidKey)
  } catch (e) {
    showToast(e.response?.data?.message || 'Firebase 저장 실패', 'error')
  } finally {
    savingFirebase.value = false
  }
}

// ─── API 키 관리 ──────────────────────────────────────────────────────────────
const apiKeys = ref([])
const showAddApiKey = ref(false)
const newApiKey = ref({ name: '', service: '', api_key: '', description: '' })
const showEditApiKey = ref(false)
const editApiKey = ref({ id: null, name: '', service: '', api_key: '', description: '' })

async function loadApiKeys() {
  try {
    const { data } = await axios.get('/api/admin/api-keys')
    const list = data.data || data || []
    apiKeys.value = list.map(k => ({ ...k, showFull: false, fullKey: '' }))
  } catch (e) { console.error('loadApiKeys error:', e) }
}

// 구글 Analytics(GA4) 측정 ID — service 코드가 google_analytics 인 키가 있으면(활성일 때)
// 모든 공개 페이지에 방문 통계 추적 코드가 자동으로 들어간다. 비활성화/삭제하면 빠짐.
function openAddAnalytics() {
  newApiKey.value = { name: '구글 Analytics 측정 ID', service: 'google_analytics', api_key: '', description: '방문 통계(GA4). 측정 ID는 G- 로 시작합니다 (예: G-ABC123DEF4)' }
  showAddApiKey.value = true
}

async function saveApiKey() {
  try {
    await axios.post('/api/admin/api-keys', newApiKey.value)
    showAddApiKey.value = false
    newApiKey.value = { name: '', service: '', api_key: '', description: '' }
    loadApiKeys()
  } catch (e) { alert(e.response?.data?.message || '등록 실패') }
}

// api_key는 목록에 마스킹된 값만 내려오므로 빈 칸으로 시작 — 비워두고 저장하면
// 백엔드가 그 필드를 건드리지 않고 기존 값을 그대로 유지함
function openEditApiKey(key) {
  editApiKey.value = { id: key.id, name: key.name, service: key.service, api_key: '', description: key.description || '' }
  showEditApiKey.value = true
}

async function saveEditApiKey() {
  try {
    const payload = { name: editApiKey.value.name, service: editApiKey.value.service, description: editApiKey.value.description }
    if (editApiKey.value.api_key) payload.api_key = editApiKey.value.api_key
    await axios.put('/api/admin/api-keys/' + editApiKey.value.id, payload)
    showEditApiKey.value = false
    loadApiKeys()
  } catch (e) { alert(e.response?.data?.message || '수정 실패') }
}

async function deleteApiKey(id) {
  if (!confirm('정말 삭제하시겠습니까?')) return
  await axios.delete('/api/admin/api-keys/' + id)
  loadApiKeys()
}

async function toggleApiKeyActive(key) {
  await axios.put('/api/admin/api-keys/' + key.id, { is_active: !key.is_active })
  loadApiKeys()
}

async function runMailTestSend() {
  try {
    const { data } = await axios.post('/api/admin/system/mail-test-send')
    alert(data.message)
  } catch (e) { alert('발송 실패 — 실제 에러: ' + (e.response?.data?.message || e.message)) }
}

const logoFileInput = ref(null)
const uploadingLogo = ref(false)

async function onLogoFileSelected(e) {
  const file = e.target.files?.[0]
  if (!file) return
  uploadingLogo.value = true
  try {
    const formData = new FormData()
    formData.append('logo', file)
    const { data } = await axios.post('/api/admin/settings/logo', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    })
    company.logo_url = data.data?.url || company.logo_url
    showToast('로고가 업로드되었습니다 — 네비게이션 바, 로그인 화면, 이메일 등에 바로 반영됩니다')
  } catch (e) {
    alert(e.response?.data?.message || '로고 업로드 실패')
  } finally {
    uploadingLogo.value = false
    e.target.value = ''
  }
}

const logoDarkFileInput = ref(null)
const uploadingLogoDark = ref(false)

async function onLogoDarkFileSelected(e) {
  const file = e.target.files?.[0]
  if (!file) return
  uploadingLogoDark.value = true
  try {
    const formData = new FormData()
    formData.append('logo', file)
    const { data } = await axios.post('/api/admin/settings/logo-dark', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    })
    company.logo_dark_url = data.data?.url || company.logo_dark_url
    showToast('다크 배경용 로고가 업로드되었습니다 — 푸터 등에 바로 반영됩니다')
  } catch (e) {
    alert(e.response?.data?.message || '다크 배경용 로고 업로드 실패')
  } finally {
    uploadingLogoDark.value = false
    e.target.value = ''
  }
}

const appIconFileInput = ref(null)
const uploadingAppIcon = ref(false)

async function onAppIconFileSelected(e) {
  const file = e.target.files?.[0]
  if (!file) return
  uploadingAppIcon.value = true
  try {
    const formData = new FormData()
    formData.append('icon', file)
    const { data } = await axios.post('/api/admin/settings/app-icon', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    })
    company.app_icon_url = data.data?.url || company.app_icon_url
    showToast('앱 아이콘이 업로드되었습니다 — 핸드폰 홈 화면 바로가기에 반영됩니다')
  } catch (e) {
    alert(e.response?.data?.message || '앱 아이콘 업로드 실패')
  } finally {
    uploadingAppIcon.value = false
    e.target.value = ''
  }
}

const faviconFileInput = ref(null)
const uploadingFavicon = ref(false)

async function onFaviconFileSelected(e) {
  const file = e.target.files?.[0]
  if (!file) return
  uploadingFavicon.value = true
  try {
    const formData = new FormData()
    formData.append('favicon', file)
    const { data } = await axios.post('/api/admin/settings/favicon', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    })
    company.favicon_url = data.data?.url || company.favicon_url
    showToast('파비콘이 업로드되었습니다 — 브라우저 탭에 바로 반영됩니다')
  } catch (e) {
    alert(e.response?.data?.message || '파비콘 업로드 실패')
  } finally {
    uploadingFavicon.value = false
    e.target.value = ''
  }
}

async function toggleReveal(key) {
  if (!key.showFull) {
    const { data } = await axios.get('/api/admin/api-keys/' + key.id + '/reveal')
    key.fullKey = data.data?.key || data.key || key.api_key || ''
  }
  key.showFull = !key.showFull
}

function copyKey(key) {
  const text = key.showFull ? key.fullKey : key.masked_key
  navigator.clipboard.writeText(key.fullKey || text)
  alert('복사되었습니다!')
}

onMounted(loadSettings)
onMounted(loadMenus)
onMounted(loadApiKeys)
onMounted(loadFirebase)

watch(() => activeTab.value, (tab) => {
  if (tab === 'api') loadApiKeys()
})

</script>

<style scoped>
/* 리뉴얼: input-soft 와 동일한 소프트 입력 스타일 (이 파일 전용 별칭) */
.input-field {
  @apply w-full bg-[#F4F6F8] border-[1.5px] border-transparent rounded-xl px-3 py-2 text-sm text-ink placeholder:text-ink-faint outline-none transition-all duration-150 focus:bg-white focus:border-amber-400 focus:ring-4 focus:ring-amber-400/10;
}

/* btn-primary / btn-secondary 는 app.css 전역 공용 클래스를 사용 (로컬 정의 제거) */

.toolbar-btn {
  @apply px-2.5 py-1 text-sm text-ink-light hover:bg-gray-200 rounded-lg font-medium transition-colors;
}

.toast-enter-active,
.toast-leave-active {
  transition: all 0.3s ease;
}

.toast-enter-from,
.toast-leave-to {
  opacity: 0;
  transform: translateY(-10px) scale(0.95);
}
</style>

<style>
/* 휴대폰 관리자: 사이트 설정은 입력칸이 매우 많아서 화면을 새로 짜지 않고 크기·간격만 손가락에 맞게 조정 */
.ss-m { padding-bottom: 24px; }
.ss-m .card { padding: 14px !important; }
.ss-m input:not([type=checkbox]):not([type=radio]):not([type=range]):not([type=file]):not([type=color]), .ss-m select, .ss-m textarea { font-size: 16px; min-height: 46px; max-width: 100%; }
.ss-m input[type=checkbox], .ss-m input[type=radio] { width: 22px; height: 22px; }
.ss-m button { min-height: 44px; }
.ss-m button.w-7, .ss-m button.w-8 { min-width: 40px; min-height: 40px; }
.ss-m .grid:not(.ss-keep)[class*="grid-cols-2"], .ss-m .grid:not(.ss-keep)[class*="grid-cols-3"], .ss-m .grid:not(.ss-keep)[class*="grid-cols-4"] { grid-template-columns: minmax(0, 1fr); }
.ss-m .ss-keep.grid-cols-3 > div { padding: 10px 4px; }
.ss-m { overflow-x: hidden; }
.ss-m table { display: block; max-width: 100%; overflow-x: auto; }
.ss-m [class*="top-5"][class*="right-5"] { top: calc(70px + env(safe-area-inset-top, 0px)); right: 12px; left: 12px; }
.ss-m h2 { font-size: 17px; }
</style>
