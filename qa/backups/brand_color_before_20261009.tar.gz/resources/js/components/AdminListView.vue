<template>
<div>
  <!-- 타이틀 -->
  <h1 v-if="title" class="flex items-center gap-2.5 text-xl font-bold text-ink mb-4">
    <span class="icon-chip w-9 h-9 bg-amber-50 text-amber-600 text-lg">{{ icon }}</span>
    {{ title }}
  </h1>

  <!-- 휴대폰: 검색 + 필터 -->
  <div v-if="isMobile" class="alv-m space-y-2.5 mb-3">
    <form @submit.prevent="load()" class="flex gap-2">
      <label class="flex-1 min-w-0 flex items-center gap-2 bg-white border border-gray-200 rounded-xl px-3 min-h-[48px] text-ink-muted">
        <AppIcon name="search" :size="18" />
        <input v-model="search" type="search" placeholder="제목·작성자 검색" autocomplete="off" class="w-full min-w-0 bg-transparent outline-none text-ink" />
      </label>
      <button type="submit" class="shrink-0 min-h-[48px] px-4 rounded-xl bg-amber-500 text-white text-[15px] font-bold">검색</button>
    </form>
    <select v-if="categories.length" :value="categoryFilter || ''" @change="onCategorySelect($event.target.value)"
      class="w-full min-h-[48px] bg-white border border-gray-200 rounded-xl px-3 text-ink">
      <option value="">📂 전체 카테고리</option>
      <option v-for="c in categories" :key="c.id || c.slug || c.name" :value="usesTable ? c.id : (c.slug || c.name)">
        {{ c.icon || '🏷' }} {{ c.name }}<template v-if="c.post_count"> ({{ c.post_count }})</template>
      </option>
    </select>
    <div v-if="categoryFilter" class="flex items-center gap-2 bg-blue-50 border border-blue-200 text-blue-700 rounded-xl px-3 min-h-[44px] text-[14px]">
      <strong class="flex-1 min-w-0 truncate">{{ categoryFilterLabel || categoryFilter }}</strong>
      <button @click="$emit('clearFilter')" class="min-w-[44px] min-h-[44px] grid place-items-center" aria-label="필터 해제"><AppIcon name="x" :size="16" /></button>
    </div>
    <slot name="filters"></slot>
    <div class="flex items-center gap-2 min-h-[44px]">
      <div class="flex-1 min-w-0 text-[14px] text-ink-muted">전체 {{ total.toLocaleString() }}건<span v-if="selectMode && selectedIds.size" class="text-red-600 font-bold"> · {{ selectedIds.size }}건 선택</span></div>
      <button v-if="selectMode && selectedIds.size" @click="deleteSelected" class="min-h-[44px] px-4 rounded-xl bg-red-500 text-white text-[15px] font-bold">삭제</button>
      <button @click="toggleSelectMode" class="min-h-[44px] px-4 rounded-xl border text-[15px] font-bold"
        :class="selectMode ? 'bg-ink text-white border-ink' : 'bg-white text-ink border-gray-200'">{{ selectMode ? '완료' : '선택' }}</button>
    </div>
  </div>

  <!-- 검색 + 필터 -->
  <div v-else class="card p-3 mb-4">
    <div class="flex flex-wrap gap-2 items-center">
      <!-- 카테고리 드롭다운 (categories 전달되면 표시) -->
      <select v-if="categories.length"
        :value="categoryFilter || ''"
        @change="onCategorySelect($event.target.value)"
        class="input-soft w-auto px-3 py-1.5">
        <option value="">📂 전체 카테고리</option>
        <option v-for="c in categories" :key="c.id || c.slug || c.name"
          :value="usesTable ? c.id : (c.slug || c.name)">
          {{ c.icon || '🏷' }} {{ c.name }} <template v-if="c.post_count">({{ c.post_count }})</template>
        </option>
      </select>
      <div v-if="categoryFilter" class="flex items-center gap-1 bg-blue-50 border border-blue-200 text-blue-700 rounded-full px-3 py-1 text-xs">
        <strong>{{ categoryFilterLabel || categoryFilter }}</strong>
        <button @click="$emit('clearFilter')" class="ml-1 text-blue-500 hover:text-blue-700 transition-colors"><AppIcon name="x" :size="12" /></button>
      </div>
      <slot name="filters"></slot>
      <form @submit.prevent="load()" class="flex-1 flex gap-1.5 min-w-[150px]">
        <input v-model="search" type="text" placeholder="제목/작성자 검색..." class="flex-1 input-soft px-3 py-1.5" />
        <button type="submit" class="btn-primary px-3 py-1.5 text-xs">검색</button>
      </form>
    </div>
    <div class="flex items-center justify-between mt-1">
      <div class="text-[11px] text-ink-faint">
        전체 {{ total }}건
        <span v-if="categoryFilter" class="text-blue-600">· "{{ categoryFilterLabel || categoryFilter }}" 필터링됨</span>
        <span v-if="selectedIds.size" class="text-red-600 ml-2">· 선택됨 {{ selectedIds.size }}건</span>
      </div>
      <button v-if="selectedIds.size > 0" @click="deleteSelected"
        class="inline-flex items-center gap-1 bg-red-500 hover:bg-red-600 text-white font-bold px-3 py-1.5 rounded-xl text-xs transition-colors">
        <AppIcon name="trash" :size="13" />선택 {{ selectedIds.size }}건 삭제
      </button>
    </div>
  </div>

  <div v-if="loading" class="text-center py-8 text-ink-muted">로딩중...</div>
  <div v-else :class="isMobile ? '' : 'flex gap-4'">
    <!-- 휴대폰: 카드 목록 -->
    <div v-if="isMobile" class="alv-m space-y-2">
      <div v-if="!items.length" class="text-center text-ink-muted py-12 text-[15px]">게시글이 없어요.</div>
      <button v-for="item in items" :key="item.id" @click="selectMode ? toggleOne(item.id) : openItem(item)"
        class="w-full text-left bg-white border rounded-2xl p-3.5 min-h-[76px] flex items-start gap-3 active:bg-amber-50"
        :class="selectedIds.has(item.id) ? 'border-red-300 bg-red-50' : 'border-gray-100'">
        <span v-if="selectMode" class="shrink-0 w-6 h-6 mt-0.5 rounded-md border-2 grid place-items-center text-white text-[14px] font-bold"
          :class="selectedIds.has(item.id) ? 'bg-red-500 border-red-500' : 'border-gray-300 bg-white'">{{ selectedIds.has(item.id) ? '✓' : '' }}</span>
        <span class="min-w-0 flex-1">
          <span class="flex items-center gap-1.5 flex-wrap">
            <span v-if="item.is_pinned" class="text-[12px] font-bold text-red-600 bg-red-50 px-1.5 py-0.5 rounded">고정</span>
            <span v-if="item.is_hidden" class="text-[12px] font-bold text-gray-600 bg-gray-100 px-1.5 py-0.5 rounded">숨김</span>
            <span v-if="item.is_locked" class="text-[12px] font-bold text-orange-600 bg-orange-50 px-1.5 py-0.5 rounded">잠김</span>
            <span v-if="isPromoted(item)" class="text-[12px] font-bold text-white bg-purple-500 px-1.5 py-0.5 rounded">{{ promoBadgeLabel(item) }}</span>
          </span>
          <span class="block text-[16px] font-bold text-ink leading-snug break-words line-clamp-2">{{ item.title || item.name || '(제목 없음)' }}</span>
          <span v-if="item.content || item.description" class="block text-[14px] text-ink-muted truncate mt-0.5">{{ (item.content || item.description || '').slice(0, 60) }}</span>
          <span class="flex items-center gap-x-2 gap-y-1 flex-wrap mt-1.5 text-[13px] text-ink-muted">
            <span>{{ item.user?.name || '-' }}</span>
            <span>{{ (item.created_at || item.published_at || '')?.slice(0,10) }}</span>
            <span>👁 {{ item.view_count || 0 }}</span>
            <span v-for="col in mobileCols(item)" :key="col.key" class="bg-gray-100 text-ink-light px-1.5 py-0.5 rounded-full text-[12px]">{{ col.text }}</span>
          </span>
        </span>
        <span class="shrink-0 text-[12px] px-2 py-1 rounded-full font-bold"
          :class="item.status ? statusClass(item.status) : (item.is_hidden || item.is_active === false ? 'bg-gray-200 text-ink-light' : 'bg-green-100 text-green-700')">
          {{ item.status || (item.is_hidden ? '숨김' : (item.is_active === false ? '비활성' : '정상')) }}
        </span>
      </button>
      <div v-if="lastPage > 1" class="flex items-center justify-between gap-2 pt-2">
        <button @click="load(page - 1)" :disabled="page <= 1" class="min-h-[48px] px-5 rounded-xl bg-white border border-gray-200 text-[15px] font-bold disabled:opacity-40">이전</button>
        <span class="text-[14px] text-ink-muted tabular-nums">{{ page }} / {{ lastPage }}</span>
        <button @click="load(page + 1)" :disabled="page >= lastPage" class="min-h-[48px] px-5 rounded-xl bg-white border border-gray-200 text-[15px] font-bold disabled:opacity-40">다음</button>
      </div>
    </div>

    <!-- 왼쪽: 목록 -->
    <div v-else :class="activeItem ? 'w-1/2' : 'w-full'">
      <div class="card overflow-hidden">
        <table class="w-full text-sm">
          <thead class="bg-gray-50 border-b border-gray-100"><tr>
            <th class="px-2 py-2 w-8 text-center">
              <input type="checkbox" :checked="allSelected" @change="toggleAll" @click.stop />
            </th>
            <th @click="clickSort('id')" class="px-3 py-2 text-left text-xs text-ink-muted w-8 cursor-pointer hover:bg-gray-100 select-none">
              # <span v-if="sortBy==='id'" class="text-amber-500">{{ sortDir==='asc'?'▲':'▼' }}</span>
            </th>
            <th @click="clickSort('title')" class="px-3 py-2 text-left text-xs text-ink-muted cursor-pointer hover:bg-gray-100 select-none">
              {{ titleCol }} <span v-if="sortBy==='title'" class="text-amber-500">{{ sortDir==='asc'?'▲':'▼' }}</span>
            </th>
            <th v-for="col in extraCols" :key="col.key" v-show="!activeItem"
              @click="clickSort(col.key)"
              class="px-3 py-2 text-left text-xs text-ink-muted cursor-pointer hover:bg-gray-100 select-none">
              {{ col.label }} <span v-if="sortBy===col.key" class="text-amber-500">{{ sortDir==='asc'?'▲':'▼' }}</span>
            </th>
            <th @click="clickSort('user_id')" class="px-3 py-2 text-left text-xs text-ink-muted cursor-pointer hover:bg-gray-100 select-none">
              작성자 <span v-if="sortBy==='user_id'" class="text-amber-500">{{ sortDir==='asc'?'▲':'▼' }}</span>
            </th>
            <th class="px-3 py-2 text-xs text-ink-muted">상태</th>
            <th @click="clickSort('view_count')" class="px-3 py-2 text-xs text-ink-muted cursor-pointer hover:bg-gray-100 select-none">
              <span class="inline-flex items-center gap-0.5"><AppIcon name="eye" :size="13" /> <span v-if="sortBy==='view_count'" class="text-amber-500">{{ sortDir==='asc'?'▲':'▼' }}</span></span>
            </th>
            <th @click="clickSort('created_at')" class="px-3 py-2 text-xs text-ink-muted cursor-pointer hover:bg-gray-100 select-none">
              날짜 <span v-if="sortBy==='created_at'" class="text-amber-500">{{ sortDir==='asc'?'▲':'▼' }}</span>
            </th>
          </tr></thead>
          <tbody>
            <tr v-for="item in items" :key="item.id"
              class="border-b border-gray-50 last:border-0 hover:bg-amber-50/40 cursor-pointer transition-colors"
              :class="activeItem?.id===item.id ? 'bg-amber-50 border-l-2 border-l-amber-500' : (selectedIds.has(item.id) ? 'bg-red-50' : '')"
              @click="openItem(item)">
              <td class="px-2 py-2 text-center" @click.stop>
                <input type="checkbox" :checked="selectedIds.has(item.id)" @change="toggleOne(item.id)" />
              </td>
              <td class="px-3 py-2 text-xs text-ink-faint">{{ item.id }}</td>
              <td class="px-3 py-2.5 max-w-[250px]">
                <div class="flex items-center gap-1">
                  <span v-if="item.is_pinned" title="고정" class="text-red-500"><AppIcon name="bookmark" :size="12" :filled="true" /></span>
                  <span v-if="item.is_hidden" title="숨김" class="text-gray-400"><AppIcon name="x" :size="12" /></span>
                  <span v-if="item.is_locked" title="잠김" class="text-orange-500"><AppIcon name="lock" :size="12" /></span>
                  <span v-if="isPromoted(item)" :title="promoTooltip(item)" class="inline-flex items-center gap-0.5 text-[11px] font-bold text-white bg-purple-500 px-1 py-px rounded"><AppIcon name="sparkles" :size="10" />{{ promoBadgeLabel(item) }}</span>
                  <div class="truncate text-sm font-medium text-ink">{{ item.title || item.name }}</div>
                </div>
                <div class="text-[11px] text-ink-faint truncate mt-0.5">{{ (item.content || item.description || '').slice(0, 60) }}{{ (item.content || item.description || '').length > 60 ? '...' : '' }}</div>
              </td>
              <td v-for="col in extraCols" :key="col.key" v-show="!activeItem" class="px-3 py-2.5">
                <button v-if="isCategoryCol(col.key)"
                  @click.stop="clickCategoryCell(item, col)"
                  class="text-[11px] bg-amber-100 text-amber-700 hover:bg-amber-200 px-1.5 py-0.5 rounded-full font-semibold transition-colors cursor-pointer">
                  {{ getNestedVal(item, col.key) }}
                </button>
                <span v-else class="text-[11px] bg-gray-100 text-ink-light px-1.5 py-0.5 rounded-full">{{ getNestedVal(item, col.key) }}</span>
              </td>
              <td class="px-3 py-2.5">
                <button @click.stop="$emit('openUser', item.user || {id: item.user_id})" class="text-xs text-blue-600 hover:underline">{{ item.user?.name || '-' }}</button>
              </td>
              <td class="px-3 py-2.5 text-center">
                <span v-if="item.status" class="text-[11px] px-1.5 py-0.5 rounded-full font-semibold" :class="statusClass(item.status)">{{ item.status }}</span>
                <span v-else-if="item.is_hidden" class="text-[11px] bg-gray-200 text-ink-light px-1.5 py-0.5 rounded-full font-semibold">숨김</span>
                <span v-else-if="item.is_active === false" class="text-[11px] bg-gray-200 text-ink-light px-1.5 py-0.5 rounded-full font-semibold">비활성</span>
                <span v-else class="text-[11px] bg-green-100 text-green-700 px-1.5 py-0.5 rounded-full font-semibold">정상</span>
              </td>
              <td class="px-3 py-2.5 text-center text-xs text-ink-faint">{{ item.view_count || 0 }}</td>
              <td class="px-3 py-2.5 text-[11px] text-ink-faint">{{ (item.created_at || item.published_at || '')?.slice(0,10) }}</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div v-if="lastPage > 1" class="flex justify-center gap-1.5 mt-4">
        <button v-for="pg in Math.min(lastPage, 10)" :key="pg" @click="load(pg)"
          class="w-8 h-8 rounded-lg text-sm transition-colors" :class="pg===page?'bg-amber-400 text-white font-bold':'text-ink-muted hover:bg-gray-100'">{{ pg }}</button>
      </div>
    </div>

    <!-- 오른쪽: 인라인 상세 + 관리 (휴대폰에서는 전체 화면) -->
    <Teleport to="body" :disabled="!isMobile">
    <div v-if="activeItem" :class="isMobile ? 'alv-m fixed inset-0 z-[60] bg-[#F3F4F6] overflow-y-auto overscroll-contain' : 'w-1/2'">
      <div class="card overflow-hidden" :class="isMobile ? 'rounded-none min-h-full' : 'sticky top-4 max-h-[calc(100vh-2rem)] overflow-y-auto'"
        :style="isMobile ? { paddingBottom: 'env(safe-area-inset-bottom, 0px)' } : null">
        <div class="alv-head px-4 py-3 border-b border-gray-100 flex items-center justify-between bg-amber-50 sticky top-0 z-10"
          :style="isMobile ? { paddingTop: 'calc(12px + env(safe-area-inset-top, 0px))' } : null">
          <span class="flex items-center gap-1.5 font-bold text-sm text-amber-700"><AppIcon name="edit" :size="14" />게시글 관리</span>
          <div class="flex gap-1">
            <button @click="editMode = !editMode" class="inline-flex items-center gap-1 text-xs bg-white border border-gray-200 px-2 py-1 rounded-lg hover:bg-gray-50 transition-colors text-ink-light">
              <AppIcon :name="editMode ? 'check' : 'edit'" :size="12" />{{ editMode ? '완료' : '편집' }}
            </button>
            <button @click="closeDetail" class="text-ink-muted hover:text-ink transition-colors" aria-label="닫기"><AppIcon name="x" :size="18" /></button>
          </div>
        </div>

        <!-- 관리 액션 바 -->
        <div v-if="detailData" class="alv-actions px-4 py-2 bg-gray-50 border-b border-gray-100 flex flex-wrap gap-1">
          <button v-if="actions.pin" @click="toggleField('is_pinned')"
            :class="activeItem.is_pinned ? 'bg-red-100 text-red-700' : 'bg-white border border-gray-200 text-ink-light'"
            class="inline-flex items-center gap-0.5 text-[11px] px-2 py-1 rounded-lg hover:bg-red-50 transition-colors">
            <AppIcon name="bookmark" :size="11" :filled="activeItem.is_pinned" />{{ activeItem.is_pinned ? '고정해제' : '고정' }}
          </button>
          <button v-if="actions.hide" @click="toggleField('is_hidden')"
            :class="activeItem.is_hidden ? 'bg-gray-200 text-ink-light' : 'bg-white border border-gray-200 text-ink-light'"
            class="inline-flex items-center gap-0.5 text-[11px] px-2 py-1 rounded-lg hover:bg-gray-100 transition-colors">
            <AppIcon name="eye" :size="11" />{{ activeItem.is_hidden ? '공개' : '숨김' }}
          </button>
          <button v-if="actions.active" @click="toggleField('is_active')"
            :class="activeItem.is_active === false ? 'bg-orange-100 text-orange-700' : 'bg-white border border-gray-200 text-ink-light'"
            class="text-[11px] px-2 py-1 rounded-lg hover:bg-orange-50 transition-colors">
            {{ activeItem.is_active === false ? '비활성' : '활성' }}
          </button>
          <button v-if="actions.lock_comments" @click="toggleField('is_locked')"
            :class="activeItem.is_locked ? 'bg-orange-100 text-orange-700' : 'bg-white border border-gray-200 text-ink-light'"
            class="inline-flex items-center gap-0.5 text-[11px] px-2 py-1 rounded-lg hover:bg-orange-50 transition-colors">
            <AppIcon name="lock" :size="11" />{{ activeItem.is_locked ? '잠금해제' : '댓글잠금' }}
          </button>
          <button v-if="actions.approved" @click="toggleField('is_approved')"
            :class="activeItem.is_approved ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'"
            class="text-[11px] px-2 py-1 rounded-lg transition-colors">
            {{ activeItem.is_approved ? '승인됨' : '대기' }}
          </button>
          <button v-if="actions.verified" @click="toggleField('is_verified')"
            :class="activeItem.is_verified ? 'bg-blue-100 text-blue-700' : 'bg-white border border-gray-200 text-ink-light'"
            class="text-[11px] px-2 py-1 rounded-lg transition-colors">
            {{ activeItem.is_verified ? '✓ 인증됨' : '인증하기' }}
          </button>
          <button v-if="actions.resolved" @click="toggleField('is_resolved')"
            :class="activeItem.is_resolved ? 'bg-green-100 text-green-700' : 'bg-white border border-gray-200 text-ink-light'"
            class="text-[11px] px-2 py-1 rounded-lg transition-colors">
            {{ activeItem.is_resolved ? '해결됨' : '미해결' }}
          </button>
          <button @click="openPointModal" class="inline-flex items-center gap-0.5 text-[11px] px-2 py-1 rounded-lg bg-purple-100 text-purple-700 hover:bg-purple-200 transition-colors">
            <AppIcon name="coins" :size="11" />포인트 조정
          </button>
          <button @click="openMoveModal" class="inline-flex items-center gap-0.5 text-[11px] px-2 py-1 rounded-lg bg-blue-100 text-blue-700 hover:bg-blue-200 transition-colors">
            <AppIcon name="tag" :size="11" />카테고리 변경
          </button>
          <button v-if="isPromoted(activeItem)" @click="clearPromotion(activeItem)"
            class="inline-flex items-center gap-0.5 text-[11px] px-2 py-1 rounded-lg bg-purple-100 text-purple-700 hover:bg-purple-200 transition-colors"
            :title="promoTooltip(activeItem)">
            <AppIcon name="sparkles" :size="11" />상위노출 해제
          </button>
          <button @click="deleteItem(activeItem)" class="inline-flex items-center gap-0.5 text-[11px] px-2 py-1 rounded-lg bg-red-100 text-red-700 hover:bg-red-200 transition-colors ml-auto"><AppIcon name="trash" :size="11" />삭제</button>
        </div>

        <!-- 상위노출 상태 배너 (활성 중이면 표시) -->
        <div v-if="detailData && isPromoted(activeItem)" class="px-4 py-2 bg-purple-50 border-b border-purple-200 flex items-center justify-between">
          <div class="text-xs">
            <span class="inline-flex items-center gap-1 font-bold text-purple-800"><AppIcon name="sparkles" :size="12" />상위노출 중</span>
            <span class="text-purple-600 ml-2">{{ promoBadgeLabel(activeItem) }}</span>
            <span class="text-ink-muted ml-2">만료: {{ promoExpiresDisplay(activeItem) }}</span>
          </div>
          <button @click="clearPromotion(activeItem)" class="text-[11px] text-purple-700 hover:text-purple-900 underline transition-colors">
            강제 해제
          </button>
        </div>

        <!-- 제목/내용 (편집 모드) -->
        <div v-if="editMode" class="px-4 py-3 space-y-2">
          <div>
            <label class="input-label !text-xs !mb-0.5">제목</label>
            <input v-model="activeItem.title" class="input-soft px-3 py-1.5" />
          </div>
          <div v-if="activeItem.content !== undefined">
            <label class="input-label !text-xs !mb-0.5">내용</label>
            <textarea v-model="activeItem.content" rows="8" class="input-soft px-3 py-1.5 font-mono"></textarea>
          </div>
          <div v-if="activeItem.description !== undefined">
            <label class="input-label !text-xs !mb-0.5">설명</label>
            <textarea v-model="activeItem.description" rows="4" class="input-soft px-3 py-1.5"></textarea>
          </div>
          <div class="grid grid-cols-2 gap-2">
            <div v-if="activeItem.price !== undefined && activeItem.price !== null">
              <label class="input-label !text-xs !mb-0.5">가격</label>
              <input v-model.number="activeItem.price" type="number" class="input-soft px-3 py-1.5" />
            </div>
            <div v-if="activeItem.city !== undefined">
              <label class="input-label !text-xs !mb-0.5">도시</label>
              <input v-model="activeItem.city" class="input-soft px-3 py-1.5" />
            </div>
          </div>
          <button @click="savePost" class="btn-primary px-4 py-1.5">저장</button>
        </div>

        <!-- 보기 모드 -->
        <div v-else class="px-4 py-3">
          <h2 class="text-lg font-bold text-ink">{{ activeItem.title || activeItem.name }}</h2>
          <div class="flex flex-wrap items-center gap-3 mt-2 text-xs text-ink-muted">
            <button @click="$emit('openUser', activeItem.user || {id: activeItem.user_id})" class="text-blue-600 hover:underline font-semibold">{{ activeItem.user?.name || '-' }}</button>
            <span v-if="activeItem.company" class="inline-flex items-center gap-1"><AppIcon name="building" :size="12" />{{ activeItem.company }}</span>
            <span v-if="activeItem.city" class="inline-flex items-center gap-1"><AppIcon name="map-pin" :size="12" />{{ activeItem.city }}, {{ activeItem.state }}</span>
            <span v-if="activeItem.category" class="inline-flex items-center gap-1"><AppIcon name="tag" :size="12" />{{ typeof activeItem.category === 'object' ? activeItem.category.name : activeItem.category }}</span>
            <span v-if="activeItem.price !== undefined && activeItem.price !== null" class="inline-flex items-center gap-1"><AppIcon name="dollar" :size="12" />${{ Number(activeItem.price).toLocaleString() }}</span>
            <span class="inline-flex items-center gap-1"><AppIcon name="eye" :size="12" />{{ activeItem.view_count || 0 }}</span>
            <span>{{ (activeItem.created_at || activeItem.published_at || '')?.slice(0,10) }}</span>
          </div>
        </div>

        <!-- 별점 (업소록 등) -->
        <div v-if="!editMode && activeItem.rating !== undefined && activeItem.rating !== null" class="px-4 pb-2 flex items-center gap-1 text-sm">
          <span class="text-amber-400">{{ '★'.repeat(Math.round(activeItem.rating)) }}{{ '☆'.repeat(5 - Math.round(activeItem.rating)) }}</span>
          <span class="font-semibold text-ink">{{ activeItem.rating }}</span>
          <span class="text-xs text-ink-muted">({{ activeItem.review_count || 0 }}개 리뷰)</span>
        </div>

        <!-- 연락처 정보 (업소록·구인구직·부동산 등) -->
        <div v-if="!editMode && (activeItem.phone || activeItem.address || activeItem.website || activeItem.email || activeItem.contact_phone || activeItem.contact_email)"
          class="px-4 pb-2 text-xs text-ink-light space-y-1">
          <div v-if="activeItem.phone || activeItem.contact_phone" class="flex items-center gap-1.5"><AppIcon name="phone" :size="12" class="text-ink-muted" />{{ activeItem.phone || activeItem.contact_phone }}</div>
          <div v-if="activeItem.address" class="flex items-center gap-1.5"><AppIcon name="map-pin" :size="12" class="text-ink-muted" />{{ activeItem.address }}</div>
          <div v-if="activeItem.website" class="flex items-center gap-1.5 truncate"><AppIcon name="globe" :size="12" class="text-ink-muted" /><a :href="activeItem.website" target="_blank" class="text-blue-600 hover:underline truncate">{{ activeItem.website }}</a></div>
          <div v-if="activeItem.email || activeItem.contact_email" class="flex items-center gap-1.5"><AppIcon name="mail" :size="12" class="text-ink-muted" />{{ activeItem.email || activeItem.contact_email }}</div>
        </div>

        <!-- 영업시간 (업소록) -->
        <div v-if="!editMode && activeItem.hours && Object.keys(activeItem.hours).length" class="px-4 pb-2">
          <div class="text-xs font-bold text-ink mb-1 flex items-center gap-1"><AppIcon name="clock" :size="12" class="text-ink-muted" />영업시간</div>
          <div class="grid grid-cols-2 gap-x-3 gap-y-0.5 text-[11px] text-ink-muted">
            <div v-for="(time, day) in activeItem.hours" :key="day" class="flex justify-between">
              <span>{{ day }}</span><span>{{ time }}</span>
            </div>
          </div>
        </div>

        <!-- 원문 출처 (뉴스) -->
        <div v-if="!editMode && activeItem.source" class="px-4 pb-2 text-xs text-ink-muted flex items-center gap-1.5">
          <AppIcon name="external-link" :size="12" />출처: {{ activeItem.source }}
          <a v-if="activeItem.source_url" :href="activeItem.source_url" target="_blank" class="text-blue-600 hover:underline">원문 보기</a>
        </div>

        <!-- 이미지 (게시판마다 필드명이 다름 — displayImages가 전부 흡수) -->
        <div v-if="!editMode && displayImages.length === 1" class="px-4 pb-2">
          <img :src="displayImages[0]" class="w-full max-h-48 object-cover rounded-lg" @error="e=>e.target.style.display='none'" />
        </div>
        <div v-else-if="!editMode && displayImages.length > 1" class="px-4 pb-2 flex gap-1.5 overflow-x-auto">
          <img v-for="(img, i) in displayImages" :key="i" :src="img" class="h-40 rounded-lg object-cover flex-shrink-0" @error="e=>e.target.style.display='none'" />
        </div>

        <!-- 본문 -->
        <div v-if="!editMode && (activeItem.content || activeItem.description)" class="px-4 py-3 border-t border-gray-100 text-sm text-ink-light leading-relaxed whitespace-pre-wrap max-h-[300px] overflow-y-auto">{{ activeItem.content || activeItem.description }}</div>
        <!-- 레시피는 content/description이 아니라 ingredients/steps에 실제 내용이 있음 -->
        <div v-else-if="!editMode && (activeItem.ingredients || activeItem.steps?.length)" class="px-4 py-3 border-t border-gray-100 text-sm text-ink-light max-h-[300px] overflow-y-auto space-y-3">
          <div v-if="activeItem.ingredients">
            <div class="font-bold text-xs text-ink mb-1">재료{{ activeItem.servings ? ` (${activeItem.servings})` : '' }}</div>
            <div class="whitespace-pre-wrap leading-relaxed">{{ activeItem.ingredients }}</div>
          </div>
          <div v-if="activeItem.steps?.length">
            <div class="font-bold text-xs text-ink mb-1">조리 순서</div>
            <div v-for="step in activeItem.steps" :key="step.order" class="mb-2">
              <span class="font-semibold">{{ step.order }}.</span> <span class="whitespace-pre-wrap">{{ step.text }}</span>
              <img v-if="step.image_url" :src="step.image_url" class="mt-1.5 max-h-40 rounded-lg border border-gray-100" @error="e=>e.target.style.display='none'" />
            </div>
          </div>
        </div>
        <div v-else-if="!editMode" class="px-4 py-3 border-t border-gray-100 text-sm text-ink-faint">(내용 없음)</div>

        <!-- 리뷰 (업소록 — 사이트 자체 리뷰 + 구글 리뷰) -->
        <div v-if="siteAndGoogleReviews.length" class="px-4 py-3 border-t border-gray-100">
          <div class="flex items-center gap-1.5 text-xs font-bold text-ink mb-2"><AppIcon name="star" :size="13" class="text-amber-400" />리뷰 {{ siteAndGoogleReviews.length }}개</div>
          <div class="space-y-2 max-h-[250px] overflow-y-auto">
            <div v-for="(r, i) in siteAndGoogleReviews" :key="i" class="border border-gray-100 rounded-lg p-2 bg-gray-50">
              <div class="flex items-center gap-1.5 text-[11px] mb-0.5">
                <span class="font-semibold text-ink">{{ r.user?.name || r.author || '익명' }}</span>
                <span class="text-amber-400">{{ '★'.repeat(r.rating || 0) }}</span>
              </div>
              <div class="text-xs text-ink-light">{{ r.content || r.text }}</div>
            </div>
          </div>
        </div>

        <!-- 댓글 + 답글 -->
        <div v-if="detailData?.comments" class="px-4 py-3 border-t border-gray-100">
          <div class="flex items-center gap-1.5 text-xs font-bold text-ink mb-2"><AppIcon name="message-circle" :size="13" />댓글 {{ commentTotalCount }}개</div>
          <div v-if="!detailData.comments.length" class="text-[11px] text-ink-faint py-2">댓글이 없습니다</div>
          <div v-else class="space-y-2 max-h-[300px] overflow-y-auto">
            <div v-for="c in detailData.comments" :key="c.id" class="border border-gray-100 rounded-lg p-2 bg-gray-50">
              <div class="flex items-start justify-between gap-2">
                <div class="flex-1 min-w-0">
                  <div class="flex items-center gap-1 text-[11px] mb-1">
                    <button @click="$emit('openUser', c.user)" class="text-blue-600 hover:underline font-semibold">{{ c.user?.name || '?' }}</button>
                    <span class="text-ink-faint">·</span>
                    <span class="text-ink-muted">{{ c.created_at?.slice(0,16).replace('T',' ') }}</span>
                    <span v-if="c.like_count" class="text-red-500">♥ {{ c.like_count }}</span>
                    <span v-if="c.is_hidden" class="bg-gray-300 text-ink-light px-1 rounded">숨김</span>
                  </div>
                  <div class="text-xs text-ink-light whitespace-pre-wrap" :class="c.is_hidden ? 'line-through text-ink-faint' : ''">{{ c.content }}</div>
                </div>
                <div class="flex gap-1 shrink-0">
                  <button @click="toggleCommentHide(c)" class="alv-cbtn text-[11px] text-orange-600 hover:underline">{{ c.is_hidden ? '공개' : '숨김' }}</button>
                  <button @click="deleteComment(c)" class="alv-cbtn text-[11px] text-red-500 hover:underline">삭제</button>
                </div>
              </div>
              <!-- 답글 -->
              <div v-if="c.replies?.length" class="mt-2 ml-4 space-y-1 border-l-2 border-amber-200 pl-2">
                <div v-for="r in c.replies" :key="r.id" class="text-[11px]">
                  <div class="flex items-start justify-between gap-2">
                    <div class="flex-1">
                      <span class="text-blue-600 font-semibold">↳ {{ r.user?.name || '?' }}</span>
                      <span class="text-ink-faint ml-1">{{ r.created_at?.slice(5,16).replace('T',' ') }}</span>
                      <span v-if="r.is_hidden" class="bg-gray-300 text-ink-light px-1 rounded ml-1">숨김</span>
                      <div class="text-ink-light mt-0.5" :class="r.is_hidden ? 'line-through text-ink-faint' : ''">{{ r.content }}</div>
                    </div>
                    <div class="flex gap-1 shrink-0">
                      <button @click="toggleCommentHide(r)" class="alv-cbtn text-[11px] text-orange-600">{{ r.is_hidden ? '공개' : '숨김' }}</button>
                      <button @click="deleteComment(r)" class="alv-cbtn text-[11px] text-red-500">삭제</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- 포인트 내역 -->
        <div v-if="detailData?.point_logs?.length" class="px-4 py-3 border-t border-gray-100">
          <div class="flex items-center gap-1.5 text-xs font-bold text-ink mb-2"><AppIcon name="coins" :size="13" />이 게시글 관련 포인트 ({{ detailData.point_logs.length }})</div>
          <div class="space-y-1 max-h-[120px] overflow-y-auto">
            <div v-for="pl in detailData.point_logs" :key="pl.id" class="flex justify-between text-[11px] py-0.5">
              <span class="text-ink-muted">{{ pl.created_at?.slice(0,10) }}</span>
              <span class="text-ink-light truncate flex-1 mx-2">{{ pl.reason }}</span>
              <span :class="pl.amount>0?'text-green-600':'text-red-600'" class="font-bold">{{ pl.amount>0?'+':'' }}{{ pl.amount }}P</span>
            </div>
          </div>
        </div>

        <!-- 신고 -->
        <div v-if="detailData?.reports?.length" class="px-4 py-3 border-t border-gray-100 bg-red-50">
          <div class="flex items-center gap-1.5 text-xs font-bold text-red-700 mb-2"><AppIcon name="alert-circle" :size="13" />신고 {{ detailData.reports.length }}건</div>
          <div class="space-y-1 max-h-[100px] overflow-y-auto">
            <div v-for="r in detailData.reports" :key="r.id" class="text-[11px] text-red-700">
              <span class="font-medium">{{ r.reporter?.name || '?' }}</span>: {{ r.reason }}
              <span class="text-ink-muted ml-1">({{ r.status }})</span>
            </div>
          </div>
        </div>
      </div>
    </div>
    </Teleport>
  </div>

  <!-- 포인트 조정 모달 -->
  <Teleport to="body" :disabled="!isMobile">
  <div v-if="showPointModal" class="fixed inset-0 bg-black/50 flex justify-center p-4" :class="isMobile ? 'alv-m z-[70] items-end' : 'z-50 items-center'" @click.self="showPointModal=false">
    <div class="bg-white rounded-2xl p-5 w-full max-w-md" :style="isMobile ? { paddingBottom: 'calc(20px + env(safe-area-inset-bottom, 0px))' } : null">
      <h3 class="flex items-center gap-2 font-bold text-ink mb-3"><span class="icon-chip w-7 h-7 bg-amber-50 text-amber-600"><AppIcon name="coins" :size="15" /></span>작성자 포인트 조정</h3>
      <div class="text-xs text-ink-light mb-3">
        게시글: <strong>{{ activeItem?.title || activeItem?.name }}</strong><br>
        작성자: <strong>{{ activeItem?.user?.name }}</strong>
      </div>
      <div class="space-y-3">
        <div>
          <label class="input-label !text-xs">증감 (음수로 차감)</label>
          <input v-model.number="pointAmount" type="number" placeholder="예: 50 또는 -20" class="input-soft px-3 py-1.5" />
        </div>
        <div>
          <label class="input-label !text-xs">사유</label>
          <input v-model="pointReason" placeholder="예: 우수 콘텐츠 보상" class="input-soft px-3 py-1.5" />
        </div>
      </div>
      <div class="flex justify-end gap-2 mt-4">
        <button @click="showPointModal=false" class="btn-ghost px-3 py-1 text-sm">취소</button>
        <button @click="applyPointAdjust" class="btn-primary px-4 py-1.5">적용</button>
      </div>
    </div>
  </div>
  </Teleport>

  <!-- 카테고리 변경 모달 -->
  <Teleport to="body" :disabled="!isMobile">
  <div v-if="showMoveModal" class="fixed inset-0 bg-black/50 flex justify-center p-4" :class="isMobile ? 'alv-m z-[70] items-end' : 'z-50 items-center'" @click.self="showMoveModal=false">
    <div class="bg-white rounded-2xl p-5 w-full max-w-sm" :style="isMobile ? { paddingBottom: 'calc(20px + env(safe-area-inset-bottom, 0px))' } : null">
      <h3 class="flex items-center gap-2 font-bold text-ink mb-3"><span class="icon-chip w-7 h-7 bg-blue-50 text-blue-600"><AppIcon name="tag" :size="15" /></span>카테고리 변경</h3>
      <input v-model="newCategory" placeholder="카테고리 이름 또는 ID" class="input-soft px-3 py-1.5" />
      <div class="flex justify-end gap-2 mt-4">
        <button @click="showMoveModal=false" class="btn-ghost px-3 py-1 text-sm">취소</button>
        <button @click="applyCategoryChange" class="btn-primary px-4 py-1.5">변경</button>
      </div>
    </div>
  </div>
  </Teleport>
</div>
</template>

<script setup>
import { ref, onMounted, onBeforeUnmount, computed, watch, inject } from 'vue'
import axios from 'axios'
import AppIcon from './AppIcon.vue'

// 관리자 휴대폰 화면이면 카드 목록 + 전체 화면 상세로 보여 줌 (AdminLayout 이 알려 줌)
const adminIsMobile = inject('adminIsMobile', ref(false))
const isMobile = computed(() => !!adminIsMobile.value)

const props = defineProps({
  icon: { type: String, default: '📋' },
  title: { type: String, required: true },
  apiUrl: { type: String, required: true },
  deleteUrl: { type: String, default: null },
  titleCol: { type: String, default: '제목' },
  extraCols: { type: Array, default: () => [] },
  // board-manager 모드: slug 주면 /api/admin/board-manager/{slug}/* 를 사용 (관리 액션 지원)
  boardSlug: { type: String, default: null },
  // 카테고리 필터 (외부에서 주입 — 카테고리 탭에서 "게시글 보기" 클릭 시)
  categoryFilter: { type: [String, Number], default: null },
  categoryFilterLabel: { type: String, default: '' },
  // 카테고리 목록 (드롭다운 필터용 — AdminBoardManager 에서 로드됨)
  categories: { type: Array, default: () => [] },
  usesTable: { type: Boolean, default: false },
  // 대분류 필터 (구인/구직, 렌트/매매 등)
  majorType: { type: String, default: '' },
})

const emit = defineEmits(['openUser', 'clearFilter', 'setCategoryFilter'])

const items = ref([]); const loading = ref(true)
const page = ref(1); const lastPage = ref(1); const total = ref(0)
const search = ref(''); const activeItem = ref(null)
const detailData = ref(null)
const editMode = ref(false)

// 멀티 선택 + 정렬
const selectedIds = ref(new Set())
const sortBy = ref('id')
const sortDir = ref('desc')
const allSelected = computed(() => items.value.length > 0 && items.value.every(i => selectedIds.value.has(i.id)))
function toggleAll() {
  if (allSelected.value) selectedIds.value = new Set()
  else selectedIds.value = new Set(items.value.map(i => i.id))
}
function toggleOne(id) {
  if (selectedIds.value.has(id)) selectedIds.value.delete(id)
  else selectedIds.value.add(id)
  selectedIds.value = new Set(selectedIds.value)
}
function clickSort(col) {
  if (sortBy.value === col) sortDir.value = sortDir.value === 'asc' ? 'desc' : 'asc'
  else { sortBy.value = col; sortDir.value = 'asc' }
  load(1)
}
async function deleteSelected() {
  const ids = [...selectedIds.value]
  if (!ids.length) return
  if (!confirm(`선택한 ${ids.length}건을 삭제합니다. 계속?`)) return
  const baseUrl = props.boardSlug
    ? `/api/admin/board-manager/${props.boardSlug}/posts`
    : (props.deleteUrl || props.apiUrl)
  let success = 0, failed = 0
  for (const id of ids) {
    try { await axios.delete(`${baseUrl}/${id}`); success++ }
    catch { failed++ }
  }
  selectedIds.value = new Set()
  load(page.value)
  alert(`삭제 완료: ${success}건 성공${failed ? `, ${failed}건 실패` : ''}`)
}

// 휴대폰: 선택 삭제는 '선택' 모드에서만 (카드를 눌렀을 때 실수로 체크되지 않게)
const selectMode = ref(false)
function toggleSelectMode() { selectMode.value = !selectMode.value; selectedIds.value = new Set() }

// 휴대폰 카드에 보여줄 추가 정보 (카테고리류는 값만, 나머지는 '이름 값')
function mobileCols(item) {
  const out = []
  for (const col of props.extraCols) {
    const v = getNestedVal(item, col.key)
    if (v === '-' || v === '' || v == null) continue
    out.push({ key: col.key, text: isCategoryCol(col.key) ? String(v) : `${col.label} ${v}` })
    if (out.length >= 4) break
  }
  return out
}

// 휴대폰 상세는 전체 화면이라, 폰의 뒤로 가기(제스처/버튼)로도 닫히게 브라우저 기록을 한 칸 쌓아 둠
// (주소는 그대로 — 주소를 바꾸면 App.vue 가 페이지 전체를 다시 그려서 검색/페이지 상태가 사라짐)
let pushedDetail = false
function closeDetail() {
  if (isMobile.value && pushedDetail) { history.back(); return }
  activeItem.value = null; editMode.value = false
}
function onPopState() {
  if (pushedDetail && !history.state?.alvDetail) { pushedDetail = false; activeItem.value = null; editMode.value = false }
}
window.addEventListener('popstate', onPopState)
// 상세가 열려 있는 동안 뒤쪽 화면이 같이 스크롤되지 않게
watch(() => isMobile.value && !!activeItem.value, locked => {
  document.body.style.overflow = locked ? 'hidden' : ''
})
onBeforeUnmount(() => { document.body.style.overflow = ''; window.removeEventListener('popstate', onPopState) })

const showPointModal = ref(false)
const pointAmount = ref(0)
const pointReason = ref('관리자 수동 조정')

const showMoveModal = ref(false)
const newCategory = ref('')

const actions = computed(() => detailData.value?.actions || {})

// 게시판마다 이미지 필드명이 제각각(image_url/thumbnail/thumbnail_url/
// cover_image/logo/images 배열) — 실제 사용자 페이지들이 쓰는 필드를 전부
// 폴백으로 모아 어떤 게시판이든 상세보기에서 이미지가 보이도록 함.
function resolveImgSrc(p) {
  if (!p) return null
  const s = String(p)
  // 단일 필드(image_url/thumbnail 등)는 저장 시 이미 '/storage/...' 또는 완전한
  // URL로 저장되지만, images 배열 필드는 '/storage/' 없이 상대경로만 저장됨
  // (storeCompressedImageRaw) — 이미 절대경로/외부URL인 건 그대로 두고 상대경로만 보정.
  if (s.startsWith('http') || s.startsWith('/')) return s
  return `/storage/${s}`
}
const displayImages = computed(() => {
  const item = activeItem.value
  if (!item) return []
  if (Array.isArray(item.images) && item.images.length) {
    return item.images.map(resolveImgSrc).filter(Boolean)
  }
  const single = item.image_url || item.thumbnail || item.thumbnail_url || item.cover_image || item.image || item.logo
  const resolved = resolveImgSrc(single)
  return resolved ? [resolved] : []
})

// 업소록의 자체 별점 리뷰(reviews)와 구글 리뷰(google_reviews)를 하나로 합쳐 표시
const siteAndGoogleReviews = computed(() => {
  const site = activeItem.value?.reviews || []
  const google = activeItem.value?.google_reviews || []
  return [...site, ...google]
})

const commentTotalCount = computed(() => {
  const cs = detailData.value?.comments || []
  return cs.reduce((sum, c) => sum + 1 + (c.replies?.length || 0), 0)
})

async function toggleCommentHide(c) {
  if (!props.boardSlug) return
  try {
    const { data } = await axios.post(`/api/admin/board-manager/${props.boardSlug}/comments/${c.id}/toggle`, { field: 'is_hidden' })
    c.is_hidden = data.data.is_hidden
  } catch (e) { alert(e.response?.data?.message || '실패') }
}

async function deleteComment(c) {
  if (!props.boardSlug) return
  if (!confirm('댓글을 삭제하시겠습니까? (답글도 함께 삭제됩니다)')) return
  try {
    await axios.delete(`/api/admin/board-manager/${props.boardSlug}/comments/${c.id}`)
    // 로컬 업데이트
    const comments = detailData.value?.comments || []
    for (let i = comments.length - 1; i >= 0; i--) {
      if (comments[i].id === c.id) { comments.splice(i, 1); return }
      comments[i].replies = (comments[i].replies || []).filter(r => r.id !== c.id)
    }
  } catch (e) { alert(e.response?.data?.message || '실패') }
}

function getNestedVal(obj, key) {
  return key.split('.').reduce((o, k) => o?.[k], obj) || '-'
}

// 카테고리 컬럼인지 자동 감지 (category, category_id, board_id, category.name, board.name 등)
function isCategoryCol(key) {
  return /^(category|board)(_id|\.name|\.slug)?$/i.test(key)
}

// 행의 카테고리 셀 클릭 → 필터
function clickCategoryCell(item, col) {
  const val = getNestedVal(item, col.key)
  if (!val || val === '-') return
  // FK 기반이면 ID 추출, 문자열이면 그대로
  let filterVal = val
  let label = val
  if (col.key.includes('.name')) {
    // 관계 객체 접근 - 부모 id 찾기
    const parent = col.key.split('.')[0]  // 'board' or 'category'
    filterVal = item[parent]?.id ?? item[parent + '_id'] ?? val
    label = val
  } else if (col.key === 'category_id' || col.key === 'board_id') {
    // ID 이지만 라벨은 카테고리 목록에서 찾기
    filterVal = item[col.key]
    const match = props.categories.find(c => c.id === filterVal)
    label = match?.name || String(filterVal)
  }
  emit('setCategoryFilter', { value: filterVal, label })
}

function onCategorySelect(val) {
  if (!val) {
    emit('clearFilter')
    return
  }
  // 선택된 카테고리의 라벨 찾기
  const match = props.categories.find(c =>
    (props.usesTable ? c.id : (c.slug || c.name)) === val ||
    String(props.usesTable ? c.id : (c.slug || c.name)) === String(val)
  )
  emit('setCategoryFilter', { value: val, label: match?.name || val })
}

function statusClass(s) {
  const map = {
    active:'bg-green-100 text-green-700', completed:'bg-blue-100 text-blue-700',
    pending:'bg-yellow-100 text-yellow-700', rejected:'bg-red-100 text-red-600',
    recruiting:'bg-green-100 text-green-700', confirmed:'bg-blue-100 text-blue-700',
    cancelled:'bg-gray-200 text-gray-500', sold:'bg-gray-100 text-gray-600',
    hidden:'bg-gray-200 text-gray-600',
  }
  return map[s] || 'bg-gray-100 text-gray-700'
}

async function openItem(item) {
  if (isMobile.value && !pushedDetail) {
    history.pushState({ ...(history.state || {}), alvDetail: true }, '')
    pushedDetail = true
  }
  activeItem.value = item
  editMode.value = false
  detailData.value = null

  // board-manager 모드면 확장 상세 로드
  if (props.boardSlug) {
    try {
      const { data } = await axios.get(`/api/admin/board-manager/${props.boardSlug}/posts/${item.id}`)
      activeItem.value = data.data.item
      detailData.value = data.data
    } catch (e) { console.warn(e) }
  } else {
    // 기존 모드
    try { const { data } = await axios.get(`${props.apiUrl}/${item.id}`); activeItem.value = data.data || item }
    catch {}
  }
}

async function toggleField(field) {
  if (!props.boardSlug) return
  try {
    const { data } = await axios.post(`/api/admin/board-manager/${props.boardSlug}/posts/${activeItem.value.id}/toggle`, { field })
    activeItem.value[field] = data.data[field]
    // 리스트 항목도 갱신
    const idx = items.value.findIndex(x => x.id === activeItem.value.id)
    if (idx >= 0) items.value[idx][field] = data.data[field]
  } catch (e) { alert(e.response?.data?.message || '실패') }
}

async function savePost() {
  if (!props.boardSlug) { editMode.value = false; return }
  try {
    const payload = {
      title: activeItem.value.title,
      name: activeItem.value.name,
      content: activeItem.value.content,
      description: activeItem.value.description,
      price: activeItem.value.price,
      city: activeItem.value.city,
    }
    await axios.put(`/api/admin/board-manager/${props.boardSlug}/posts/${activeItem.value.id}`, payload)
    editMode.value = false
    alert('저장되었습니다')
  } catch (e) { alert(e.response?.data?.message || '저장 실패') }
}

function openPointModal() {
  pointAmount.value = 0
  pointReason.value = '관리자 수동 조정'
  showPointModal.value = true
}

async function applyPointAdjust() {
  if (!props.boardSlug || !pointAmount.value) return
  try {
    const { data } = await axios.post(
      `/api/admin/board-manager/${props.boardSlug}/posts/${activeItem.value.id}/points`,
      { amount: pointAmount.value, reason: pointReason.value }
    )
    alert(`${data.message}. 새 잔액: ${data.new_balance}P`)
    showPointModal.value = false
    openItem(activeItem.value) // 포인트 로그 갱신
  } catch (e) { alert(e.response?.data?.message || '실패') }
}

function openMoveModal() {
  newCategory.value = typeof activeItem.value.category === 'object' ? activeItem.value.category?.id : (activeItem.value.category || '')
  showMoveModal.value = true
}

async function applyCategoryChange() {
  if (!props.boardSlug) return
  try {
    await axios.post(`/api/admin/board-manager/${props.boardSlug}/posts/${activeItem.value.id}/category`, { category: newCategory.value })
    alert('카테고리가 변경되었습니다')
    showMoveModal.value = false
    openItem(activeItem.value)
  } catch (e) { alert(e.response?.data?.message || '실패') }
}

async function load(p=1) {
  loading.value = true; page.value = p
  const params = { page: p, per_page: 20, sort_by: sortBy.value, sort_dir: sortDir.value }
  if (search.value) params.search = search.value
  if (props.categoryFilter !== null && props.categoryFilter !== undefined && props.categoryFilter !== '') {
    params.category = props.categoryFilter
    params.category_id = props.categoryFilter
    params.board_id = props.categoryFilter
  }
  if (props.majorType) params.major_type = props.majorType
  // board-manager 모드면 관리자 posts 엔드포인트 사용 (필터 지원)
  const url = props.boardSlug
    ? `/api/admin/board-manager/${props.boardSlug}/posts`
    : props.apiUrl
  try {
    const { data } = await axios.get(url, { params })
    items.value = data.data?.data || data.data || []
    lastPage.value = data.data?.last_page || 1
    total.value = data.data?.total || items.value.length
  } catch {}
  loading.value = false
}

// 카테고리/대분류 필터 변경 시 자동 재로드
watch(() => props.categoryFilter, () => load(1))
watch(() => props.majorType, () => load(1))

async function deleteItem(item) {
  if (!confirm('정말 삭제하시겠습니까?')) return
  const url = props.boardSlug
    ? `/api/admin/board-manager/${props.boardSlug}/posts/${item.id}`
    : `${props.deleteUrl || props.apiUrl}/${item.id}`
  try {
    await axios.delete(url)
    items.value = items.value.filter(x => x.id !== item.id)
    total.value--
    if (activeItem.value?.id === item.id) closeDetail()
  } catch (e) {
    alert(e.response?.data?.message || '삭제 실패')
  }
}

// ─── 상위노출(promotion) 상태 helper ────────────────────────────────
function isPromoted(item) {
  if (!item) return false
  // modern tier 시스템
  if (item.promotion_tier && item.promotion_tier !== 'none' && item.promotion_expires_at
      && new Date(item.promotion_expires_at) > new Date()) return true
  // legacy boost 시스템
  if (item.boosted_until && new Date(item.boosted_until) > new Date()) return true
  return false
}
function promoBadgeLabel(item) {
  if (item.promotion_tier === 'national')   return '전국구'
  if (item.promotion_tier === 'state_plus') return '주+'
  if (item.promotion_tier === 'sponsored')  return '스폰'
  if (item.boosted_until) return '부스트'
  return '노출'
}
function promoExpiresDisplay(item) {
  const d = item.promotion_expires_at || item.boosted_until
  if (!d) return '-'
  return new Date(d).toLocaleString('ko-KR', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
}
function promoTooltip(item) {
  return `상위노출 활성 중 · 만료: ${promoExpiresDisplay(item)}`
}

async function clearPromotion(item) {
  if (!confirm('상위노출을 즉시 해제할까요? (포인트 환불 없음)')) return
  try {
    await axios.post(`/api/admin/${detectResourceFromUrl()}/${item.id}/clear-promotion`)
    // 리스트의 실제 항목을 찾아 in-place 교체 (Vue reactivity 안전)
    const idx = items.value.findIndex(x => x.id === item.id)
    if (idx >= 0) {
      items.value[idx] = {
        ...items.value[idx],
        promotion_tier: 'none',
        promotion_expires_at: null,
        boosted_until: null,
        promotion_states: null,
      }
    }
    if (activeItem.value?.id === item.id) {
      activeItem.value = { ...(idx >= 0 ? items.value[idx] : item) }
    }
  } catch (e) {
    alert(e.response?.data?.message || '해제 실패')
  }
}

function detectResourceFromUrl() {
  // /api/market → market, /api/businesses → businesses 등
  const m = (props.apiUrl || '').match(/\/api\/([a-z_-]+)/)
  return m ? m[1] : 'market'
}

onMounted(() => load())
</script>

<style>
/* 휴대폰 관리자: 작은 버튼/입력창을 손가락으로 누르기 쉽게 */
.alv-m input, .alv-m textarea, .alv-m select { font-size: 16px; }
.alv-m .alv-actions button { min-height: 44px; font-size: 14px; padding: 0 14px; border-radius: 12px; }
.alv-m .alv-head button { min-height: 44px; min-width: 44px; font-size: 14px; }
.alv-m .alv-cbtn { min-height: 40px; min-width: 44px; font-size: 14px; }
</style>
