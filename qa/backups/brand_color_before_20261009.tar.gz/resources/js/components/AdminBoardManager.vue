<template>
<!-- ───────── 휴대폰 화면 ───────── -->
<div v-if="isMobile" class="alv-m space-y-3">
  <!-- 대분류 (구인/구직, 렌트/매매 등) -->
  <div v-if="majorTypes.length" class="flex gap-2 overflow-x-auto scrollbar-hide" role="group" aria-label="분류">
    <button @click="setMajorType('')" :aria-pressed="!activeMajorType"
      class="shrink-0 min-h-[44px] px-4 rounded-full border text-[15px]"
      :class="!activeMajorType ? 'bg-ink text-white border-ink font-bold' : 'bg-white text-ink border-gray-200 font-medium'">전체 ({{ overview.total || 0 }})</button>
    <button v-for="mt in majorTypes" :key="mt.key" @click="setMajorType(mt.key)" :aria-pressed="activeMajorType === mt.key"
      class="shrink-0 min-h-[44px] px-4 rounded-full border text-[15px]"
      :class="activeMajorType === mt.key ? 'bg-ink text-white border-ink font-bold' : 'bg-white text-ink border-gray-200 font-medium'">{{ mt.label }} ({{ mt.count }})</button>
  </div>

  <!-- 요약 -->
  <div class="flex gap-2 overflow-x-auto scrollbar-hide">
    <div class="shrink-0 min-w-[92px] bg-white border border-gray-100 rounded-2xl px-3 py-2.5"><div class="text-[12px] text-ink-muted">전체 글</div><div class="text-[20px] font-black tabular-nums text-ink">{{ (overview.total || 0).toLocaleString() }}</div></div>
    <div class="shrink-0 min-w-[92px] bg-white border border-gray-100 rounded-2xl px-3 py-2.5"><div class="text-[12px] text-ink-muted">오늘</div><div class="text-[20px] font-black tabular-nums text-blue-600">{{ overview.today || 0 }}</div></div>
    <div class="shrink-0 min-w-[92px] bg-white border border-gray-100 rounded-2xl px-3 py-2.5"><div class="text-[12px] text-ink-muted">이번 주</div><div class="text-[20px] font-black tabular-nums text-green-600">{{ overview.week || 0 }}</div></div>
    <button @click="activeTab = 'rep'" class="shrink-0 min-w-[92px] text-left bg-white border rounded-2xl px-3 py-2.5 active:bg-red-50" :class="(overview.pending_reports || 0) > 0 ? 'border-red-200' : 'border-gray-100'"><div class="text-[12px] text-ink-muted">신고 대기</div><div class="text-[20px] font-black tabular-nums text-red-600">{{ overview.pending_reports || 0 }}</div></button>
    <button @click="activeTab = 'ban'" class="shrink-0 min-w-[92px] text-left bg-white border border-gray-100 rounded-2xl px-3 py-2.5 active:bg-purple-50"><div class="text-[12px] text-ink-muted">광고 활성</div><div class="text-[20px] font-black tabular-nums text-purple-600">{{ overview.active_banners || 0 }}</div></button>
  </div>

  <!-- 탭 -->
  <div class="flex gap-2 overflow-x-auto scrollbar-hide" role="tablist" aria-label="관리 메뉴">
    <button v-for="t in tabs" :key="t.key" @click="activeTab = t.key" role="tab" :aria-selected="activeTab === t.key"
      class="shrink-0 min-h-[44px] px-4 rounded-full border text-[15px] flex items-center gap-1.5"
      :class="activeTab === t.key ? 'bg-amber-500 text-white border-amber-500 font-bold' : 'bg-white text-ink border-gray-200 font-medium'">
      {{ t.label }}
      <span v-if="t.badge" class="min-w-[20px] h-5 px-1.5 rounded-full bg-red-500 text-white text-[12px] font-bold grid place-items-center">{{ t.badge }}</span>
    </button>
  </div>

  <!-- 게시글 -->
  <AdminListView v-if="activeTab === 'posts'" :icon="icon" :title="''" :api-url="apiUrl" :delete-url="deleteUrl || apiUrl"
    :extra-cols="extraCols" :board-slug="slug"
    :categories="categories" :uses-table="usesTable"
    :category-filter="postCategoryFilter" :category-filter-label="postCategoryFilterLabel"
    :major-type="activeMajorType"
    @open-user="u => $emit('openUser', u)"
    @clear-filter="postCategoryFilter = null; postCategoryFilterLabel = ''"
    @set-category-filter="onSetCategoryFilter" />

  <!-- 카테고리 -->
  <div v-else-if="activeTab === 'cat'" class="space-y-3">
    <div class="text-[14px] text-ink-muted">
      <template v-if="activeMajorType"><strong class="text-amber-700">{{ activeMajorTypeLabel }}</strong> 카테고리</template>
      <template v-else>{{ label }} 전용 카테고리</template>
    </div>
    <div v-if="majorTypes.length && !activeMajorType" class="bg-orange-50 border border-orange-200 rounded-xl p-3 text-[14px] text-orange-800">
      💡 이 게시판은 대분류별로 카테고리가 나뉘어 있어요. 위에서 {{ majorTypes.map(m => m.label).join(' / ') }} 중 하나를 먼저 고르세요.
    </div>
    <div v-if="hasAutoDetected" class="bg-blue-50 border border-blue-200 text-blue-800 rounded-xl p-3 text-[14px]">
      💡 기존 글에서 자동으로 찾은 카테고리예요. 이름을 한글로 고치고 <strong>저장</strong>을 누르면 확정돼요.
    </div>
    <div v-if="categories.length === 0" class="text-center text-ink-muted py-8 text-[15px]">카테고리가 없어요. 아래 "카테고리 추가"를 눌러 주세요.</div>
    <div v-for="(c, i) in categories" :key="i" class="bg-white border border-gray-100 rounded-2xl p-3.5 space-y-2.5">
      <div class="flex gap-2">
        <input v-model="c.icon" placeholder="🏷" aria-label="아이콘" class="w-16 min-h-[48px] rounded-xl border border-gray-200 text-center px-2" />
        <input v-model="c.name" placeholder="이름" aria-label="이름" class="flex-1 min-w-0 min-h-[48px] rounded-xl border border-gray-200 px-3" />
      </div>
      <input v-model="c.slug" placeholder="slug (영문 주소)" aria-label="slug" class="w-full min-h-[48px] rounded-xl border border-gray-200 px-3" />
      <div class="flex flex-wrap items-center gap-x-5 gap-y-2">
        <label class="flex items-center gap-2 min-h-[44px] text-[15px] text-ink"><input type="checkbox" v-model="c.is_active" class="w-6 h-6 accent-amber-500" /> 사용</label>
        <label v-if="hasAutoFetch" class="flex items-center gap-2 min-h-[44px] text-[15px] text-ink"><input type="checkbox" v-model="c.auto_fetch" class="w-6 h-6 accent-amber-500" /> 자동수집</label>
        <span v-if="c.post_count" class="text-[13px] bg-gray-100 text-ink-light px-2 py-1 rounded-full font-semibold">{{ c.post_count }}개</span>
        <span v-if="c.auto_detected" class="text-[13px] bg-blue-100 text-blue-700 px-2 py-1 rounded-full font-semibold">자동감지</span>
      </div>
      <input v-if="hasAutoFetch && c.auto_fetch" v-model="c.channel_url" placeholder="채널 URL (선택)" aria-label="채널 URL" class="w-full min-h-[48px] rounded-xl border border-gray-200 px-3" />
      <div class="grid grid-cols-2 gap-2">
        <button @click="viewCategoryPosts(c)" class="min-h-[48px] rounded-xl bg-amber-50 text-amber-700 text-[15px] font-bold">게시글 보기</button>
        <button @click="removeCategoryMobile(i)" class="min-h-[48px] rounded-xl bg-red-50 text-red-600 text-[15px] font-bold">목록에서 빼기</button>
      </div>
    </div>
    <button @click="addCategory" class="w-full min-h-[52px] rounded-2xl border-2 border-dashed border-gray-300 text-[16px] font-bold text-ink-light">+ 카테고리 추가</button>
    <div class="sticky z-10 -mx-3.5 px-3.5 pt-2 pb-2 bg-gradient-to-t from-[#F3F4F6] via-[#F3F4F6] to-transparent" :style="{ bottom: 'calc(66px + env(safe-area-inset-bottom, 0px))' }">
      <button @click="saveCategories" class="w-full min-h-[52px] rounded-2xl bg-amber-500 text-white text-[16px] font-bold shadow-lg">카테고리 저장</button>
    </div>
  </div>

  <!-- 부모가 넣는 추가 탭 (예: 공동구매 승인) -->
  <div v-else-if="isCustomTab(activeTab)" class="overflow-x-auto">
    <slot :name="`tab-${activeTab}`"></slot>
  </div>

  <!-- 설정 -->
  <div v-else-if="activeTab === 'set'" class="space-y-2.5">
    <div class="text-[14px] text-ink-muted">이 게시판만의 기본 설정이에요.</div>
    <div v-for="(def, key) in settingSchema" :key="key" class="bg-white border border-gray-100 rounded-2xl px-3.5 py-3">
      <div class="flex items-center gap-3 min-h-[44px]">
        <div class="flex-1 min-w-0">
          <div class="text-[16px] font-bold text-ink leading-snug">{{ def.label }}</div>
        </div>
        <button v-if="def.type === 'bool'" type="button" role="switch" :aria-checked="!!settingValues[key]" :aria-label="def.label"
          @click="settingValues[key] = !settingValues[key]"
          class="relative shrink-0 w-[54px] h-[32px] rounded-full transition-colors" :class="settingValues[key] ? 'bg-emerald-500' : 'bg-gray-300'">
          <span class="absolute top-[4px] w-6 h-6 bg-white rounded-full shadow transition-all" :class="settingValues[key] ? 'left-[26px]' : 'left-[4px]'"></span>
        </button>
      </div>
      <select v-if="def.type === 'select'" v-model="settingValues[key]" class="mt-2 w-full min-h-[48px] rounded-xl border border-gray-200 px-3 bg-white">
        <option v-for="o in def.options" :key="o.value" :value="o.value">{{ o.label }}</option>
      </select>
      <input v-else-if="def.type === 'number'" type="number" inputmode="numeric" v-model.number="settingValues[key]" class="mt-2 w-full min-h-[48px] rounded-xl border border-gray-200 px-3 tabular-nums" />
      <input v-else-if="def.type !== 'bool'" type="text" v-model="settingValues[key]" class="mt-2 w-full min-h-[48px] rounded-xl border border-gray-200 px-3" />
    </div>
    <div class="sticky z-10 -mx-3.5 px-3.5 pt-2 pb-2 bg-gradient-to-t from-[#F3F4F6] via-[#F3F4F6] to-transparent" :style="{ bottom: 'calc(66px + env(safe-area-inset-bottom, 0px))' }">
      <button @click="saveSettings" class="w-full min-h-[52px] rounded-2xl bg-amber-500 text-white text-[16px] font-bold shadow-lg">설정 저장</button>
    </div>
  </div>

  <!-- 포인트 -->
  <div v-else-if="activeTab === 'point'" class="space-y-2.5">
    <div class="text-[14px] text-ink-muted">💡 {{ label }} 전용 포인트 규칙이에요. 전체 포인트는 [시스템 › 포인트 설정]에서 바꿔요.</div>
    <div v-for="(def, key) in pointSchema" :key="key" class="border rounded-2xl p-3.5" :class="def.is_deduction ? 'bg-red-50 border-red-100' : 'bg-white border-gray-100'">
      <div class="text-[16px] font-bold text-ink">{{ def.label }}</div>
      <div class="grid grid-cols-2 gap-2 mt-2">
        <label class="block"><span class="block text-[13px] text-ink-muted mb-1">포인트 (P)</span>
          <input type="number" inputmode="numeric" v-model.number="pointValues[key]" class="w-full min-h-[48px] rounded-xl border border-gray-200 px-3 bg-white tabular-nums" /></label>
        <label class="block"><span class="block text-[13px] text-ink-muted mb-1">하루 한도</span>
          <input type="number" inputmode="numeric" v-model.number="pointValues[key + '_daily_max']" placeholder="-" class="w-full min-h-[48px] rounded-xl border border-gray-200 px-3 bg-white tabular-nums" /></label>
      </div>
    </div>
    <div class="sticky z-10 -mx-3.5 px-3.5 pt-2 pb-2 bg-gradient-to-t from-[#F3F4F6] via-[#F3F4F6] to-transparent" :style="{ bottom: 'calc(66px + env(safe-area-inset-bottom, 0px))' }">
      <button @click="savePoints" class="w-full min-h-[52px] rounded-2xl bg-amber-500 text-white text-[16px] font-bold shadow-lg">포인트 규칙 저장</button>
    </div>
  </div>

  <!-- 배너/광고 -->
  <div v-else-if="activeTab === 'ban'" class="space-y-2.5">
    <div class="flex items-center justify-between gap-2">
      <div class="text-[14px] text-ink-muted min-w-0">이 게시판({{ slug }})에 나오는 광고</div>
      <router-link to="/admin/banners" class="shrink-0 min-h-[44px] px-3 inline-flex items-center text-[14px] font-bold text-blue-600">전체 광고 →</router-link>
    </div>
    <div v-if="bannerStats" class="flex gap-2 overflow-x-auto scrollbar-hide">
      <div class="shrink-0 min-w-[78px] bg-white border border-gray-100 rounded-2xl px-3 py-2"><div class="text-[12px] text-ink-muted">전체</div><div class="font-black text-ink tabular-nums">{{ bannerStats.total }}</div></div>
      <div class="shrink-0 min-w-[78px] bg-white border border-gray-100 rounded-2xl px-3 py-2"><div class="text-[12px] text-ink-muted">활성</div><div class="font-black text-green-700 tabular-nums">{{ bannerStats.active }}</div></div>
      <div class="shrink-0 min-w-[78px] bg-white border border-gray-100 rounded-2xl px-3 py-2"><div class="text-[12px] text-ink-muted">대기</div><div class="font-black text-yellow-700 tabular-nums">{{ bannerStats.pending }}</div></div>
      <div class="shrink-0 min-w-[78px] bg-white border border-gray-100 rounded-2xl px-3 py-2"><div class="text-[12px] text-ink-muted">노출</div><div class="font-black text-blue-700 tabular-nums">{{ bannerStats.total_impressions }}</div></div>
      <div class="shrink-0 min-w-[78px] bg-white border border-gray-100 rounded-2xl px-3 py-2"><div class="text-[12px] text-ink-muted">매출(P)</div><div class="font-black text-purple-700 tabular-nums">{{ bannerStats.total_revenue }}</div></div>
    </div>
    <div v-if="banners.length === 0" class="text-center text-ink-muted py-10 text-[15px]">이 게시판에 등록된 광고가 없어요.</div>
    <div v-for="b in banners" :key="b.id" class="bg-white border border-gray-100 rounded-2xl p-3.5">
      <div class="flex items-start gap-2">
        <div class="flex-1 min-w-0">
          <div class="text-[16px] font-bold text-ink break-words">{{ b.title }}</div>
          <button @click="$emit('openUser', b.user)" class="text-[14px] text-blue-600 min-h-[32px]">{{ b.user?.name || '-' }}</button>
        </div>
        <span class="shrink-0 text-[12px] px-2 py-1 rounded-full font-bold" :class="statusClass(b.status)">{{ b.status }}</span>
      </div>
      <div class="text-[13px] text-ink-muted mt-1 space-y-0.5">
        <div>위치 {{ b.position }}<template v-if="b.slot_number"> · 슬롯 S{{ b.slot_number }}</template></div>
        <div>{{ b.start_date }} ~ {{ b.end_date }}</div>
        <div>노출 {{ b.impressions }} · 클릭 {{ b.clicks }} · 비용 {{ b.total_cost }}P</div>
      </div>
      <div class="grid grid-cols-2 gap-2 mt-3">
        <button v-if="b.status === 'pending'" @click="approveBanner(b)" class="min-h-[48px] rounded-xl bg-emerald-500 text-white text-[15px] font-bold">승인</button>
        <button v-if="b.status === 'pending'" @click="rejectBanner(b)" class="min-h-[48px] rounded-xl bg-red-50 text-red-600 text-[15px] font-bold">거절</button>
        <button v-if="b.status === 'active'" @click="pauseBanner(b)" class="min-h-[48px] rounded-xl bg-orange-50 text-orange-700 text-[15px] font-bold">일시정지</button>
        <button @click="deleteBanner(b)" class="min-h-[48px] rounded-xl bg-gray-100 text-ink text-[15px] font-bold">삭제</button>
      </div>
    </div>
  </div>

  <!-- 신고 -->
  <div v-else-if="activeTab === 'rep'" class="space-y-2.5">
    <div class="text-[14px] text-ink-muted">이 게시판에 들어온 신고 (처리 대기)</div>
    <div v-if="reports.length === 0" class="text-center text-ink-muted py-10 text-[15px]">신고가 없어요 👍</div>
    <div v-for="r in reports" :key="r.id" class="bg-white border border-gray-100 rounded-2xl p-3.5">
      <div class="flex items-center gap-2 text-[13px] text-ink-muted">
        <span class="font-bold text-ink">#{{ r.reportable_id }}</span>
        <span>{{ (r.created_at || '').slice(0, 10) }}</span>
        <span class="ml-auto bg-gray-100 text-ink-light px-2 py-0.5 rounded-full text-[12px] font-bold">{{ r.status }}</span>
      </div>
      <div class="text-[15px] text-red-600 font-bold mt-1 break-words">{{ r.reason }}</div>
      <button @click="$emit('openUser', r.reporter)" class="text-[14px] text-blue-600 min-h-[36px]">신고자 {{ r.reporter?.name || '-' }}</button>
      <div class="grid grid-cols-2 gap-2 mt-2">
        <button @click="updateReport(r, 'resolved')" class="min-h-[48px] rounded-xl bg-emerald-500 text-white text-[15px] font-bold">해결</button>
        <button @click="updateReport(r, 'rejected')" class="min-h-[48px] rounded-xl bg-gray-100 text-ink text-[15px] font-bold">기각</button>
      </div>
    </div>
  </div>
</div>

<!-- ───────── PC 화면 ───────── -->
<div v-else>
  <!-- 헤더 -->
  <div class="mb-4 flex items-start justify-between">
    <div>
      <div class="text-xs text-ink-muted">관리자 › 게시판 관리 › {{ label }}</div>
      <h1 class="flex items-center gap-2.5 text-xl font-bold text-ink mt-1">
        <span class="icon-chip w-9 h-9 bg-amber-50 text-amber-600 text-lg">{{ icon }}</span>
        {{ label }} 관리
      </h1>
      <p class="text-xs text-ink-faint mt-0.5">게시글·카테고리·설정·포인트·배너·신고를 한 페이지에서 관리합니다</p>
    </div>
  </div>

  <!-- 대분류 탭 (jobs: 구인/구직, realestate: 렌트/매매/룸메이트) -->
  <div v-if="majorTypes && majorTypes.length" class="flex gap-2 mb-4 flex-wrap">
    <button @click="setMajorType('')"
      class="px-4 py-2 rounded-xl text-sm font-bold border transition-colors"
      :class="!activeMajorType ? 'bg-amber-400 text-white border-amber-400' : 'bg-white text-ink-light border-gray-200 hover:bg-amber-50'">
      전체 ({{ overview.total || 0 }})
    </button>
    <button v-for="mt in majorTypes" :key="mt.key" @click="setMajorType(mt.key)"
      class="px-4 py-2 rounded-xl text-sm font-bold border transition-colors"
      :class="activeMajorType === mt.key ? 'bg-amber-400 text-white border-amber-400' : 'bg-white text-ink-light border-gray-200 hover:bg-amber-50'">
      {{ mt.label }} ({{ mt.count }})
    </button>
  </div>

  <!-- 통계 카드 -->
  <div class="grid grid-cols-2 md:grid-cols-5 gap-3 mb-4">
    <div class="card p-3">
      <div class="text-xs text-ink-muted">전체 게시글</div>
      <div class="text-xl font-bold text-ink">{{ overview.total || 0 }}</div>
    </div>
    <div class="card p-3">
      <div class="text-xs text-ink-muted">오늘 등록</div>
      <div class="text-xl font-bold text-blue-600">{{ overview.today || 0 }}</div>
    </div>
    <div class="card p-3">
      <div class="text-xs text-ink-muted">주간 등록</div>
      <div class="text-xl font-bold text-green-600">{{ overview.week || 0 }}</div>
    </div>
    <div class="card p-3">
      <div class="text-xs text-ink-muted">신고 대기</div>
      <div class="text-xl font-bold text-red-600">{{ overview.pending_reports || 0 }}</div>
    </div>
    <div class="card p-3">
      <div class="text-xs text-ink-muted">광고 활성</div>
      <div class="text-xl font-bold text-purple-600">{{ overview.active_banners || 0 }}</div>
    </div>
  </div>

  <!-- 탭 네비 -->
  <div class="bg-white rounded-t-2xl border border-b-0 border-gray-100">
    <div class="flex overflow-x-auto">
      <button v-for="t in tabs" :key="t.key" @click="activeTab=t.key"
        class="flex items-center gap-1.5 px-4 py-3 text-sm whitespace-nowrap border-b-2 transition-colors"
        :class="activeTab===t.key ? 'border-amber-500 text-amber-700 font-bold bg-amber-50' : 'border-transparent text-ink-muted hover:text-ink'">
        <AppIcon v-if="t.icon" :name="t.icon" :size="14" />{{ t.label }}
        <span v-if="t.badge" class="ml-0.5 bg-red-500 text-white text-[11px] font-bold px-1.5 rounded-full">{{ t.badge }}</span>
      </button>
    </div>
  </div>

  <!-- 탭 컨텐츠 -->
  <div class="bg-white rounded-b-2xl border border-t-0 border-gray-100 p-4 min-h-[400px]">
    <!-- 📝 게시글 -->
    <div v-if="activeTab==='posts'">
      <AdminListView :icon="icon" :title="''" :api-url="apiUrl" :delete-url="deleteUrl || apiUrl"
        :extra-cols="extraCols" :board-slug="slug"
        :categories="categories" :uses-table="usesTable"
        :category-filter="postCategoryFilter" :category-filter-label="postCategoryFilterLabel"
        :major-type="activeMajorType"
        @open-user="u => $emit('openUser', u)"
        @clear-filter="postCategoryFilter = null; postCategoryFilterLabel = ''"
        @set-category-filter="onSetCategoryFilter" />
    </div>

    <!-- 📂 카테고리 -->
    <div v-else-if="activeTab==='cat'">
      <div class="flex justify-between items-center mb-3">
        <div class="text-sm text-ink-light">
          <span v-if="activeMajorType">
            <strong class="text-amber-700">{{ activeMajorTypeLabel }}</strong> 카테고리
          </span>
          <span v-else>{{ label }} 전용 카테고리</span>
          <span v-if="majorTypes.length && !activeMajorType" class="text-[11px] bg-orange-100 text-orange-700 px-1.5 py-0.5 rounded-full font-semibold ml-1">
            ⚠️ 상단에서 대분류 선택 필요
          </span>
          <span v-if="usesTable" class="badge-green !text-[11px] ml-1">DB 테이블</span>
          <span v-else class="badge-blue !text-[11px] ml-1">설정 저장</span>
        </div>
        <div class="flex gap-2">
          <button @click="addCategory" class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg px-3 py-1.5 text-sm transition-colors">+ 추가</button>
          <button @click="saveCategories" class="btn-primary px-3 py-1.5">저장</button>
        </div>
      </div>
      <div v-if="majorTypes.length && !activeMajorType" class="bg-orange-50 border border-orange-200 rounded-xl p-3 text-sm text-orange-800 mb-3">
        💡 이 게시판은 <strong>대분류별로 카테고리가 분리</strong>되어 있습니다. 위의 {{ majorTypes.map(m=>m.label).join(' / ') }} 중 하나를 먼저 선택하세요.
      </div>
      <div v-if="hasAutoDetected" class="bg-blue-50 border border-blue-200 text-blue-800 rounded-xl p-2 text-xs mb-3">
        💡 기존 데이터에서 자동 감지된 카테고리입니다. 이름을 한글로 수정하고 <strong>"저장"</strong>을 누르면 확정됩니다.
      </div>
      <div v-if="categories.length === 0" class="text-center text-ink-muted py-8 text-sm">카테고리가 없습니다. "+ 추가" 버튼을 눌러주세요.</div>
      <div v-else class="space-y-2">
        <div v-for="(c, i) in categories" :key="i" class="flex items-center gap-2 border border-gray-100 rounded-xl p-2 bg-gray-50">
          <span class="text-ink-faint cursor-move">☰</span>
          <input v-model="c.icon" placeholder="🏷" class="input-soft px-2 py-1 w-14 text-center bg-white" />
          <input v-model="c.name" placeholder="이름" class="input-soft px-2 py-1 flex-1 bg-white" />
          <input v-model="c.slug" placeholder="slug" class="input-soft px-2 py-1 w-28 bg-white" />
          <label class="text-xs flex items-center gap-1 text-ink-light"><input type="checkbox" v-model="c.is_active"> 활성</label>
          <label v-if="hasAutoFetch" class="text-xs flex items-center gap-1 text-ink-light" title="체크하면 매일 YouTube에서 자동으로 영상을 수집합니다. 끄면 사용자가 직접 추가한 트랙만 유지됩니다.">
            <input type="checkbox" v-model="c.auto_fetch"> <AppIcon name="refresh" :size="11" /> 자동수집
          </label>
          <input v-if="hasAutoFetch && c.auto_fetch" v-model="c.channel_url" placeholder="채널 URL(선택) — 지정 시 이 채널만 수집"
            class="input-soft px-2 py-1 w-56 bg-white text-xs" title="채널 URL/핸들을 지정하면 자동수집이 일반 키워드 검색 대신 이 채널의 업로드 영상만 가져옵니다" />
          <span v-if="c.post_count" class="text-[11px] bg-gray-200 text-ink-light px-1.5 py-0.5 rounded-full font-semibold">{{ c.post_count }}개</span>
          <span v-if="c.auto_detected" class="badge-blue !text-[11px]">자동감지</span>
          <button @click="viewCategoryPosts(c)" class="btn-primary px-2 py-1 text-[11px]">
            게시글 보기
          </button>
          <button @click="removeCategory(i)" class="text-red-500 text-xs px-2 hover:text-red-600 transition-colors">삭제</button>
        </div>
      </div>
    </div>

    <!-- 커스텀 탭 슬롯 (부모가 탭 키를 render) -->
    <div v-else-if="isCustomTab(activeTab)">
      <slot :name="`tab-${activeTab}`"></slot>
    </div>

    <!-- ⚙️ 설정 -->
    <div v-else-if="activeTab==='set'">
      <div class="text-sm text-ink-light mb-3">이 게시판만의 기본 설정입니다. 키 형식: <code class="bg-gray-100 px-1 rounded">board.{{ slug }}.*</code></div>
      <div class="space-y-3">
        <div v-for="(def, key) in settingSchema" :key="key" class="flex items-center gap-3 border-b border-gray-50 pb-2">
          <label class="text-sm flex-1">
            <div class="font-medium text-ink">{{ def.label }}</div>
            <div class="text-[11px] text-ink-faint">{{ key }}</div>
          </label>
          <template v-if="def.type==='bool'">
            <input type="checkbox" v-model="settingValues[key]" class="w-4 h-4" />
          </template>
          <template v-else-if="def.type==='select'">
            <select v-model="settingValues[key]" class="input-soft w-auto px-2 py-1">
              <option v-for="o in def.options" :key="o.value" :value="o.value">{{ o.label }}</option>
            </select>
          </template>
          <template v-else-if="def.type==='number'">
            <input type="number" v-model.number="settingValues[key]" class="input-soft px-2 py-1 w-28" />
          </template>
          <template v-else>
            <input type="text" v-model="settingValues[key]" class="input-soft px-2 py-1 w-56" />
          </template>
        </div>
      </div>
      <div class="mt-4 text-right">
        <button @click="saveSettings" class="btn-primary px-4 py-2">설정 저장</button>
      </div>
    </div>

    <!-- 💰 포인트 -->
    <div v-else-if="activeTab==='point'">
      <div class="text-sm text-ink-light mb-3">💡 <strong>{{ label }} 전용</strong> 포인트 규칙. 전역 포인트는 [시스템 › 포인트 설정]에서 관리합니다.</div>
      <table class="w-full text-sm border border-gray-100">
        <thead class="bg-gray-50 text-ink-light">
          <tr>
            <th class="p-2 text-left">항목</th>
            <th class="p-2 w-32">포인트 (P)</th>
            <th class="p-2 w-32">일일 한도</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(def, key) in pointSchema" :key="key" class="border-t border-gray-50" :class="def.is_deduction ? 'bg-red-50' : ''">
            <td class="p-2">
              <div class="font-medium text-ink">{{ def.label }}</div>
              <div class="text-[11px] text-ink-faint">{{ key }}</div>
            </td>
            <td class="p-2"><input type="number" v-model.number="pointValues[key]" class="input-soft px-2 py-1" /></td>
            <td class="p-2"><input type="number" v-model.number="pointValues[key + '_daily_max']" class="input-soft px-2 py-1" placeholder="-" /></td>
          </tr>
        </tbody>
      </table>
      <div class="mt-4 text-right">
        <button @click="savePoints" class="btn-primary px-4 py-2">포인트 규칙 저장</button>
      </div>
    </div>

    <!-- 📢 배너/광고 -->
    <div v-else-if="activeTab==='ban'">
      <div class="flex justify-between items-center mb-3">
        <div class="text-sm text-ink-light">
          이 게시판 페이지({{ slug }})에 노출되는 광고 — 실제 <code class="bg-gray-100 px-1 rounded">banner_ads</code> 연동
        </div>
        <router-link to="/admin/banners" class="text-xs text-blue-600 hover:underline">전체 광고 관리 →</router-link>
      </div>
      <div v-if="bannerStats" class="grid grid-cols-5 gap-2 mb-3">
        <div class="bg-gray-50 rounded-xl p-2 text-center"><div class="text-xs text-ink-muted">전체</div><div class="font-bold text-ink">{{ bannerStats.total }}</div></div>
        <div class="bg-green-50 rounded-xl p-2 text-center"><div class="text-xs text-ink-muted">활성</div><div class="font-bold text-green-700">{{ bannerStats.active }}</div></div>
        <div class="bg-yellow-50 rounded-xl p-2 text-center"><div class="text-xs text-ink-muted">대기</div><div class="font-bold text-yellow-700">{{ bannerStats.pending }}</div></div>
        <div class="bg-blue-50 rounded-xl p-2 text-center"><div class="text-xs text-ink-muted">노출</div><div class="font-bold text-blue-700">{{ bannerStats.total_impressions }}</div></div>
        <div class="bg-purple-50 rounded-xl p-2 text-center"><div class="text-xs text-ink-muted">매출(P)</div><div class="font-bold text-purple-700">{{ bannerStats.total_revenue }}</div></div>
      </div>
      <div v-if="banners.length === 0" class="text-center text-ink-muted py-8 text-sm">이 게시판에 등록된 광고가 없습니다.</div>
      <table v-else class="w-full text-sm">
        <thead class="bg-gray-50 text-ink-light">
          <tr>
            <th class="p-2 text-left">제목</th>
            <th class="p-2 text-left">광고주</th>
            <th class="p-2">위치</th>
            <th class="p-2">슬롯</th>
            <th class="p-2">기간</th>
            <th class="p-2">노출/클릭</th>
            <th class="p-2">비용(P)</th>
            <th class="p-2">상태</th>
            <th class="p-2">관리</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="b in banners" :key="b.id" class="border-t border-gray-50 hover:bg-amber-50/40 transition-colors">
            <td class="p-2 font-medium text-ink">{{ b.title }}</td>
            <td class="p-2"><button @click="$emit('openUser', b.user)" class="text-blue-600 hover:underline text-xs">{{ b.user?.name }}</button></td>
            <td class="p-2 text-center text-xs">{{ b.position }}</td>
            <td class="p-2 text-center text-xs">{{ b.slot_number ? `S${b.slot_number}` : '-' }}</td>
            <td class="p-2 text-[11px] text-ink-muted">{{ b.start_date }} ~ {{ b.end_date }}</td>
            <td class="p-2 text-center text-xs">{{ b.impressions }}/{{ b.clicks }}</td>
            <td class="p-2 text-center">{{ b.total_cost }}</td>
            <td class="p-2 text-center">
              <span class="text-[11px] px-2 py-0.5 rounded-full font-semibold" :class="statusClass(b.status)">{{ b.status }}</span>
            </td>
            <td class="p-2 text-center">
              <button v-if="b.status==='pending'" @click="approveBanner(b)" class="text-xs text-green-600 mr-1 hover:underline">승인</button>
              <button v-if="b.status==='pending'" @click="rejectBanner(b)" class="text-xs text-red-600 mr-1 hover:underline">거절</button>
              <button v-if="b.status==='active'" @click="pauseBanner(b)" class="text-xs text-orange-600 mr-1 hover:underline">일시정지</button>
              <button @click="deleteBanner(b)" class="text-xs text-ink-muted hover:underline">삭제</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- 🚨 신고 -->
    <div v-else-if="activeTab==='rep'">
      <div class="text-sm text-ink-light mb-3">이 게시판에 대한 신고 대기 목록</div>
      <div v-if="reports.length === 0" class="text-center text-ink-muted py-8 text-sm">신고가 없습니다.</div>
      <table v-else class="w-full text-sm">
        <thead class="bg-gray-50 text-ink-light">
          <tr>
            <th class="p-2 text-left">대상</th>
            <th class="p-2 text-left">신고자</th>
            <th class="p-2 text-left">사유</th>
            <th class="p-2">상태</th>
            <th class="p-2">시간</th>
            <th class="p-2">처리</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="r in reports" :key="r.id" class="border-t border-gray-50">
            <td class="p-2 text-xs">#{{ r.reportable_id }}</td>
            <td class="p-2"><button @click="$emit('openUser', r.reporter)" class="text-blue-600 hover:underline text-xs">{{ r.reporter?.name }}</button></td>
            <td class="p-2 text-red-600 text-xs">{{ r.reason }}</td>
            <td class="p-2 text-center"><span class="badge-gray !text-[11px]">{{ r.status }}</span></td>
            <td class="p-2 text-[11px] text-ink-faint">{{ (r.created_at||'').slice(0,10) }}</td>
            <td class="p-2 text-center">
              <button @click="updateReport(r, 'resolved')" class="text-xs text-green-600 mr-1 hover:underline">해결</button>
              <button @click="updateReport(r, 'rejected')" class="text-xs text-ink-muted hover:underline">기각</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</div>
</template>

<script setup>
import { ref, onMounted, computed, watch, inject } from 'vue'
import axios from 'axios'
import AdminListView from './AdminListView.vue'
import AppIcon from './AppIcon.vue'

const props = defineProps({
  slug:      { type: String, required: true },
  label:     { type: String, required: true },
  icon:      { type: String, default: '📋' },
  apiUrl:    { type: String, required: true },
  deleteUrl: { type: String, default: null },
  extraCols: { type: Array, default: () => [] },
  // 게시판 고유 설정 스키마 (key → { label, type, default, options })
  settingSchema: { type: Object, default: () => ({}) },
  pointSchema:   { type: Object, default: () => ({}) },
  // 커스텀 탭 (slug 별 추가 탭 — key/label/icon, 삽입 위치는 afterCategory 또는 afterPosts)
  customTabs: { type: Array, default: () => [] },
})
defineEmits(['openUser'])

// 관리자 휴대폰 화면이면 카드/칩 형태로 보여 줌 (AdminLayout 이 알려 줌)
const adminIsMobile = inject('adminIsMobile', ref(false))
const isMobile = computed(() => !!adminIsMobile.value)

const activeTab = ref('posts')
const tabs = computed(() => {
  const base = [
    { key: 'posts', icon: 'edit', label: '게시글' },
    { key: 'cat',   icon: 'tag',  label: '카테고리' },
  ]
  // afterCategory 위치의 커스텀 탭 (예: 공구 승인)
  const afterCat = (props.customTabs || []).filter(t => !t.position || t.position === 'afterCategory')
  const rest = [
    { key: 'set',   icon: 'settings',     label: '설정' },
    { key: 'point', icon: 'coins',        label: '포인트' },
    { key: 'ban',   icon: 'megaphone',    label: '배너/광고', badge: bannerStats.value?.pending || 0 },
    { key: 'rep',   icon: 'alert-circle', label: '신고', badge: overview.value?.pending_reports || 0 },
  ]
  return [...base, ...afterCat, ...rest]
})

const overview = ref({})
const categories = ref([])
const usesTable = ref(false)
const postCategoryFilter = ref(null)
const postCategoryFilterLabel = ref('')
const activeMajorType = ref('')

const majorTypes = computed(() => overview.value?.major_types_breakdown || [])
const activeMajorTypeLabel = computed(() => {
  const m = majorTypes.value.find(mt => mt.key === activeMajorType.value)
  return m?.label || ''
})

function setMajorType(key) {
  activeMajorType.value = key
  postCategoryFilter.value = null
  postCategoryFilterLabel.value = ''
  loadCategories()
}

function viewCategoryPosts(c) {
  // FK 기반이면 id, 문자열 기반이면 slug/name 사용
  postCategoryFilter.value = c.id || c.slug || c.name
  postCategoryFilterLabel.value = c.name || c.slug
  activeTab.value = 'posts'
}

function onSetCategoryFilter({ value, label }) {
  postCategoryFilter.value = value
  postCategoryFilterLabel.value = label
}

function isCustomTab(key) {
  return (props.customTabs || []).some(t => t.key === key)
}
const settingValues = ref({})
const pointValues = ref({})
const banners = ref([])
const bannerStats = ref(null)
const reports = ref([])

async function loadOverview() {
  try {
    const { data } = await axios.get(`/api/admin/board-manager/${props.slug}/overview`)
    overview.value = data.data
  } catch (e) { console.warn('overview load failed', e) }
}

async function loadCategories() {
  try {
    const params = {}
    if (activeMajorType.value) params.major_type = activeMajorType.value
    const { data } = await axios.get(`/api/admin/board-manager/${props.slug}/categories`, { params })
    categories.value = (data.data || []).map(c => ({
      id: c.id,
      name: c.name || '',
      slug: c.slug || '',
      icon: c.icon || '',
      is_active: c.is_active !== false,
      auto_fetch: c.auto_fetch !== false,
      channel_url: c.channel_url || '',
      post_count: c.post_count || 0,
      auto_detected: !!c.auto_detected,
    }))
    usesTable.value = !!data.uses_table
  } catch (e) { console.warn('categories load failed', e) }
}
const hasAutoDetected = computed(() => categories.value.some(c => c.auto_detected))
// auto_fetch 컬럼이 카테고리에 존재할 때만 체크박스 노출 (현재 music 만)
const hasAutoFetch = computed(() => props.slug === 'music' && usesTable.value)
function addCategory() { categories.value.push({ name: '', slug: '', icon: '🏷', is_active: true, auto_fetch: true, channel_url: '' }) }
function removeCategory(i) { categories.value.splice(i, 1) }
function removeCategoryMobile(i) {
  const c = categories.value[i]
  if (!confirm(`'${c?.name || '이름 없음'}' 카테고리를 목록에서 뺄까요?\n(아래 '저장'을 눌러야 실제로 반영돼요)`)) return
  removeCategory(i)
}
async function saveCategories() {
  try {
    const payload = { categories: categories.value }
    if (activeMajorType.value) payload.major_type = activeMajorType.value
    await axios.post(`/api/admin/board-manager/${props.slug}/categories`, payload)
    alert('카테고리가 저장되었습니다')
    loadCategories()
  } catch (e) { alert(e.response?.data?.message || '저장 실패') }
}

async function loadSettings() {
  try {
    const { data } = await axios.get(`/api/admin/board-manager/${props.slug}/settings`)
    const raw = data.data || {}
    const vals = {}
    Object.keys(props.settingSchema).forEach(key => {
      const fullKey = `board.${props.slug}.${key}`
      const def = props.settingSchema[key]
      const item = raw[fullKey]
      let val = item?.value
      if (val === undefined || val === null) val = def.default
      if (def.type === 'bool') val = val === true || val === 'true' || val === '1' || val === 1
      if (def.type === 'number') val = Number(val || 0)
      vals[key] = val
    })
    settingValues.value = vals
  } catch (e) { console.warn('settings load failed', e) }
}
async function saveSettings() {
  const payload = {}
  Object.keys(settingValues.value).forEach(key => {
    payload[`board.${props.slug}.${key}`] = settingValues.value[key]
  })
  try {
    await axios.post(`/api/admin/board-manager/${props.slug}/settings`, { settings: payload })
    alert('설정이 저장되었습니다')
  } catch (e) { alert(e.response?.data?.message || '저장 실패') }
}

async function loadPoints() {
  try {
    const { data } = await axios.get(`/api/admin/board-manager/${props.slug}/points`)
    const raw = (data.data || []).reduce((acc, r) => { acc[r.key] = r.value; return acc }, {})
    const vals = {}
    Object.keys(props.pointSchema).forEach(key => {
      const fullKey = `board.${props.slug}.point_${key}`
      vals[key] = Number(raw[fullKey] ?? props.pointSchema[key].default ?? 0)
      vals[key + '_daily_max'] = Number(raw[fullKey + '_daily_max'] ?? props.pointSchema[key].daily_max ?? 0)
    })
    pointValues.value = vals
  } catch (e) { console.warn('points load failed', e) }
}
async function savePoints() {
  const payload = {}
  Object.keys(pointValues.value).forEach(key => {
    const cleanKey = key.replace(/_daily_max$/, '')
    const suffix = key.endsWith('_daily_max') ? '_daily_max' : ''
    payload[`board.${props.slug}.point_${cleanKey}${suffix}`] = pointValues.value[key]
  })
  try {
    await axios.post(`/api/admin/board-manager/${props.slug}/points`, { points: payload })
    alert('포인트 규칙이 저장되었습니다')
  } catch (e) { alert(e.response?.data?.message || '저장 실패') }
}

async function loadBanners() {
  try {
    const { data } = await axios.get(`/api/admin/board-manager/${props.slug}/banners`)
    banners.value = data.data || []
    bannerStats.value = data.stats
  } catch (e) { console.warn('banners load failed', e) }
}
async function approveBanner(b) { await axios.post(`/api/admin/banners/${b.id}/approve`); loadBanners() }
async function rejectBanner(b) {
  const reason = prompt('거절 사유')
  if (!reason) return
  await axios.post(`/api/admin/banners/${b.id}/reject`, { reason })
  loadBanners()
}
async function pauseBanner(b) { await axios.post(`/api/admin/banners/${b.id}/pause`); loadBanners() }
async function deleteBanner(b) {
  if (!confirm('삭제? (활성 광고는 포인트 환불됨)')) return
  await axios.delete(`/api/admin/banners/${b.id}`)
  loadBanners()
}

async function loadReports() {
  try {
    const { data } = await axios.get(`/api/admin/board-manager/${props.slug}/reports`)
    reports.value = data.data?.data || data.data || []
  } catch (e) { console.warn('reports load failed', e) }
}
async function updateReport(r, status) {
  await axios.put(`/api/admin/reports/${r.id}`, { status })
  loadReports()
  loadOverview()
}

function statusClass(s) {
  return {
    active:   'bg-green-100 text-green-700',
    pending:  'bg-yellow-100 text-yellow-700',
    paused:   'bg-orange-100 text-orange-700',
    rejected: 'bg-red-100 text-red-700',
    expired:  'bg-gray-100 text-gray-500',
  }[s] || 'bg-gray-100 text-gray-700'
}

watch(activeTab, (tab) => {
  if (tab === 'cat')   loadCategories()
  if (tab === 'set')   loadSettings()
  if (tab === 'point') loadPoints()
  if (tab === 'ban')   loadBanners()
  if (tab === 'rep')   loadReports()
})

onMounted(() => {
  loadOverview()
  loadCategories() // 게시글 탭 드롭다운 필터에 필요
  loadBanners() // for badge count
})
</script>
