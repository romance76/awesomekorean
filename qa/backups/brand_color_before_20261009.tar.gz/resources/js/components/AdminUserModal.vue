<template>
<div v-if="show && !isMobile" class="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" @click.self="$emit('close')">
  <div class="bg-white rounded-2xl shadow-xl w-full max-w-5xl max-h-[92vh] overflow-hidden flex flex-col">
    <div class="px-5 py-3 border-b border-gray-100 flex items-center justify-between bg-amber-50">
      <div class="flex items-center gap-2">
        <span class="icon-chip w-7 h-7 bg-white text-amber-600"><AppIcon name="user" :size="15" /></span>
        <span class="font-bold text-ink">회원 상세 정보</span>
        <span v-if="data?.user" class="text-sm text-ink-light">— {{ data.user.name }} ({{ data.user.email }})</span>
      </div>
      <button @click="$emit('close')" class="text-ink-muted hover:text-ink transition-colors"><AppIcon name="x" :size="20" /></button>
    </div>

    <div v-if="loading" class="py-12 text-center text-ink-muted">로딩중...</div>
    <div v-else-if="data" class="flex-1 overflow-hidden flex flex-col">
      <!-- 요약 카드 -->
      <div class="px-5 pt-3 grid grid-cols-6 gap-2">
        <div class="bg-blue-50 rounded-xl p-2 text-center">
          <div class="text-xs text-ink-muted">포인트</div>
          <div class="font-bold text-blue-700">{{ Number(data.user.points||0).toLocaleString() }}P</div>
        </div>
        <div class="bg-amber-50 rounded-xl p-2 text-center">
          <div class="text-xs text-ink-muted">Entry</div>
          <div class="font-bold text-amber-700">🎟 {{ Number(data.user.entries||0).toLocaleString() }}</div>
        </div>
        <div class="bg-green-50 rounded-xl p-2 text-center">
          <div class="text-xs text-ink-muted">결제 누적</div>
          <div class="font-bold text-green-700">${{ Number(data.summary?.total_spent_usd||0) }}</div>
        </div>
        <div class="bg-purple-50 rounded-xl p-2 text-center">
          <div class="text-xs text-ink-muted">전체 게시</div>
          <div class="font-bold text-purple-700">{{ data.summary?.posts_total||0 }}</div>
        </div>
        <div class="bg-amber-50 rounded-xl p-2 text-center">
          <div class="text-xs text-ink-muted">광고(활성)</div>
          <div class="font-bold text-amber-700">{{ data.summary?.ads_active||0 }}</div>
        </div>
        <div class="bg-red-50 rounded-xl p-2 text-center">
          <div class="text-xs text-ink-muted">상태</div>
          <div class="font-bold" :class="data.user.is_banned?'text-red-700':'text-green-700'">{{ data.user.is_banned?'정지':'정상' }}</div>
        </div>
      </div>

      <!-- 탭 -->
      <div class="px-5 pt-3 flex flex-wrap gap-1 border-b border-gray-100">
        <button v-for="t in tabs" :key="t.key" @click="tab=t.key"
          class="flex items-center gap-1 px-3 py-2 text-xs font-medium border-b-2 -mb-px whitespace-nowrap transition-colors"
          :class="tab===t.key?'border-amber-500 text-amber-700':'border-transparent text-ink-muted hover:text-ink'">
          <AppIcon :name="t.icon" :size="12" />{{ t.label }}
          <span v-if="count(t.key) > 0" class="ml-0.5 bg-gray-100 text-ink-light text-[11px] px-1 rounded">{{ count(t.key) }}</span>
        </button>
      </div>

      <!-- 스크롤 영역 -->
      <div class="flex-1 overflow-y-auto px-5 py-3">
        <!-- 기본정보 -->
        <div v-if="tab==='info'">
          <div class="grid grid-cols-2 gap-3">
            <div><label class="input-label !text-xs !mb-0.5">이름</label><input v-model="data.user.name" class="input-soft px-3 py-1.5" /></div>
            <div><label class="input-label !text-xs !mb-0.5">닉네임</label><input v-model="data.user.nickname" class="input-soft px-3 py-1.5" /></div>
            <div><label class="input-label !text-xs !mb-0.5">이메일</label><input v-model="data.user.email" class="input-soft px-3 py-1.5" /></div>
            <div><label class="input-label !text-xs !mb-0.5">전화</label><input v-model="data.user.phone" class="input-soft px-3 py-1.5" /></div>
            <div><label class="input-label !text-xs !mb-0.5">도시</label><input v-model="data.user.city" class="input-soft px-3 py-1.5" /></div>
            <div><label class="input-label !text-xs !mb-0.5">주</label><input v-model="data.user.state" class="input-soft px-3 py-1.5" /></div>
            <div><label class="input-label !text-xs !mb-0.5">역할</label>
              <select v-model="data.user.role" class="input-soft px-3 py-1.5">
                <option value="user">일반</option><option value="admin">관리자</option><option value="super_admin">슈퍼</option>
              </select>
            </div>
            <div><label class="input-label !text-xs !mb-0.5">상태</label>
              <select v-model="data.user.is_banned" class="input-soft px-3 py-1.5">
                <option :value="false">정상</option><option :value="true">정지</option>
              </select>
            </div>
            <div><label class="input-label !text-xs !mb-0.5">포인트</label><input v-model.number="data.user.points" type="number" class="input-soft px-3 py-1.5" /></div>
            <div><label class="input-label !text-xs !mb-0.5">게임 포인트</label><input v-model.number="data.user.game_points" type="number" class="input-soft px-3 py-1.5" /></div>
          </div>
          <div class="mt-3 text-xs text-ink-faint">가입: {{ data.user.created_at?.slice(0,10) }} · 로그인 {{ data.user.login_count||0 }}회 · 최근 {{ data.user.last_login_at?.slice(0,10)||'-' }}</div>
          <button @click="saveUser" class="btn-primary mt-3 px-5 py-2">저장</button>
        </div>

        <!-- 결제 -->
        <div v-if="tab==='payments'">
          <div v-if="!data.payments?.length" class="py-6 text-center text-ink-muted text-sm">결제 내역 없음</div>
          <table v-else class="w-full text-xs">
            <thead class="bg-gray-50 text-ink-light"><tr><th class="p-2 text-left">주문#</th><th class="p-2">날짜</th><th class="p-2">금액</th><th class="p-2">포인트</th><th class="p-2">상태</th><th class="p-2">Stripe</th></tr></thead>
            <tbody>
              <tr v-for="p in data.payments" :key="p.id" class="border-t border-gray-50">
                <td class="p-2 font-bold">#{{ p.id }}</td>
                <td class="p-2">{{ p.created_at?.slice(0,10) }}</td>
                <td class="p-2 text-green-700 font-bold">${{ p.amount }}</td>
                <td class="p-2 text-blue-700 font-bold">+{{ p.points_purchased }}P</td>
                <td class="p-2"><span class="px-1.5 py-0.5 rounded-full text-[11px] font-semibold" :class="statusClass(p.status)">{{ p.status }}</span></td>
                <td class="p-2 text-[11px] text-ink-faint truncate max-w-[120px]">{{ p.stripe_payment_id }}</td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- 포인트 -->
        <div v-if="tab==='points'">
          <div v-if="!data.points?.length" class="py-6 text-center text-ink-muted text-sm">포인트 내역 없음</div>
          <table v-else class="w-full text-xs">
            <thead class="bg-gray-50 text-ink-light"><tr><th class="p-2 text-left">날짜</th><th class="p-2 text-left">사유</th><th class="p-2">타입</th><th class="p-2">증감</th><th class="p-2">잔액</th></tr></thead>
            <tbody>
              <tr v-for="pt in data.points" :key="pt.id" class="border-t border-gray-50">
                <td class="p-2 text-ink-muted">{{ pt.created_at?.slice(0,16).replace('T',' ') }}</td>
                <td class="p-2">{{ pt.reason }}</td>
                <td class="p-2 text-[11px] text-ink-muted">{{ pt.type }}</td>
                <td class="p-2 text-right font-bold" :class="pt.amount>0?'text-green-600':'text-red-600'">{{ pt.amount>0?'+':'' }}{{ pt.amount }}P</td>
                <td class="p-2 text-right text-ink-light">{{ pt.balance_after }}P</td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- Entry (Sweepstakes 응모권 — Point와 완전 별도 시스템) -->
        <div v-if="tab==='entries'">
          <div class="bg-amber-50 border border-amber-100 rounded-xl p-3 mb-3 flex flex-wrap items-end gap-3">
            <div>
              <label class="text-xs text-ink-muted block mb-1">증감 (음수 가능)</label>
              <input v-model.number="entryAdjustForm.amount" type="number" class="input-soft !w-28 !py-1.5 text-sm" />
            </div>
            <div class="flex-1 min-w-[200px]">
              <label class="text-xs text-ink-muted block mb-1">사유</label>
              <input v-model="entryAdjustForm.description" type="text" class="input-soft w-full !py-1.5 text-sm" placeholder="예: 이벤트 보상, 테스트용" />
            </div>
            <button @click="adjustEntries" :disabled="entryAdjusting" class="btn-primary !px-5 !py-2 text-sm">{{ entryAdjusting ? '처리중...' : '지급/차감' }}</button>
          </div>
          <div v-if="entryAdjustMsg" class="text-sm mb-3" :class="entryAdjustOk?'text-green-600':'text-red-500'">{{ entryAdjustMsg }}</div>

          <div v-if="!data.entries?.length" class="py-6 text-center text-ink-muted text-sm">Entry 내역 없음</div>
          <table v-else class="w-full text-xs">
            <thead class="bg-gray-50 text-ink-light"><tr><th class="p-2 text-left">날짜</th><th class="p-2 text-left">사유</th><th class="p-2">타입</th><th class="p-2">증감</th><th class="p-2">잔액</th></tr></thead>
            <tbody>
              <tr v-for="et in data.entries" :key="et.id" class="border-t border-gray-50">
                <td class="p-2 text-ink-muted">{{ et.created_at?.slice(0,16).replace('T',' ') }}</td>
                <td class="p-2">{{ et.description }}</td>
                <td class="p-2 text-[11px] text-ink-muted">{{ et.transaction_type }}</td>
                <td class="p-2 text-right font-bold" :class="et.amount>0?'text-green-600':'text-red-600'">{{ et.amount>0?'+':'' }}{{ et.amount }}</td>
                <td class="p-2 text-right text-ink-light">🎟 {{ et.balance_after }}</td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- 커뮤니티 -->
        <div v-if="tab==='posts'">
          <PostTable :items="data.posts" icon="💬" empty="커뮤니티 게시글 없음" />
        </div>
        <!-- 댓글 -->
        <div v-if="tab==='comments'">
          <div v-if="!data.comments?.length" class="py-6 text-center text-ink-muted text-sm">댓글 없음</div>
          <div v-for="c in data.comments" :key="c.id" class="py-2 border-b border-gray-50 text-xs">
            <div class="text-ink-light">{{ c.content }}</div>
            <div class="text-[11px] text-ink-faint mt-0.5">{{ c.created_at?.slice(0,10) }} · 좋아요 {{ c.like_count||0 }}</div>
          </div>
        </div>
        <!-- 장터 -->
        <div v-if="tab==='market'"><PostTable :items="data.market" icon="🛒" empty="장터 글 없음" :extra="['price','city']" /></div>
        <!-- 구인 -->
        <div v-if="tab==='jobs'"><PostTable :items="data.jobs" icon="💼" empty="구인 글 없음" :extra="['company','city']" /></div>
        <!-- 부동산 -->
        <div v-if="tab==='realestate'"><PostTable :items="data.realestate" icon="🏠" empty="부동산 글 없음" :extra="['price','city']" /></div>
        <!-- 이벤트 -->
        <div v-if="tab==='events'"><PostTable :items="data.events" icon="🎉" empty="이벤트 없음" :extra="['start_date','city']" /></div>
        <!-- 동호회 -->
        <div v-if="tab==='clubs'"><PostTable :items="data.clubs" icon="👥" empty="동호회 없음" :extra="['category','member_count']" title-field="name" /></div>
        <!-- Q&A -->
        <div v-if="tab==='qa'"><PostTable :items="data.qa" icon="❓" empty="Q&A 없음" :extra="['bounty_points','answer_count']" /></div>

        <!-- 광고 -->
        <div v-if="tab==='banners'">
          <div v-if="!data.banners?.length" class="py-6 text-center text-ink-muted text-sm">광고 신청 내역 없음</div>
          <table v-else class="w-full text-xs">
            <thead class="bg-gray-50 text-ink-light"><tr><th class="p-2 text-left">제목</th><th class="p-2">페이지</th><th class="p-2">위치</th><th class="p-2">기간</th><th class="p-2">비용</th><th class="p-2">상태</th></tr></thead>
            <tbody>
              <tr v-for="b in data.banners" :key="b.id" class="border-t border-gray-50">
                <td class="p-2">{{ b.title }}</td>
                <td class="p-2 text-[11px]">{{ b.page }}</td>
                <td class="p-2 text-[11px] text-center">{{ b.position }}</td>
                <td class="p-2 text-[11px] text-ink-muted">{{ b.start_date }} ~ {{ b.end_date }}</td>
                <td class="p-2 text-right">{{ b.total_cost }}P</td>
                <td class="p-2 text-center"><span class="text-[11px] px-1.5 py-0.5 rounded-full font-semibold" :class="statusClass(b.status)">{{ b.status }}</span></td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- 신고한 내역 -->
        <div v-if="tab==='reports'">
          <div v-if="!data.reports_filed?.length" class="py-6 text-center text-ink-muted text-sm">신고 내역 없음</div>
          <div v-for="r in data.reports_filed" :key="r.id" class="py-2 border-b border-gray-50 text-xs">
            <div class="flex justify-between">
              <span class="font-medium text-ink">{{ r.reportable_type?.split('\\').pop() }} #{{ r.reportable_id }}</span>
              <span class="text-[11px] px-1.5 py-0.5 rounded-full font-semibold" :class="statusClass(r.status)">{{ r.status }}</span>
            </div>
            <div class="text-red-600">{{ r.reason }}</div>
            <div class="text-[11px] text-ink-faint">{{ r.created_at?.slice(0,10) }}</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</template>

<script setup>
import { ref, computed, watch, inject, h } from 'vue'
import { useRouter } from 'vue-router'
import axios from 'axios'
import AppIcon from './AppIcon.vue'

const props = defineProps({ show: Boolean, userId: [Number, String] })
const emit = defineEmits(['close'])

// 휴대폰 관리자: 이 큰 팝업 대신 '회원관리'의 휴대폰 회원 상세 화면으로 이동
const adminIsMobile = inject('adminIsMobile', ref(false))
const isMobile = computed(() => !!adminIsMobile.value)
const router = useRouter()
watch(() => [props.show, props.userId], ([show, id]) => {
  if (show && id && isMobile.value) { emit('close'); router.push({ path: '/admin/members', query: { user: String(id) } }) }
}, { immediate: true })

const data = ref(null); const loading = ref(false); const tab = ref('info')
const entryAdjustForm = ref({ amount: '', description: '' })
const entryAdjusting = ref(false)
const entryAdjustMsg = ref('')
const entryAdjustOk = ref(false)

const tabs = [
  { key:'info',       icon:'list',           label:'기본정보' },
  { key:'payments',   icon:'wallet',         label:'결제' },
  { key:'points',     icon:'coins',          label:'포인트' },
  { key:'entries',    icon:'ticket',         label:'Entry' },
  { key:'posts',      icon:'message-circle', label:'커뮤니티' },
  { key:'comments',   icon:'message-square', label:'댓글' },
  { key:'market',     icon:'shopping-cart',  label:'장터' },
  { key:'jobs',       icon:'briefcase',      label:'구인' },
  { key:'realestate', icon:'building',       label:'부동산' },
  { key:'events',     icon:'calendar',       label:'이벤트' },
  { key:'clubs',      icon:'users',          label:'동호회' },
  { key:'qa',         icon:'help-circle',    label:'Q&A' },
  { key:'banners',    icon:'megaphone',      label:'광고' },
  { key:'reports',    icon:'alert-circle',   label:'신고' },
]

function count(key) {
  if (!data.value) return 0
  const map = { payments:'payments', points:'points', entries:'entries', posts:'posts', comments:'comments',
    market:'market', jobs:'jobs', realestate:'realestate', events:'events',
    clubs:'clubs', qa:'qa', banners:'banners', reports:'reports_filed' }
  return data.value[map[key]]?.length || 0
}

function statusClass(s) {
  return {
    active:    'bg-green-100 text-green-700',
    completed: 'bg-green-100 text-green-700',
    resolved:  'bg-green-100 text-green-700',
    pending:   'bg-yellow-100 text-yellow-700',
    paused:    'bg-orange-100 text-orange-700',
    rejected:  'bg-red-100 text-red-700',
    refunded:  'bg-red-100 text-red-700',
    cancelled: 'bg-gray-100 text-gray-500',
    expired:   'bg-gray-100 text-gray-500',
  }[s] || 'bg-gray-100 text-gray-700'
}

// 게시물 공통 리스트 컴포넌트
const PostTable = {
  props: { items: Array, icon: String, empty: String, extra: { type: Array, default: () => [] }, titleField: { type: String, default: 'title' } },
  setup(p) {
    return () => {
      if (!p.items?.length) return h('div', { class: 'py-6 text-center text-gray-400 text-sm' }, p.empty)
      return h('table', { class: 'w-full text-xs' }, [
        h('thead', { class: 'bg-gray-50 text-gray-600' }, h('tr', [
          h('th', { class: 'p-2 text-left' }, '#'),
          h('th', { class: 'p-2 text-left' }, '제목'),
          ...p.extra.map(k => h('th', { class: 'p-2' }, k)),
          h('th', { class: 'p-2' }, '조회'),
          h('th', { class: 'p-2' }, '날짜'),
        ])),
        h('tbody', p.items.map(it =>
          h('tr', { class: 'border-t', key: it.id }, [
            h('td', { class: 'p-2 text-gray-400' }, '#' + it.id),
            h('td', { class: 'p-2 font-medium' }, it[p.titleField] || it.title || it.name || '-'),
            ...p.extra.map(k => h('td', { class: 'p-2 text-center text-[10px]' }, String(it[k] ?? '-'))),
            h('td', { class: 'p-2 text-center text-gray-500' }, it.view_count || 0),
            h('td', { class: 'p-2 text-[10px] text-gray-400' }, (it.created_at||'').slice(0,10)),
          ])
        ))
      ])
    }
  }
}

watch(() => props.userId, async (id) => {
  if (!id || isMobile.value) return
  loading.value = true; data.value = null; tab.value = 'info'
  try { const { data: res } = await axios.get(`/api/admin/users/${id}/detail`); data.value = res.data } catch {}
  loading.value = false
}, { immediate: true })

async function adjustEntries() {
  if (!data.value?.user || !entryAdjustForm.value.amount) return
  entryAdjusting.value = true; entryAdjustMsg.value = ''
  try {
    const { data: res } = await axios.post('/api/admin/entries/adjust', {
      user_id: data.value.user.id,
      amount: entryAdjustForm.value.amount,
      description: entryAdjustForm.value.description || '관리자 조정',
    })
    data.value.user.entries = res.data?.balance_after ?? data.value.user.entries
    entryAdjustMsg.value = '처리되었습니다'; entryAdjustOk.value = true
    entryAdjustForm.value = { amount: '', description: '' }
    const { data: fresh } = await axios.get(`/api/admin/users/${data.value.user.id}/detail`)
    if (fresh.data) data.value.entries = fresh.data.entries
  } catch (e) {
    entryAdjustMsg.value = e.response?.data?.message || '처리 실패'; entryAdjustOk.value = false
  }
  entryAdjusting.value = false
}

async function saveUser() {
  if (!data.value?.user) return
  try { await axios.put(`/api/admin/users/${data.value.user.id}`, data.value.user); alert('저장되었습니다') } catch (e) { alert(e.response?.data?.message || '저장 실패') }
}
</script>
